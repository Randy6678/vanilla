import Link from "next/link";
import Image from "next/image";

import classes from "./hero.module.css";

import CelebrationSvg from "../../assets/svg/celebration.svg";

function AboutUsHeroSection() {
  return (
    <div className="m-auto max-w-6xl p-12">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/2 max-w-md flex flex-col justify-center leading-tight">
          <div className="md:text-3xl text-2xl font-black">
            Our Goals And Mission
          </div>
          <div className="mt-4 leading-relaxed">
            <h4 className="text-lg text-gray-600 leading-relaxed font-semibold mb-4">
              Our goal and mission is to spread love and smiles. Sending mobile
              top-ups is on of the ways of sharing love and smiles
            </h4>
            <p className="text-lg font-medium text-gray-500">
              <span className="italic align-top text-lg font-bold text-gray-600">"</span>
              Mobile phones can change lives and therefore so can we. It’s a
              massive responsibility and a global opportunity. That’s why we do
              everything we can every day to make people’s lives a little better
              through mobile top-up.
              <span className="italic align-top text-2xl font-bold text-gray-600">"</span>
            </p>
            <p className="text-right text-sm italic underline text-gray-500">-- By Someone Famous</p>
          </div>
          <div className="my-5 h-16">
            <Link href="/send-topup">
              <a className="shadow-md font-medium py-2 px-4 text-gray-100 cursor-pointer bg-red-500 hover:bg-red-600 rounded text-lg text-center w-48">
                Send A Topup
              </a>
            </Link>
          </div>
        </div>
        <div className="flex md:justify-end w-full md:w-1/2 -mt-5">
          <div className={classes.bgDots}>
            <div className="shadow-2xl max-w-md rounded-t-full mt-6 ml-4">
              <Image
                alt="card img"
                className="rounded-t"
                src={CelebrationSvg}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AboutUsHeroSection;

import Image from "next/image";

import SendGiftSvg from "../../../assets/svg/send_gift.svg";
import { AppleStoreLogo, PlayStoreLogo, TravelMan } from "../../ui/svg";

function HomeHeroSection() {
  return (
    <div className="hero bg-gray-100 py-16">
      {/*container */}
      <div className="container px-4 sm:px-8 lg:px-16 xl:px-20 mx-auto">
        {/*hero wrapper */}
        <div className="hero-wrapper grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/*hero text */}
          <div className="hero-text col-span-6">
            <h1 className=" font-bold text-4xl md:text-5xl max-w-xl text-gray-900 leading-tight">
              Send mobile recharge to anyone anywhere
            </h1>
            <hr className=" w-12 h-1 bg-red-500 rounded-full mt-8" />
            <p className="text-gray-800 text-base leading-relaxed mt-8 font-semibold">
              Easy and safe way to recharge a mobile phone overseas and stay
              connected to your loved ones
            </p>
            <div className="get-app flex space-x-5 mt-10 justify-center md:justify-start">
              <button className="apple bg-white shadow-md px-3 py-2 rounded-lg flex items-center space-x-4">
                <div className="logo">
                  <AppleStoreLogo />
                </div>
                <div className="text">
                  <p
                    className=" text-xs text-gray-600"
                    style={{ fontSize: "0.5rem" }}
                  >
                    Download on the
                  </p>
                  <p className=" text-xs font-semibold text-gray-900">
                    Apple Store
                  </p>
                </div>
              </button>
              <button className="google bg-white shadow-md px-3 py-2 rounded-lg flex items-center space-x-4">
                <div className="image">
                  <PlayStoreLogo />
                </div>
                <div className="text">
                  <p
                    className="text-xs text-gray-600"
                    style={{ fontSize: "0.5rem" }}
                  >
                    Download it from
                  </p>
                  <p className="text-xs font-semibold text-gray-900">
                    Google play
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/*hero image */}
          <div className="hero-image col-span-6">
            {/* <TravelMan /> */}
            <Image src={SendGiftSvg} alt="Send Top up" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomeHeroSection;

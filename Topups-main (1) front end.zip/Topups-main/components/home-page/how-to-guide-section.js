import {
  UserCircleIcon,
  IdentificationIcon,
  CashIcon,
  EmojiHappyIcon,
} from "@heroicons/react/solid";

function HowToGuideSection() {
  return (
    <section className="py-12">
      <div className="text-center max-w-3xl mx-auto mb-6 px-6 md:px-0">
        <h1 className="text-gray-800 text-3xl font-bold text-center mb-5">
          How can you buy top-ups at topup ?
        </h1>
        <p className="text-gray-500 font-normal text-xl text-center">
          We make it to experience the future of mobile top-ups
        </p>
      </div>
      <div className="pt-8 pb-6 px-5 md:px-8 xl:px-0 text-center sm:text-left">
        <div className="max-w-6xl m-auto grid grid-flow-row gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 justify-center">
          <div className="py-5 px-2">
            <UserCircleIcon className="w-20 h-20 text-blue-500 mb-2 mx-auto sm:mx-0" />
            <h3 className="text-md font-medium mb-4 text-gray-800">
              1. Create a free account
            </h3>
            <p className="text-sm text-gray-500">Sign up and create your free account</p>
          </div>
          <div className="py-5 px-2">
            <IdentificationIcon className="w-20 h-20 text-blue-500 mb-2 mx-auto sm:mx-0" />
            <h3 className="text-md font-medium mb-4 text-gray-800">
              2. Enter recipient info
            </h3>
            <p className="text-sm text-gray-500">
              Enter the top-up recipient country, phone number and mobile operator
            </p>
          </div>
          <div className="py-5 px-2">
            <CashIcon className="w-20 h-20 text-blue-500 mb-2 mx-auto sm:mx-0" />
            <h3 className="text-md font-medium mb-4 text-gray-800">3. Make Payments</h3>
            <p className="text-sm text-gray-500">
              Variaty of payment methods:
              credit card, payment app, or by bank transfer
            </p>
          </div>
          <div className="py-5 px-2">
            <EmojiHappyIcon className="w-20 h-20 text-blue-500 mb-2 mx-auto sm:mx-0" />
            <h3 className="text-md font-medium mb-4 text-gray-800">
              4. Receive Top-up
            </h3>
            <p className="text-sm text-gray-500">
              Relax, lets process your top-up order. Receive top-up few minutes after making payments
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default HowToGuideSection;

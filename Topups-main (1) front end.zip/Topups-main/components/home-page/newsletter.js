import Image from "next/image";

import MailBoxSvg from "../../assets/svg/mailbox.svg";
import Button from "../ui/button";
import Container from "../ui/container";

function NewsLetter() {
  return (
    <section>
      <div className="w-full shadow bg-gray-800 py-6 px-6">
        <Container>
          <div className="max-w-6xl m-auto grid grid-flow-row grid-cols-1 md:grid-cols-2">
            <div className="py-8 pt-6 px-8 flex items-center">
              <div>
                <h2 className="text-3xl leading-tight text-white font-medium mb-6">
                  Sign up for top-up promotions
                </h2>
                <p className="text-lg leading-relaxed text-gray-300 mb-7">
                  We'll let you know about significant promotional updates so
                  you can buy at the best time
                </p>
              </div>
            </div>
            <div className="py-8 px-8 flex flex-col justify-center items-center">
              <div className="flex flex-row flex-wrap items-center">
                <div className="w-full lg:w-4/6">
                  <input
                    type="email"
                    placeholder="Email"
                    className="h-12 w-full px-4 rounded ring-1 ring-gray-300 ring-opacity-95 focus:outline-none shadow-inner bg-gray-100 focus:bg-gray-200"
                  />
                </div>
                <div className="w-full lg:w-2/6">
                  <button className="w-full lg:w-32 mt-5 lg:mt-0 lg:ml-4 rounded px-4 py-3 shadow-lg bg-red-500 hover:bg-red-600 focus:drop-shadow-lg">
                    <span className="text-xl font-semibold text-gray-50">
                      Sign Up
                    </span>
                  </button>
                </div>
              </div>
              <p className="text-sm mt-3 text-gray-200">We well never spam your inbox with promotional messages</p>
            </div>
          </div>
        </Container>
      </div>
    </section>
  );
}

export default NewsLetter;

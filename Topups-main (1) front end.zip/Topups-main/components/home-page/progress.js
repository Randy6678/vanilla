import Image from "next/image";

import UnderContructionSvg from "../../assets/svg/under_construction.svg";

function Progress() {
  return (
    <section className="py-12">
      <div className="px-5 lg:px-0 mb-5">
        <div className="max-w-5xl mx-auto py-14 px-8 bg-white border border-black border-opacity-10 shadow-lg rounded-xl">
          <div className="flex flex-row flex-wrap">
            <div className="w-full lg:w-1/2 py-8 px-4">
              <Image
                src={UnderContructionSvg}
                alt="Mobile app under construction image"
              />
            </div>
            <div className="w-full lg:w-1/2 py-8 px-2">
              <h2 className="text-3xl font-semibold mb-6">
                Mobile App Under Contruction
              </h2>
              <h4 className="text-xl font-medium mb-6">
                Our mobile up is coming up soon
              </h4>
              <p className="leading-8 text-gray-500 mb-6">
                Join the waiting list. Let's us notify you when the app is live
              </p>
              <div>
                <input
                  type="email"
                  className="h-12 w-full px-4 rounded-md ring-2 ring-black ring-opacity-10 focus:outline-none shadow-inner bg-gray-50 focus:bg-gray-100"
                />
                <button className="w-full mt-5 rounded px-4 py-3 border-b-4 border-l-2 shadow-lg bg-gray-700 border-gray-800">
                  <span className="text-xl font-bold text-gray-50">
                    Join Wait List
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Progress;

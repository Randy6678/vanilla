// react
import { Fragment, useEffect, useState } from "react";
// next
import Image from "next/image";
import { useRouter } from "next/router";

// components
import Container from "../ui/container";
import CountriesDropdown from "../ui/forms/controls/countriesDropdown";

// hooks
import useGetSupportedCountries from "../../hooks/useGetSupportedCountries";

// assets
import WorldConnectedSvg from "../../assets/svg/connected.svg";

function SendTopupSection() {
  const [selectedCountry, setSelectedCountry] = useState("");
  const [supportedCountries, setSupportedCountries] = useState([]);

  const { loading, error, data } = useGetSupportedCountries();

  console.log("query loading", loading);
  console.log("query error", error);
  console.log("query data", data);

  const router = useRouter();

  useEffect(() => {
    if (data?.GetCountries) {
      const {
        GetCountries: { Items },
      } = data;
      const countriesIsos = Items.map((item) => item.CountryIso);
      setSupportedCountries(countriesIsos);
    }
  }, [data]);

  function handleOnSelectCountry(value) {
    setSelectedCountry(value);
  }

  function handleSubmitCountry() {
    router.push(`/send-topup?country=${selectedCountry}`);
  }

  return (
    <section>
      <Container>
        <div className="my-16 lg:my-24">
          <div className="max-w-5xl mx-auto px-2 py-6 lg:py-14 md:px-8 bg-white border border-black border-opacity-10 shadow-lg rounded-xl">
            <div className="flex flex-row flex-wrap">
              <div className="hidden lg:block w-full lg:w-1/2 py-8 px-6">
                <Image
                  src={WorldConnectedSvg}
                  alt="Mobile app under construction image"
                />
              </div>
              <div className="w-full lg:w-1/2 py-8 px-5 text-center lg:text-left">
                {loading ? (
                  <Fragment>
                    <div
                      className="w-11/12 h-8 mb-8 rounded bg-gray-200"
                      data-placeholder
                    />

                    <div
                      className="w-7/12 h-5 mb-6 rounded bg-gray-200"
                      data-placeholder
                    />

                    <div
                      className="w-5/12 h-7 mb-8 rounded bg-gray-200"
                      data-placeholder
                    />

                    <div>
                      <div
                        className="w-full h-12 rounded bg-gray-200"
                        data-placeholder
                      />
                      <div
                        className="w-full h-14 mt-8 rounded px-4 py-3 bg-gray-200"
                        data-placeholder
                      />
                    </div>
                  </Fragment>
                ) : (
                  <Fragment>
                    <h2 className="text-2xl text-gray-900 font-semibold leading-tight mb-8">
                      Where are you sending{" "}
                      <b className="text-red-500">Topup</b> to ?
                    </h2>
                    <h5 className="text-base text-gray-900 font-semibold leading-tight mb-6">
                      Send Topup to over 160+ counties
                    </h5>
                    <p className="text-lg font-norma leading-relaxed text-gray-600 mb-8">
                      Browse Countries
                    </p>
                    <div>
                      <CountriesDropdown
                        selectedCountry={selectedCountry}
                        onCountrySelection={handleOnSelectCountry}
                        countries={supportedCountries}
                      />
                      <button
                        className="w-full mt-8 rounded px-4 py-3 bg-red-500 hover:bg-red-600 hover:shadow disabled:bg-gray-400 disabled:cursor-not-allowed"
                        disabled={!selectedCountry}
                        onClick={handleSubmitCountry}
                      >
                        <span className="text-xl font-semibold text-gray-50">
                          Continue
                        </span>
                      </button>
                    </div>
                  </Fragment>
                )}
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export default SendTopupSection;

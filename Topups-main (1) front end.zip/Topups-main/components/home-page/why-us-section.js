/* This example requires Tailwind CSS v2.0+ */
import {
  AnnotationIcon,
  GlobeAltIcon,
  LightningBoltIcon,
  ScaleIcon,
  LockClosedIcon,
  CashIcon
} from "@heroicons/react/outline";

const features = [
  {
    name: "Worldwide Mobile Operator Covarage",
    description:
      "We support sending topup to almost all mobile opeators worldwide. With us you can send mobile topup to anyone anywhere",
    icon: GlobeAltIcon,
  },
  {
    name: "No hidden fees",
    description:
      "Know exactly the full amount your recipient will receive at checkout",
    icon: ScaleIcon,
  },
  {
    name: "Instant digital deliveries",
    description:
      "Our topup transfers are instant, You’ll be able to use your digital credit within seconds",
    icon: LightningBoltIcon,
  },
  {
    name: "Mobile notifications",
    description:
      "Recipient receives an instant notification on the topup and the sender",
    icon: AnnotationIcon,
  },
  {
    name: "Pay securely",
    description: "Your funds are protected by the industry’s leading payment processors",
    icon: LockClosedIcon
  },
  {
    name: "Your preferred payment method",
    description: "Choose from a wide range of payment options",
    icon: CashIcon
  },
];

import Container from "../ui/container";

function WhyUsSection() {
  return (
    <section>
      <Container>
        <div className="my-16 lg:my-24 py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">
                Why Us
              </h2>
              <p className="mt-2 text-2xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-3xl">
                Why buy topups from BuyTopups.com
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                There’s no faster, safer place to buy mobile topups
              </p>
            </div>

            <div className="mt-10">
              <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
                {features.map((feature) => (
                  <div key={feature.name} className="relative">
                    <dt>
                      <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-red-500 text-white">
                        <feature.icon className="h-6 w-6" aria-hidden="true" />
                      </div>
                      <p className="ml-16 text-lg leading-6 font-medium text-gray-900">
                        {feature.name}
                      </p>
                    </dt>
                    <dd className="mt-2 ml-16 text-base text-gray-500">
                      {feature.description}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export default WhyUsSection;

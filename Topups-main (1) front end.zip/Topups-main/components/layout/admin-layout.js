import { useRouter } from "next/router";

import Container from "../ui/container";
import CustomLink from "../ui/custom-link";

function AdminLayout(props) {
  const { pathname } = useRouter();
  console.log(pathname);

  return (
    <section className="bg-gray-50">
      <div className="pt-32" />
      <div className="relative w-full px-2 sm:px-0">
        {/* Tabs Area */}
        <div className="w-full">
          <Container>
            <div className="w-full flex flex-wrap md:flex-nowrap px-1 py-1.5 gap-2 bg-white rounded-xl top-10 drop-shadow">
              <CustomLink
                href="/dashboard"
                className={`${ pathname == "/dashboard" ? "bg-red-100 font-bold text-gray-700 shadow" : "font-medium text-gray-400 hover:bg-red-100/40 hover:text-gray-500" } w-full py-3 px-3 text-center leading-5 rounded-lg focus:outline-none focus:ring-2 ring-offset-2 ring-offset-blue-400 ring-white ring-opacity-60 `}
              >
                Dashboard
              </CustomLink>
              <CustomLink
                href="/dashboard/history"
                className={`${ pathname == "/dashboard/history" ? "bg-red-100 font-bold text-gray-700 shadow" : "font-medium text-gray-400 hover:bg-red-100/40 hover:text-gray-500" } w-full py-3 px-3 text-center leading-5 rounded-lg focus:outline-none focus:ring-2 ring-offset-2 ring-offset-blue-400 ring-white ring-opacity-60 `}
              >
                History
              </CustomLink>
              <CustomLink
                href="/dashboard/contacts"
                className={`${ pathname == "/dashboard/contacts" ? "bg-red-100 font-bold text-gray-700 shadow" : "font-medium text-gray-400 hover:bg-red-100/40 hover:text-gray-500" } w-full py-3 px-3 text-center leading-5 rounded-lg focus:outline-none focus:ring-2 ring-offset-2 ring-offset-blue-400 ring-white ring-opacity-60 `}
              >
                Contacts
              </CustomLink>
              <CustomLink
                href="/dashboard/profile"
                className={`${ pathname == "/dashboard/profile" ? "bg-red-100 font-bold text-gray-700 shadow" : "font-medium text-gray-400 hover:bg-red-100/40 hover:text-gray-500" } w-full py-3 px-3 text-center leading-5 rounded-lg focus:outline-none focus:ring-2 ring-offset-2 ring-offset-blue-400 ring-white ring-opacity-60 `}
              >
                Profile
              </CustomLink>
            </div>
          </Container>
        </div>
      </div>
      {/* Panels Area */}
      <div className="mt-10 pb-20">
        <Container>
          <div className="min-h-screen py-8 px-3 sm:px-4 md:px-8 rounded-xl drop-shadow bg-white">
            {props.children}
          </div>
        </Container>
      </div>
    </section>
  );
}

export default AdminLayout;

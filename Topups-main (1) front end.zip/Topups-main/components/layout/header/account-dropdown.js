import { Fragment } from "react";

import { Menu, Transition } from "@headlessui/react";
import {
  ChevronDownIcon,
  LoginIcon,
  UserAddIcon,
} from "@heroicons/react/solid";

import CustomLink from "../../ui/custom-link";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

function AccountDropdown(props) {
  return (
    <Menu as="li" className="relative">
      <Menu.Button className="flex flex-row items-center rounded-md border border-gray-300 text-gray-700 shadow-sm px-3 py-2 bg-white hover:bg-gray-50 focus:outline-none focus:shadow">
        <span className="font-medium">My Account</span>
        <ChevronDownIcon className="w-5 h-5 -mr-1 ml-2" />
      </Menu.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1"
      >
        <Menu.Items className="origin-top-right absolute z-10 right-0 mt-2 w-52 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1">
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/login"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <LoginIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Login
                </CustomLink>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/signup"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <UserAddIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Signup
                </CustomLink>
              )}
            </Menu.Item>
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}

export default AccountDropdown;

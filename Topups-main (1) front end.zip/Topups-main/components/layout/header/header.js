import { useEffect, useRef } from "react";

import { useRouter } from "next/router";

import {
  firebaseApp,
  firebaseAuth,
} from "../../../services/firebaseClient.service";
import { useAuth } from "../../../context/authContext";

import Logo from "./logo";
import NavLink from "../../ui/nav-link";
import { MenuIcon } from "../../ui/svg";
import UserAvatarDropdown from "./user-avatar-dropdown";
import AccountDropdown from "./account-dropdown";

function MainHeader(props) {
  const { onOpenNav, onDismissNav } = props;
  const headerRef = useRef();

  const router = useRouter();

  const { pathname } = router;
  const {
    state: { user, checkingAuth },
    dispatch,
  } = useAuth();

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
  }, []);

  // the function to call when the user scrolls, added as a method
  function handleScroll() {
    const classTokens = [
      "fixed",
      "z-30",
      "transition-all",
      "duration-500",
      "ease-in",
      "-top-32",
      "translate-y-32",
      "shadow",
      "bg-gray-50",
      "backdrop-filter",
      "backdrop-blur",
      "md:bg-opacity-90",
      "firefox:bg-opacity-90",
    ];
    if (window.pageYOffset > 0) {
      // user is scrolled
      if (headerRef.current) headerRef.current.classList.add(...classTokens);
    } else {
      // user is at top of page
      if (headerRef.current) headerRef.current.classList.remove(...classTokens);
    }
  }

  async function handleLogout() {
    await firebaseAuth.getAuth(firebaseApp).signOut();
    dispatch({
      type: "LOGOUT",
    });
    // router.push("/login");
  }

  return (
    <header
      className="header py-6 bg-gray-100 w-full"
      ref={headerRef}
    >
      {/* container */}
      <div className="container px-4 sm:px-8 lg:px-16 xl:px-20 mx-auto">
        {/* header wrapper */}
        <div className="header-wrapper flex items-center justify-between">
          {/* header logo */}
          <div className="header-logo">
            <Logo />
          </div>

          {/* mobile toggle */}
          <div className="toggle lg:hidden">
            <button onClick={onOpenNav} onKeyDown={onDismissNav}>
              <MenuIcon />
            </button>
          </div>

          {/* Navbar */}
          <nav className="navbar hidden lg:block">
            <ul className="flex space-x-8 items-center text-sm font-semibold">
              <li>
                <NavLink
                  href="/about-us"
                  className={`${
                    pathname == "/about-us"
                      ? "active border-b-2 border-red-500 pb-2"
                      : null
                  } hover:text-red-500`}
                >
                  About Us
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/help-center"
                  className={`${
                    pathname == "/help-center"
                      ? "active border-b-2 border-red-500 pb-2"
                      : null
                  } hover:text-red-500`}
                >
                  Help Center
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/partners"
                  className={`${
                    pathname == "/partners"
                      ? "active border-b-2 border-red-500 pb-2"
                      : null
                  } hover:text-red-500`}
                >
                  Partners
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/contact-us"
                  className={`${
                    pathname == "/contact-us"
                      ? "active border-b-2 border-red-500 pb-2"
                      : null
                  } hover:text-red-500`}
                >
                  Contact
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/send-topup"
                  className="cta bg-red-500 hover:bg-red-600 px-3 py-2 rounded text-white font-semibold"
                >
                  Send Topup
                </NavLink>
              </li>
              {checkingAuth ? (
                <li>
                  <a
                    className="cta w-32 bg-gray-200 px-3 py-2 rounded text-white font-semibold animate-pulse"
                    style={{height: 38}}
                  >
                    <span className="invisible">Loading......</span>
                  </a>
                </li>
              ) : user ? (
                <UserAvatarDropdown onLogout={handleLogout} user={user} />
              ) : (
                <AccountDropdown />
              )}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default MainHeader;

// Next Imports
import Link from "next/link";

function Logo() {
  return (
    <h1 className="font-semibold text-black leading-relaxed">
      <Link href="/">
        <a>BuyTopup.com</a>
      </Link>
    </h1>
  );
}

export default Logo;

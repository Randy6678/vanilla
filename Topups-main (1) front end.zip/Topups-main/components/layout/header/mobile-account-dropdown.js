import { Fragment } from "react";
import PropTypes from "prop-types";

import { Menu, Transition } from "@headlessui/react";
import {
  ChevronUpIcon,
  ChevronDownIcon,
  LoginIcon,
  UserAddIcon,
} from "@heroicons/react/solid";

import CustomLink from "../../ui/custom-link";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

function MobileAccountDropdown(props) {
  const { user, onLogout } = props;

  return (
    <Menu as="li" className="relative">
      {({ open }) => (
        <Fragment>
          <Menu.Button className="flex flex-row w-full items-center my-4 hover:text-red-500">
            <span className="font-normal">My Account</span>
            {open ? (
              <ChevronUpIcon className="w-5 h-5 -mr-1 ml-2" />
            ) : (
              <ChevronDownIcon className="w-5 h-5 -mr-1 ml-2" />
            )}
          </Menu.Button>

          {open && (
            <Transition
              as={Fragment}
              enter="transition ease-out duration-200"
              enterFrom="opacity-0 translate-y-1"
              enterTo="opacity-100 translate-y-0"
              leave="transition ease-in duration-150"
              leaveFrom="opacity-100 translate-y-0"
              leaveTo="opacity-0 translate-y-1"
            >
              <Menu.Items className="mt-2 w-full rounded-md bg-white focus:outline-none px-2">
                <hr />
                <div className="py-1">
                  <Menu.Item>
                    {({ active }) => (
                      <CustomLink
                        href="/dashboard"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900 font-semibold"
                            : "text-gray-700",
                          "flex flex-row items-center px-4 py-2 text-sm font-normal"
                        )}
                      >
                        <LoginIcon className="w-4 h-4 mr-2 text-gray-500" />
                        Login
                      </CustomLink>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <CustomLink
                        href="/dasboard/history"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900 font-semibold"
                            : "text-gray-700",
                          "flex flex-row items-center px-4 py-2 text-sm font-normal"
                        )}
                      >
                        <UserAddIcon className="w-4 h-4 mr-2 text-gray-500" />
                        Signup
                      </CustomLink>
                    )}
                  </Menu.Item>
                </div>
              </Menu.Items>
            </Transition>
          )}
        </Fragment>
      )}
    </Menu>
  );
}

MobileAccountDropdown.propTypes = {
  onLogout: PropTypes.func,
  user: PropTypes.object,
};

export default MobileAccountDropdown;

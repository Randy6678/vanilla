import { Fragment } from "react";
import { useRouter } from "next/router";
import { Dialog, Transition } from "@headlessui/react";
import {
  CloseIcon,
  FacebookIcon,
  InstagramIcon,
  TwitterIcon,
  YoutubeIcon,
} from "../../ui/svg";

import {
  firebaseApp,
  firebaseAuth,
} from "../../../services/firebaseClient.service";
import { useAuth } from "../../../context/authContext";

import NavLink from "../../ui/nav-link";
import MobileUserDropdown from "./mobile-user-dropdown";
import MobileAccountDropdown from "./mobile-account-dropdown";

function MobileNav(props) {
  // implement on click outside for this component
  const { isOpen, onCloseNav } = props;

  const router = useRouter();
  const { pathname } = router;
  const {
    state: { user, checkingAuth },
    dispatch,
  } = useAuth();

  async function handleLogout() {
    await firebaseAuth.getAuth(firebaseApp).signOut();
    dispatch({
      type: "LOGOUT",
    });
  }

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        static
        className="fixed z-50 inset-0 overflow-y-auto"
        // initialFocus={initialFocus}
        open={isOpen}
        onClose={onCloseNav}
      >
        {/* Dialog Dackdrop */}
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <Dialog.Overlay className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>

        {/* mobile Nav */}
        <div className="mobile-navbar">
          {/* navbar wrapper */}
          <Transition.Child
            className="navbar-wrapper fixed top-0 left-0 h-full bg-white z-30 w-64 shadow-lg p-5"
            // show={isOpen}
            enter="transition duration-300 -ml-64"
            enterFrom=""
            enterTo="transform translate-x-64"
            leave="transition duration-300"
            leaveFrom=""
            leaveTo="transform -translate-x-64"
          >
            <div className="close">
              <button
                className="absolute top-0 right-0 mt-4 mr-4"
                onClick={onCloseNav}
              >
                <CloseIcon />
              </button>
            </div>
            <ul className="divide-y">
              {checkingAuth ? (
                <li>
                  <NavLink
                    href="/about-us"
                    className={`${
                      pathname == "/about-us" ? "font-bold text-red-500" : null
                    } my-4 inline-block hover:text-red-500`}
                  >
                    Loading...
                  </NavLink>
                </li>
              ) : user ? (
                <MobileUserDropdown onLogout={handleLogout} user={user} />
              ) : (
                <MobileAccountDropdown />
              )}
              <li>
                <NavLink
                  href="/about-us"
                  className={`${
                    pathname == "/about-us" ? "font-bold text-red-500" : null
                  } my-4 inline-block hover:text-red-500`}
                >
                  About us
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/help-center"
                  className={`${
                    pathname == "/help-center" ? "font-bold text-red-500" : null
                  } my-4 inline-block hover:text-red-500`}
                >
                  Help Center
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/partners"
                  className={`${
                    pathname == "/partners" ? "font-bold text-red-500" : null
                  } my-4 inline-block hover:text-red-500`}
                >
                  Partners
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/contact-us"
                  className={`${
                    pathname == "/contact-us" ? "font-bold text-red-500" : null
                  } my-4 inline-block hover:text-red-500`}
                >
                  Contact
                </NavLink>
              </li>
              <li>
                <NavLink
                  href="/send-topup"
                  className="my-8 w-full text-center cta inline-block bg-red-500 hover:bg-red-600 px-3 py-2 rounded text-white font-semibold"
                >
                  Send Topup
                </NavLink>
              </li>
            </ul>

            {/* follow us */}
            <div className="follow">
              <p className=" italic font-semibold">follow us:</p>
              <div className="social flex space-x-5 mt-4 ">
                <a href="#">
                  <TwitterIcon />
                </a>
                <a href="#">
                  <FacebookIcon />
                </a>
                <a href="#">
                  <InstagramIcon />
                </a>
                <a href="#">
                  <YoutubeIcon />
                </a>
              </div>
            </div>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition.Root>
  );
}

export default MobileNav;

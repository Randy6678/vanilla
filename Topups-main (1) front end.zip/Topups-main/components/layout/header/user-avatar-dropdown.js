import { Fragment } from "react";
import PropTypes from "prop-types";

import { Menu, Transition } from "@headlessui/react";
import {
  ChevronDownIcon,
  HomeIcon,
  ArchiveIcon,
  UserGroupIcon,
  UserCircleIcon,
  LogoutIcon,
} from "@heroicons/react/solid";

import CustomLink from "../../ui/custom-link";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

function UserAvatarDropdown(props) {
  const { user, onLogout } = props;

  return (
    <Menu as="li" className="relative">
      <Menu.Button className="flex flex-row items-center rounded-md border border-gray-300 text-gray-700 shadow-sm px-3 py-2 bg-white hover:bg-gray-50 focus:outline-none focus:shadow">
        <span className="font-medium">My Account</span>
        <ChevronDownIcon className="w-5 h-5 -mr-1 ml-2" />
      </Menu.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1"
      >
        <Menu.Items className="origin-top-right absolute z-10 right-0 mt-2 w-60 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1 text-left">
            <div className="px-4 py-3">
              <h4 className="text-md text-gray-800 my-1 font-semibold leading-relaxed capitalize">
                {user.name}
              </h4>
              <h5 className="text-sm text-gray-600 mb-1 font-normal">
                {user.email}
              </h5>
            </div>
          </div>
          <hr />
          <div className="py-1">
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/dashboard"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <HomeIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Dashboard
                </CustomLink>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/dashboard/history"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <ArchiveIcon className="w-4 h-4 mr-2 text-gray-500" />
                  History
                </CustomLink>
              )}
            </Menu.Item>
          </div>
          <div className="py-1">
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/dashboard/contacts"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <UserGroupIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Contacts
                </CustomLink>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <CustomLink
                  href="/dashboard/profile"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-semibold"
                      : "text-gray-700",
                    "flex flex-row items-center px-4 py-2 text-sm font-normal"
                  )}
                >
                  <UserCircleIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Profile
                </CustomLink>
              )}
            </Menu.Item>
          </div>
          <div className="py-1">
            <Menu.Item>
              {({ active }) => (
                <button
                  onClick={onLogout}
                  role="button"
                  className={classNames(
                    active
                      ? "bg-gray-100 text-gray-900 font-bold"
                      : "text-gray-700",
                    "flex flex-row items-center w-full text-left px-4 py-2 text-sm font-medium"
                  )}
                >
                  <LogoutIcon className="w-4 h-4 mr-2 text-gray-500" />
                  Sign out
                </button>
              )}
            </Menu.Item>
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}

UserAvatarDropdown.propTypes = {
  onLogout: PropTypes.func,
  user: PropTypes.object,
};

export default UserAvatarDropdown;

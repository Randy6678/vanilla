import { useState } from "react";

import { useRouter } from "next/router";

import MainHeader from "./header/header";
import Footer from "./footer/main-footer";
import MobileNav from "./header/mobileNav";
import AuthFooter from "./footer/auth-footer";

const footerExceptionPaths = ["/login", "/signup"];

function Layout(props) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { pathname } = useRouter();

  const showFooter = !footerExceptionPaths.includes(pathname);

  function handleOpenMobileNav() {
    setMobileNavOpen(true);
  }

  function handleCloseMobileNav() {
    setMobileNavOpen(false);
  }

  function handleNavCloseWithEsc(event) {
    const keyPressedCode = event.which;

    if (keyPressedCode == 27) {
      setMobileNavOpen(false);
    }
  }

  return (
    <div
      className="bg-gray-50 min-h-screen"
      style={{ display: "grid", gridTemplateRows: "auto 1fr auto" }}
    >
      {/* <Navigation /> */}
      <div>
        <MainHeader
          onOpenNav={handleOpenMobileNav}
          onDismissNav={handleNavCloseWithEsc}
        />
        {/* <div style={{ height: "86px" }} /> */}
        <MobileNav isOpen={mobileNavOpen} onCloseNav={handleCloseMobileNav} />
      </div>
      <main>{props.children}</main>
      {showFooter ? <Footer /> : <AuthFooter />}
    </div>
  );
}

export default Layout;

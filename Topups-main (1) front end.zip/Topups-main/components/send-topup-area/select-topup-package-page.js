// react
import { useState, useRef, useEffect } from "react";

// next
import { useRouter } from "next/router";
// react toast
import { toast } from "react-toastify";
// axios
import axios from "axios";

// context
import { useAuth } from "../../context/authContext";

// components
import Container from "../ui/container";
import TopupPackage from "./topupPackage";
import Modal from "../ui/modal";
import CloseIcon from "../ui/svg/closeIcon";
import EstimateInput from "../ui/forms/controls/estimateInput";

// hooks
import useGetProductsForProvider from "../../hooks/useGetProductsForProvider";

function SelectTopUpPackage(props) {
  const [providerInfo, setProviderInfo] = useState({});
  const [availableProducts, setAvailableProducts] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [activeModalData, setActiveModalData] = useState();

  const router = useRouter();
  const {
    state: { user },
  } = useAuth();

  const sendAmountInputRef = useRef(null);
  const receiveAmountInputRef = useRef(null);

  const { country, prov, actNo } = router.query;

  const { loading, error, data } = useGetProductsForProvider(
    country ? country.toUpperCase() : props.country.toUpperCase(),
    prov ?? props.prov,
  );

  useEffect(() => {
    if (data?.GetProducts && data?.GetProviders) {
      const {
        GetProducts: { Items },
        GetProviders: { Items: ProviderItems },
      } = data;

      const provider = ProviderItems.find((item) => item.ProviderCode == prov);

      const products = Items.map((item) => {
        let product = {
          Benefits: item.Benefits,
          CommissionRate: item.CommissionRate,
          DefaultDisplayText: item.DefaultDisplayText,
          LocalizationKey: item.LocalizationKey,
          LookupBillsRequired: item.LookupBillsRequired,
        };

        if (item.Minimum.ReceiveValue == item.Maximum.ReceiveValue) {
          product = {
            ...product,
            ...item.Maximum,
            ProductValueVaries: false,
            TotalChargeFee:
              item.Maximum.SendValue +
              item.Maximum.CustomerFee +
              item.Maximum.DistributorFee,
          };
        } else {
          product = {
            ...product,
            CustomerFee: null,
            DistributorFee: null,
            ReceiveCurrencyIso: item.Maximum.ReceiveCurrencyIso,
            SendCurrencyIso: item.Maximum.SendCurrencyIso,
            MinSendValue: item.Minimum.SendValue,
            MaxSendValue: item.Maximum.SendValue,
            MinReceiveValue: item.Minimum.ReceiveValue,
            MaxReceiveValue: item.Maximum.ReceiveValue,
            ProductValueVaries: true,
            TotalChargeFee: null,
          };
        }

        product = {
          ...product,
          PaymentTypes: item.PaymentTypes,
          ProcessingMode: item.ProcessingMode,
          ProviderCode: item.ProviderCode,
          RedemptionMechanism: item.RedemptionMechanism,
          RegionCode: item.RegionCode,
          SettingDefinitions: item.SettingDefinitions,
          SkuCode: item.SkuCode,
          UatNumber: item.UatNumber,
          ValidityPeriodIso: item.ValidityPeriodIso,
        };

        return product;
      });

      setProviderInfo(provider);
      setAvailableProducts(products);
    }
  }, [data]);

  const productsPlaceholder = new Array("1", "2", "3", "4");

  if (error) return <p>Error :(</p>;

  if (data) console.log(data);

  function handleOpenModal() {
    setOpenModal(true);
  }

  function handleCloseModal() {
    setOpenModal(false);
  }

  function handleUpdateModalContent(content) {
    setActiveModalData(content);
  }

  async function handleContinue() {
    const sendInputValue = sendAmountInputRef.current?.value;
    const receiveInputValue = receiveAmountInputRef.current?.value;
    console.log(sendInputValue, receiveInputValue);
    let issuesFound =
      !Number(sendInputValue) ||
      sendInputValue < activeModalData?.minSendAmount ||
      sendInputValue > activeModalData?.maxSendAmount ||
      !Number(receiveInputValue) ||
      receiveInputValue < activeModalData?.minReceiveAmount ||
      receiveInputValue > activeModalData?.maxReceiveAmount;

    if (!issuesFound) {
      console.log(providerInfo)
      try {
        console.log(activeModalData)
        // create the order in db and redirect to summary page
        const orderResponse = await axios.post(
          `${process.env.backendUrl}/api/orders`,
          {
            countryIso: country.toUpperCase(),
            providerCode: providerInfo.ProviderCode,
            productSkuCode: activeModalData.skuCode,
            productSendAmount: sendInputValue,
            productReceiveAmount: receiveInputValue,
            accountNumber: actNo,
            providerLogo: providerInfo.LogoUrl,
            providerName: providerInfo.Name,
          }
        );
        const orderData = orderResponse.data;

        if (!orderData) {
          toast.error("Error creating order", {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
          });
          return;
        }

        router.push(`/summary/${orderData.id}`);
      } catch (error) {
        console.log("error", error.response);
        toast.error("Error creating order", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    } else {
      setOpenModal(false);
      toast.error("Invalid Send or Receive Amount", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
    }
  }

  function estimateSendValue(data) {
    sendAmountInputRef.current.value = data.Price.SendValue;
  }

  function estimateReceiveValue(data) {
    receiveAmountInputRef.current.value = data.Price.ReceiveValue;
  }

  return (
    <section>
      <Container>
        <div className="my-20 lg:my-28 bg-white">
          <div className="py-12 px-4 sm:px-8 lg:px-14 ring-1 ring-black ring-opacity-10 rounded-md sm:rounded-lg shadow-md sm:shadow-lg ">
            <div className="bg-white px-6 py-4 mx-auto">
              <h2 className="font-bold text-md md:text-xl lg:text-2xl text-gray-900 text-center leading-tight mb-8">
                Choose your preferred{" "}
                <span className="text-red-500">topup package</span>
              </h2>

              {loading && (
                <div
                  className="mx-auto w-72 h-10 bg-gray-200 rounded"
                  data-placeholder
                />
              )}

              <div className="flex justify-center items-center mb-10">
                {providerInfo?.LogoUrl && (
                  <img
                    src={providerInfo.LogoUrl}
                    alt={providerInfo.Name}
                    width={50}
                    height={50}
                    className="mr-2"
                  />
                )}
                <h3 className="text-md font-bold leading-tight text-gray-900">
                  {providerInfo && providerInfo.Name}
                </h3>
              </div>

              {openModal && (
                <Modal
                  open={openModal}
                  closeModal={handleCloseModal}
                  backDropExit={false}
                  initialFocus={sendAmountInputRef}
                >
                  <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <div className="bg-white px-4 pt-5">
                      <div className="px-2 flex items-center w-full">
                        <div className="text-gray-900 font-bold text-lg">
                          Flexible Option Package
                        </div>
                        <button onClick={handleCloseModal} className="ml-auto">
                          <CloseIcon classes="text-gray-700 w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    <div className="px-5 pt-7 py-6">
                      <h3 className="text-lg text-gray-800 text-center capitalize font-light leading-tight mb-2">
                        How much do you want to send to recipient
                      </h3>
                      <p className="text-sm text-gray-700 text-center capitalize font-medium">
                        Enter amount between:{" "}
                        <b>
                          {activeModalData.receiveCurrency}{" "}
                          {activeModalData.minReceiveAmount} -{" "}
                          {activeModalData.maxReceiveAmount}
                        </b>
                      </p>
                      <EstimateInput
                        labelText="Send Amount"
                        placeholder="0.00"
                        value={activeModalData.minSendAmount}
                        minValue={activeModalData.minSendAmount}
                        maxValue={activeModalData.maxSendAmount}
                        name="sendAmount"
                        currency={activeModalData.payCurrency}
                        onPriceEstimated={estimateReceiveValue}
                        inputRef={sendAmountInputRef}
                        packageCode={activeModalData.skuCode}
                        estimateType="SENDING"
                      />
                      <EstimateInput
                        labelText="Receive Amount"
                        placeholder="0.00"
                        value={activeModalData.minReceiveAmount}
                        minValue={activeModalData.minReceiveAmount}
                        maxValue={activeModalData.maxReceiveAmount}
                        name="receiveAmount"
                        currency={activeModalData.receiveCurrency}
                        onPriceEstimated={estimateSendValue}
                        inputRef={receiveAmountInputRef}
                        packageCode={activeModalData.skuCode}
                        estimateType="RECEIVING"
                      />
                    </div>
                    <hr className="w-full" />
                    <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse justify-center">
                      <button
                        type="button"
                        className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm disabled:bg-gray-500 disabled:cursor-not-allowed"
                        disabled={false}
                        onClick={handleContinue}
                      >
                        Continue
                      </button>
                      <button
                        type="button"
                        className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                        onClick={handleCloseModal}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </Modal>
              )}

              <div className="flex flex-row flex-wrap justify-center gap-8">
                {loading
                  ? productsPlaceholder.map((placeholder) => (
                      <div
                        key={placeholder}
                        className="w-72 h-48 bg-gray-200 rounded-md"
                        data-placeholder
                      />
                    ))
                  : availableProducts.map((product) => (
                      <TopupPackage
                        key={product.LocalizationKey}
                        details={{
                          desc: product.DefaultDisplayText,
                          perks: product.Benefits,
                          receiveAmount: product.ProductValueVaries
                            ? null
                            : product.ReceiveValue,
                          receiveCurrency: product.ReceiveCurrencyIso,
                          totalPayAmount: product.ProductValueVaries
                            ? null
                            : product.TotalChargeFee,
                          payCurrency: product.SendCurrencyIso,
                          varies: product.ProductValueVaries,
                          minReceiveAmount: product.ProductValueVaries
                            ? product.MinReceiveValue
                            : product.ReceiveValue,
                          maxReceiveAmount: product.ProductValueVaries
                            ? product.MaxReceiveValue
                            : product.ReceiveValue,
                          minSendAmount: product.ProductValueVaries
                            ? product.MinSendValue
                            : product.SendValue,
                          maxSendAmount: product.ProductValueVaries
                            ? product.MaxSendValue
                            : product.SendValue,
                          providerCode: providerInfo.ProviderCode,
                          providerName: providerInfo.Name,
                          providerLogo: providerInfo.LogoUrl,
                          skuCode: product.SkuCode,
                        }}
                        openModal={handleOpenModal}
                        updateModalContent={handleUpdateModalContent}
                      />
                    ))}
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export default SelectTopUpPackage;

// react
import { useEffect, useState } from "react";
// next
import { useRouter } from "next/router";

// components
import Container from "../ui/container";
import MobilePhoneInput from "../ui/forms/controls/mobileNumberInput";
import MobileOperatorSelect from "../ui/forms/controls/mobileOperatorSelect";

function TopUpPage() {
  // get initial selected country, selected provider, phone number from router
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedProvider, setSelectedProvider] = useState();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [optionalCountryInfo, setOptionalCountryInfo] = useState();

  const router = useRouter();

  const { country, accNo } = router.query;

  useEffect(() => {
    // console.log(country);
    if (country && country.trim()) setSelectedCountry(country);
    if (accNo && accNo.trim()) setPhoneNumber(accNo);
  }, [country, accNo]);

  function handleOnChange(value, data, event, formattedValue) {
    setPhoneNumber(value);
    setSelectedCountry(data.countryCode);
    // console.log(data);
  }

  function handleOnSelectProvider(value) {
    // console.log(value);
    setSelectedProvider(value);
  }

  function handleSubmit() {
    router.push(
      `/send-topup/select-package?country=${selectedCountry}&prov=${selectedProvider.code}&actNo=${phoneNumber}`
    );
  }

  return (
    <section>
      <Container>
        <div className="my-20 lg:my-28 bg-white">
          <div className="py-12 px-4 sm:px-8 lg:px-14 ring-1 ring-black ring-opacity-10 rounded-md sm:rounded-lg shadow-md sm:shadow-lg ">
            <h2 className="text-2xl text-gray-900 text-center font-semibold leading-tight mb-10">
              Who are you sending <b className="text-red-500">Topup</b> to ?
            </h2>
            <div className="mb-12">
              <p className="text-lg font-norma leading-relaxed text-gray-600 mb-4">
                Enter Phone Number
              </p>
              <MobilePhoneInput
                phoneNumber={phoneNumber}
                onPhoneChange={handleOnChange}
                selectedCountry={selectedCountry}
                setOptionalCountryInfo={setOptionalCountryInfo}
              />
            </div>
            <div className="mb-12">
              <p className="text-lg font-norma leading-relaxed text-gray-600 mb-4">
                Select Mobile Operator
              </p>
              <MobileOperatorSelect
                selectedCountry={selectedCountry}
                selectedProvider={selectedProvider}
                onSelectProvider={handleOnSelectProvider}
              />
            </div>
            <div className="mb-4 lg:flex lg:justify-center">
              <button
                className="w-full lg:w-6/12 lg:mx-auto rounded px-4 py-3 bg-red-500 hover:bg-red-600 disabled:bg-gray-400 disabled:cursor-not-allowed hover:shadow"
                onClick={handleSubmit}
                disabled={
                  !selectedProvider ||
                  !phoneNumber ||
                  !selectedCountry ||
                  phoneNumber.length <
                    optionalCountryInfo.InternationalDialingInformation[0]
                      .MinimumLength ||
                  phoneNumber.length >
                    optionalCountryInfo.InternationalDialingInformation[0]
                      .MaximumLength
                }
              >
                <span className="text-xl font-semibold text-gray-50">
                  Continue
                </span>
              </button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export default TopUpPage;

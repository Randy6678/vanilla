// next
import { useRouter } from "next/router";
// react toast
import { toast } from "react-toastify";
// axios
import axios from "axios";

function TopupPackage(props) {
  const {
    details: {
      perks,
      desc,
      receiveAmount,
      receiveCurrency,
      totalPayAmount,
      minReceiveAmount,
      maxReceiveAmount,
      maxSendAmount,
      providerCode,
      providerName,
      providerLogo,
      skuCode,
      varies,
    },
    openModal,
    updateModalContent,
  } = props;

  const router = useRouter();
  const { country, prov, actNo } = router.query;

  async function handlePackageClick() {
    if (varies) {
      updateModalContent(props.details);
      openModal();
    } else {
      try {
        // create the order in db and redirect to summary page
        const orderResponse = await axios.post(
          `${process.env.backendUrl}/api/orders`,
          {
            countryIso: country.toUpperCase(),
            providerCode: providerCode,
            productSkuCode: skuCode,
            productSendAmount: maxSendAmount,
            productReceiveAmount: maxReceiveAmount,
            accountNumber: actNo,
            providerLogo: providerLogo,
            providerName: providerName,
          }
        );
        const orderData = orderResponse.data;

        if (!orderData) {
          toast.error("Error creating order", {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
          });
          return;
        }

        router.push(`/summary/${orderData.id}`);
      } catch (error) {
        console.log("error", error.response);
        toast.error("Error creating order", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    }
  }

  return (
    <button
      onClick={handlePackageClick}
      className="group w-72 text-center bg-gray-50 ring-1 ring-black ring-opacity-10 hover:cursor-pointer transition duration-300 ease-in-out shadow-sm hover:shadow-xl hover:-translate-y-1 hover:scale-110 hover:bg-white rounded-md"
    >
      <div className="py-3 px-2 border-b border-gray-100 rounded-t-md shadow">
        <h6 className="leading-tight text-md font-bold text-gray-800 group-hover:text-co">
          {desc}
        </h6>
      </div>
      <div className="py-5 px-2">
        <h5 className="leading-relaxed text-md font-medium text-gray-500">
          {varies ? "Send between:" : "Recipient gets:"}{" "}
          {varies ? (
            <b className="group-hover:text-red-500">
              {minReceiveAmount} - {maxReceiveAmount} {receiveCurrency}
            </b>
          ) : (
            <b className="group-hover:text-red-500">
              {receiveAmount} {receiveCurrency}
            </b>
          )}
        </h5>
        {perks && (
          <div className="mt-2" title="Some packages comes with perks">
            <h6 className="inline font-medium text-gray-500 mr-2">Bonus:</h6>
            <p className="inline">
              {perks.map((perk, i, { length }) => (
                <span
                  key={perk}
                  className="text-sm text-gray-500 lowercase pr-1"
                >
                  {perk}
                  {i + 1 != length ? "," : null}
                </span>
              ))}
            </p>
          </div>
        )}
      </div>
      <div className="py-2 px-2 border-t border-gray-200 rounded-b-md shadow">
        <p className="text-base leading-relaxed font-normal text-gray-500">
          Pay:{" "}
          <b className="font-bold text-gray-800 group-hover:text-red-500">
            {varies ? "To be estimated" : `$${totalPayAmount}`}
          </b>
        </p>
      </div>
    </button>
  );
}

export default TopupPackage;

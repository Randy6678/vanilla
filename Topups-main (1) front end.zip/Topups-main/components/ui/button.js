function Button(props) {
  const {buttonClasses, buttonTextClasses} = props;

  const btnClasses = `flex items-center justify-between w-full rounded px-4 py-3 m-1 mt-6 border-b-4 border-l-2 shadow-lg ${buttonClasses}`
  const btnTextClasses = `text-xl font-bold text-gray-50 ${buttonTextClasses}`

  return (
    <button className={btnClasses}>
      <span className={btnTextClasses}>{props.children}</span>
      {props.Icon && <props.Icon className="w-5 h-5 text-white fill-current" />}
    </button>
  );
}

export default Button;

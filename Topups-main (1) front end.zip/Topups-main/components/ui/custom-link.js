import Link from "next/link";

function CustomLink(props) {
  const { href, ...otherProps } = props;
  return (
    <Link href={href}>
      <a {...otherProps}>{props.children}</a>
    </Link>
  );
}

export default CustomLink;

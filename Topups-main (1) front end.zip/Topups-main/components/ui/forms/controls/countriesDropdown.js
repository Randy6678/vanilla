import PropTypes from "prop-types";
import ReactFlagsSelect from "react-flags-select";

import classes from "./countriesDropdown.module.css";



function CountriesDropdown(props) {
  const { selectedCountry, onCountrySelection, countries} = props;

  return (
    <ReactFlagsSelect
      countries={countries}
      selected={selectedCountry}
      onSelect={onCountrySelection}
      searchable
      className={[
        classes.select,
        "text-base bg-gray-50 rounded-md shadow-inner max-h-60 ring-2 ring-black ring-opacity-10 focus:outline-none sm:text-sm",
      ]}
      selectButtonClassName="border-0 bg-gray-200"
    />
  );
}

CountriesDropdown.propTypes = {
  selectedCountry: PropTypes.string,
  onCountrySelection: PropTypes.func,
  supportedCountries: PropTypes.array,
};

export default CountriesDropdown;

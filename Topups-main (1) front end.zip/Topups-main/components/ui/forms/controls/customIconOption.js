import Image from "next/image";

import { components } from "react-select";

const CustomIconOption = (props) => {
  const { data } = props;

  return (
    <components.Option {...props}>
      <div className="flex flex-row items-center">
        {data.logo && (
          <img
            src={data.logo}
            alt={data.name}
            width={30}
            height={30}
            className="mr-5"
          />
        )}
        <h5 className="text-md">{data.name}</h5>
      </div>
    </components.Option>
  );
};

export default CustomIconOption;

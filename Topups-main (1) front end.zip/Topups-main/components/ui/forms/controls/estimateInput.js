// react
import { useState, useEffect } from "react";

// hooks
import useEstimateProductPrice from "../../../../hooks/useEstimateProductPrice";

function EstimateInput(props) {
  const {
    labelText,
    placeholder,
    value,
    minValue,
    maxValue,
    name,
    currency,
    inputRef,
    onPriceEstimated,
    packageCode,
    estimateType,
  } = props;

  const [inputValue, setInputValue] = useState(value);
  const [feedback, setFeedback] = useState("");

  const [estimateProductPrice, { data, loading, error }] =
    useEstimateProductPrice();

  let typingTimer = null;

  useEffect(() => {
    if (inputValue && inputValue >= minValue && inputValue <= maxValue) {
      clearTimeout(typingTimer);

      typingTimer = setTimeout(() => {
        estimateProductPrice({
          variables: {
            sendValue: estimateType == "SENDING" ? inputValue : 0,
            receiveValue: estimateType == "RECEIVING" ? inputValue : 0,
            skuCode: packageCode,
            uniqueId: "itemUniqueId",
          },
        });
      }, 500);
    } else {
      setFeedback("Could not estimate prices for the specified value");
    }

    return () => clearTimeout(typingTimer);
  }, [inputValue]);

  useEffect(() => {
    // console.log(data);
    let estimatePrice = null;
    if (data && data.EstimatePrices?.Items?.length) {
      estimatePrice = data.EstimatePrices?.Items[0];
      onPriceEstimated(estimatePrice);

      setFeedback("");
    }

    if (error) {
      setFeedback("Something went wrong while trying to estimate prices");
      console.log("ERROR", err);
    }
  }, [data, error]);

  function blockInvalidChar(event) {
    ["e", "E", "+", "-"].includes(event.key) && event.preventDefault();
  }

  function handleValueChange(event) {
    setFeedback(null);

    const enteredValue = event.target.value ? Number(event.target.value) : "";

    if (enteredValue && enteredValue < minValue) {
      setFeedback(`Entered value cannot be less than ${minValue} ${currency}`);
      console.log(`Entered value cannot be less than ${minValue}`);
    } else if (enteredValue && enteredValue > maxValue) {
      setFeedback(`Entered value cannot be more than ${maxValue} ${currency}`);
      console.log(`Entered value cannot be more than ${maxValue}`);
    }

    if (!enteredValue || enteredValue < minValue || enteredValue > maxValue) {
      onPriceEstimated({
        Price: {
          SendValue: 0,
          ReceiveValue: 0,
        },
      });
    }

    setInputValue(enteredValue);
  }

  return (
    <div className="form-control py-2 px-2 sm:px-4 md:px-8 mt-4 mb-4">
      <label
        htmlFor="receiveAmount"
        className="block text-sm font-medium text-gray-600 mb-1"
      >
        {labelText}
      </label>
      <div className="flex items-stretch w-full relative rounded-md bg-gray-100">
        <input
          type="number"
          className="flex-shrink flex-grow flex-auto leading-normal border border-grey-light px-3 py-2 relative rounded-l-md shadow-inner focus:outline-none focus:bg-gray-50"
          maxLength={8}
          autoComplete="off"
          placeholder={placeholder}
          name={name}
          id={name}
          value={inputValue}
          onKeyDown={blockInvalidChar}
          onChange={handleValueChange}
          ref={inputRef}
        />
        <div className="flex -mr-px">
          <span className="flex items-center leading-normal bg-grey-lighter rounded rounded-l-none border border-l-0 border-grey-light px-3 whitespace-no-wrap text-grey-dark text-sm rounded-r-md">
            {currency}
          </span>
        </div>
      </div>
      {feedback && (
        <small className="text-light text-red-500">{feedback}</small>
      )}
      {loading && (
        <small className="text-light text-gray-500">Estimating...</small>
      )}
    </div>
  );
}

export default EstimateInput;

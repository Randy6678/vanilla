// react
import { useEffect } from "react";
// phone input
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

// hooks
import useGetSupportedCountries from "../../../../hooks/useGetSupportedCountries";

function MobilePhoneInput(props) {
  const {
    phoneNumber,
    onPhoneChange,
    selectedCountry,
    setOptionalCountryInfo,
  } = props;
  const { loading, error, data } = useGetSupportedCountries();

  useEffect(() => {
    if (setOptionalCountryInfo) {
      if (selectedCountry && selectedCountry.trim() && data) {
        const additionalInfo = data.GetCountries.Items.find(
          (item) => item.CountryIso == selectedCountry.toUpperCase()
        );
        setOptionalCountryInfo(additionalInfo);
      }
    }
  }, [selectedCountry, loading]);

  const currentCountry = selectedCountry ? selectedCountry.toLowerCase() : "";

  if (loading) return <div className="w-full border-2 rounded bg-gray-200 shadow-inner" data-placeholder style={{height: 50}} />;
  if (error) {
    console.log(error);
    return <p>Error :(</p>;
  }

  const {
    GetCountries: { Items },
  } = data;

  const supportedCountries = Items.map((item) => item.CountryIso.toLowerCase());

  return (
    <PhoneInput
      onlyCountries={supportedCountries}
      country={currentCountry}
      value={phoneNumber}
      onChange={onPhoneChange}
      placeholder="Mobile Number"
      inputClass="border border-gray-100 text-base bg-gray-50 rounded-md shadow-inner max-h-60 ring-2 ring-black ring-opacity-10 focus:outline-none sm:text-sm"
      inputStyle={{
        width: "100%",
        minHeight: "50px",
        borderColor: "rgba(243, 244, 246, var(--tw-border-opacity))",
      }}
      buttonClass="rounded-md shadow ring-1 ring-black ring-opacity-10 focus:outline-none relative"
      buttonStyle={{
        border: "none",
        borderColor: "rgba(243, 244, 246, var(--tw-border-opacity))",
      }}
      dropdownClass="w-full"
      dropdownStyle={{}}
    />
  );
}

export default MobilePhoneInput;

// react
import { useState, Fragment, useEffect } from "react";
// react select
import Select from "react-select";

// components
import CustomIconOption from "./customIconOption";

// hooks
import useGetProvidersForCountry from "../../../../hooks/useGetProvidersForCountry";

function MobileOperatorSelect(props) {
  const { selectedProvider, onSelectProvider, selectedCountry } = props;

  const [options, SetOptions] = useState([]);
  const [feedback, setFeedback] = useState(
    "No providers found for selected country"
  );

  const { loading, data, error } = useGetProvidersForCountry(selectedCountry);

  useEffect(() => {
    // console.log(data);
    let optionsData = [];

    if (data && data.GetProviders?.Items.length) {
      optionsData = data.GetProviders?.Items.map((item) => ({
        name: item.Name,
        code: item.ProviderCode,
        logo: item.LogoUrl,
      }));
    } else {
      setFeedback("No providers found for selected country");
    }

    SetOptions(optionsData);

    if (error) {
      setFeedback("Something went wrong while fetching providers");
      console.log("ERROR", error);
    }
  }, [data, error]);

  return (
    <Fragment>
      <Select
        instanceId="mobileOperatorSelect"
        className="text-base"
        classNamePrefix="mobileOperatorSelect"
        options={options}
        value={selectedProvider}
        placeholder={
          loading ? "Loading options..." : "Select mobile provider...."
        }
        isDisabled={loading}
        getOptionLabel={(e) => e.name}
        getOptionValue={(e) => e.code}
        onChange={onSelectProvider}
        noOptionsMessage={() => feedback}
        components={{ Option: CustomIconOption }}
      />
    </Fragment>
  );
}

export default MobileOperatorSelect;

import { useState } from "react";

import { ArrowNarrowRightIcon } from "@heroicons/react/solid";

import CountriesDropdown from "./controls/countriesDropdown";
import MobilePhoneInput from "./controls/mobileNumberInput";
import Button from "../button";

function TopUpCountryForm() {
  const [country, setCountry] = useState("");
  const [mobilePhone, setMobilePhone] = useState();

  const handleCountrySelect = (code) => {
    // console.log(code);
    setCountry(code);
  };

  const handleMobilePhoneChange = (value, countryInfo, e, formattedValue) => {
    const { countryCode } = countryInfo;
    // console.log(countryCode);
    if (countryCode != country.toLowerCase()) {
      setCountry(countryCode.toUpperCase());
    }
    setMobilePhone(value);
  };

  return (
    <div className="bg-white ring-1 ring-black ring-opacity-5 rounded-xl max-w-xl drop-shadow-lg p-5 mx-auto">
      <h2 className="text-center text-3xl font-semibold my-4 mb-8">
        Buy Top-up
      </h2>
      <div className="my-6">
        <h4 className="text-md font-medium text-gray-500 mb-3">
          Select Country
        </h4>
        <div className="w-full">
          <CountriesDropdown
            selectedCountry={country}
            onCountrySelection={handleCountrySelect}
          />
        </div>
      </div>
      {/* <div className="my-6">
        <h4 className="text-md font-medium text-gray-500 mb-3">Phone Number</h4>
        <div className="w-full">
          <MobilePhoneInput
            selectedCountry={country}
            phoneNumber={mobilePhone}
            onPhoneChange={handleMobilePhoneChange}
          />
        </div>
      </div> */}
      <div className="my-10">
        <Button
          Icon={ArrowNarrowRightIcon}
          buttonClasses="bg-gray-700 border-gray-800"
          buttonTextClasses="text-white"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}

export default TopUpCountryForm;

import React, { useState } from "react";

function Tab(props) {
  const { activeTab, updateActiveTab, tabIndex, className } = props;

  return (
    <a
      className={className({ selected: activeTab == tabIndex })}
      onClick={(e) => {
        e.preventDefault();
        updateActiveTab(tabIndex);
      }}
      data-toggle="tab"
      href="#link1"
      role="tablist"
    >
      {props.children}
    </a>
  );
}

export function TabGroup(props) {
  const [activeTab, setActiveTab] = useState(1);

  const childrenWithProps = React.Children.map(props.children, (child) => {
    // Checking isValidElement is the safe way
    // and avoids a typescript error too.
    if (React.isValidElement(child)) {
      return React.cloneElement(child, {
        activeTab: activeTab,
        updateActiveTab: setActiveTab,
      });
    }
    return child;
    T;
  });

  return (
    <div {...props}>
      {childrenWithProps}
    </div>
  );
}

export function TabList(props) {
  const { activeTab, updateActiveTab, ...otherProps } = props;

  const childrenWithProps = React.Children.map(
    props.children,
    (child, index) => {
      // Checking isValidElement is the safe way
      // and avoids a typescript error too.
      if (React.isValidElement(child)) {
        return React.cloneElement(child, {
          activeTab: activeTab,
          updateActiveTab: updateActiveTab,
          tabIndex: index + 1,
        });
      }
      return child;
    }
  );

  return (
    <div className="w-full" role="tablist" {...otherProps}>
      {childrenWithProps}
    </div>
  );
}

export function TabPanels(props) {
  const { activeTab, updateActiveTab, ...otherProps } = props;

  const childrenWithProps = React.Children.map(
    props.children,
    (child, index) => {
      // Checking isValidElement is the safe way
      // and avoids a typescript error too.
      if (React.isValidElement(child)) {
        return React.cloneElement(child, {
          activeTab,
          updateActiveTab,
          panelIndex: index + 1,
        });
      }
      return child;
    }
  );

  return (
    <div className="w-full" {...otherProps}>
      {childrenWithProps}
    </div>
  );
}

export function TabPanel(props) {
  const { activeTab, panelIndex } = props;

  return (
    <div className={activeTab === panelIndex ? "block" : "hidden"} id="link3">
      {props.children}
    </div>
  );
}

export default Tab;

// imports
import { createContext, useReducer, useEffect, useContext } from "react";
// import { setCookie, destroyCookie, parseCookies } from "nookies";

import { useRouter } from "next/router";

import { firebaseApp, firebaseAuth } from "../services/firebaseClient.service";
import { userService } from "../services/user.service";
import axios from "axios";

// refresh token time
const REFRESH_TOKEN_TIME = 30 * 60 * 1000; // 30mins

// reducer
const reducer = (state, action) => {
  switch (action.type) {
    case "LOGIN":
      return {
        ...state,
        user: action.payload,
        checkingAuth: false,
        authError: null,
      };
    case "LOGOUT":
      return { ...state, user: null, checkingAuth: false, authError: null };
    case "LOADING":
      return { ...state, checkingAuth: true };
    case "ERROR":
      return {
        ...state,
        user: null,
        checkingAuth: false,
        authError: action.payload,
      };
    default:
      return state;
  }
};

// create context
const AuthContext = createContext({});

// useAuth Hook
const useAuth = () => {
  return useContext(AuthContext);
};

// context Provider
const AuthProvider = ({ user, checkingAuth = true, authError, children }) => {
  // initial State
  const [state, dispatch] = useReducer(reducer, {
    user,
    checkingAuth,
    authError: authError,
  });
  const value = { state, dispatch };

  // console.log("Auth Context", state);

  const router = useRouter();

  useEffect(() => {
    console.log("FIREBASEAUTHSTATE USEEFFECT RUN");

    return firebaseAuth
      .getAuth(firebaseApp)
      .onAuthStateChanged(async (firebaseUser) => {
        console.log("Auth Context Firebase user", firebaseUser);
        try {
          if (!firebaseUser) {
            dispatch({
              type: "LOGOUT",
            });
            // destroy server side cookie
            await axios.post(
              "/api/logout",
              null,
              {
                headers: {
                  "Content-Type": "application/json",
                },
              }
            );
            // check if the user is on a dashboard page
            // if on a dashboard page, redirect to login page
            console.log("ROUTER PATHNAME", router.pathname);
            if (router.pathname.startsWith("/dashboard")) {
              await router.push("/login");
            }
          } else {
            const { token } = await firebaseUser.getIdTokenResult();
            // set server side cookie
            await axios.post(
              "/api/login",
              { token },
              {
                headers: {
                  "Content-Type": "application/json",
                },
              }
            );
            console.log("TOKEN", token);

            if (!checkingAuth) {
              dispatch({
                type: "LOADING",
              });
            }

            // send the token to backend
            const loggedUser = await userService.getAuthenticatedUser(token);
            // console.log("RESPONSE", response);
            dispatch({
              type: "LOGIN",
              payload: loggedUser,
            });

            console.log("LOGGED USER", loggedUser);
          }
        } catch (error) {
          console.log("ERROR", error);
          dispatch({
            type: "ERROR",
            payload: error,
          });
        }
      });
  }, []);

  // force refresh the token every 10 minutes
  useEffect(() => {
    const handle = setInterval(async () => {
      const user = firebaseAuth.getAuth(firebaseApp).currentUser;
      if (user) await user.getIdToken(true);
    }, REFRESH_TOKEN_TIME);

    // clean up setInterval
    return () => clearInterval(handle);
  }, []);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export { useAuth, AuthProvider };

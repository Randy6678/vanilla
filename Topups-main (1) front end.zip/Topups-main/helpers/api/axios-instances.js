const axios = require("axios");

const axiosAuth = axios.create({
  baseURL: process.env.appAuthApi,
});

module.exports = {
  axiosAuth,
};

import { userService } from "../services/user.service";

const publicPaths = [
  "/",
  "/about-us",
  "/help-center",
  "/help-center/faq",
  "/partners",
  "/contact-us",
  "/send-topup",
  "/send-topup/select-package",
  "/login",
  "/signup",
];

async function authCheck(url) {
  const path = url.split("?")[0];
  try {
    const user = await userService.getAuthenticatedUser();

    // redirect to login page if accessing a private page and not logged in
    if (!user && !publicPaths.includes(path)) {
      setAuthorized(false);
      router.push({
        pathname: "/login",
        query: { returnUrl: router.asPath },
      });
    } else {
      dispatch({
        type: "LOGIN",
        payload: user,
      });
      setAuthorized(true);
    }
  } catch (error) {
    setAuthorized(false);
    if (!publicPaths.includes(path)) {
      router.push({
        pathname: "/login",
        query: { returnUrl: router.asPath },
      });
    }
  }
}
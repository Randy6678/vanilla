const axios = require("axios");
const {
  firebaseApp,
  firebaseAuth,
} = require("../services/firebaseClient.service");

const axiosPublic = axios.create({
  baseURL: process.env.appApi,
});

const axiosAuth = axios.create({
  baseURL: process.env.appAuthApi,
});

axiosAuth.interceptors.request.use(
  async (config) => {
    // let user = await firebase.auth().currentUser;
    let user = await firebaseAuth.getAuth(firebaseApp).currentUser;
    let token = user ? await user.getIdToken() : "";
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

module.exports = {
  axiosPublic,
  axiosAuth,
};

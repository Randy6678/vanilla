// apollo
import { useMutation, gql } from "@apollo/client";

const ESTIMATE_PRODUCT_PRICE = gql`
  mutation EstimatePrices(
    $sendValue: Float!
    $receiveValue: Float!
    $skuCode: String!
    $uniqueId: String!
  ) {
    EstimatePrices(
      payload: [
        {
          SendValue: $sendValue
          ReceiveValue: $receiveValue
          SkuCode: $skuCode
          BatchItemRef: $uniqueId
        }
      ]
    ) {
      Items {
        Price {
          CustomerFee
          DistributorFee
          ReceiveValue
          ReceiveCurrencyIso
          ReceiveValueExcludingTax
          TaxRate
          TaxName
          TaxCalculation
          SendValue
          SendCurrencyIso
        }
      }
    }
  }
`;

export default function useEstimateProductPrice() {
  const [mutateFunction, { loading, error, data }] = useMutation(
    ESTIMATE_PRODUCT_PRICE
  );

  console.log("data", data);
  console.log("error", error);
  console.log("loading", loading);

  return [mutateFunction, { data, loading, error }];
}

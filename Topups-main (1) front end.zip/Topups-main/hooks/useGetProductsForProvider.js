// apollo
import { useQuery, gql } from "@apollo/client";

const FETCH_PRODUCTS_FOR_A_PROVIDER = gql`
  query FetchProductsForProvider($countryIso: String, $providerCode: String) {
    GetProducts(countryIsos: [$countryIso], providerCodes: [$providerCode]) {
      ResultCode
      Items {
        ProviderCode
        SkuCode
        LocalizationKey
        SettingDefinitions {
          Name
          Description
          IsMandatory
        }
        Maximum {
          CustomerFee
          DistributorFee
          ReceiveValue
          ReceiveCurrencyIso
          ReceiveValueExcludingTax
          TaxRate
          TaxName
          TaxCalculation
          SendValue
          SendCurrencyIso
        }
        Minimum {
          CustomerFee
          DistributorFee
          ReceiveValue
          ReceiveCurrencyIso
          ReceiveValueExcludingTax
          TaxRate
          TaxName
          TaxCalculation
          SendValue
          SendCurrencyIso
        }
        CommissionRate
        ProcessingMode
        RedemptionMechanism
        Benefits
        ValidityPeriodIso
        UatNumber
        AdditionalInformation
        DefaultDisplayText
        RegionCode
        PaymentTypes
        LookupBillsRequired
      }
      ErrorCodes {
        Code
        Context
      }
    }
    GetProviders(countryIsos: [$countryIso], providerCodes: [$providerCode]) {
      Items {
        ProviderCode
        Name
        LogoUrl
      }
    }
  }
`;

export default function useGetProductsForProvider(countryIso, providerCode) {
  const { loading, error, data } = useQuery(FETCH_PRODUCTS_FOR_A_PROVIDER, {
    variables: { countryIso, providerCode },
  });

  return { data, loading, error };
}

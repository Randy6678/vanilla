// apollo
import { useQuery, gql } from "@apollo/client";

const ALL_PROVIDERS_IN_COUNTRY = gql`
  query GetProvidersForCountry($countryIso: String!) {
    GetProviders(countryIsos: [$countryIso]) {
      Items {
        ProviderCode
        Name
        LogoUrl
      }
    }
  }
`;

export default function useGetProvidersForCountry(countryIso) {
  const { loading, error, data } = useQuery(ALL_PROVIDERS_IN_COUNTRY, {
    variables: { countryIso },
  });

  return { data, loading, error };
}

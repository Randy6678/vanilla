// apollo
import { useQuery, gql } from "@apollo/client";

const ALL_SUPPORTED_COUNTRIES = gql`
  query FetchSupportedCountries {
    GetCountries {
      ResultCode
      Items {
        CountryIso
        CountryName
        InternationalDialingInformation {
          Prefix
          MinimumLength
          MaximumLength
        }
      }
      ErrorCodes {
        Code
        Context
      }
    }
  }
`;

export default function useGetSupportedCountries() {
  const { loading, error, data } = useQuery(ALL_SUPPORTED_COUNTRIES);

  return { data, loading, error };
}

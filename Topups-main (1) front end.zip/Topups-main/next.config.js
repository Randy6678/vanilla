const { PHASE_DEVELOPMENT_SERVER } = require("next/constants");

let envOptions = {
  // mongoDb Logs
  mongodb_username: "rilla",
  mongodb_password: "rilla",
  mongodb_clustername: "cluster0",
  mongodb_database: "my-site",
  dingConnectApi: "https://api.dingconnect.com/api/V1",
  dingConnectAuth: "https://idp.ding.com/connect", // https://idp.ding.com/connect/token
};

// for development
if (PHASE_DEVELOPMENT_SERVER) {
  envOptions = {
    ...envOptions,
    // API Endpoints
    appApi: "http://localhost:3000/api",
    appAuthApi: "http://localhost:5000/api/auth",
    appDingGraphql: "http://localhost:5000/graphql",
    backendUrl: "http://localhost:5000",
    paystack_public_key: "pk_test_8878e41d2ca3074812fc5d8b1ec898f44c5ec8c4",
  };
} else {
  // for production/api/auth
  envOptions = {
    ...envOptions,
    // API Endpoints
    appApi: "https://topups.vercel.app/api",
    appAuthApi: "https://topups-api.onrender.com/api/auth",
    appDingGraphql: "https://topups-api.onrender.com/graphql",
    backendUrl: "https://topups-api.onrender.com",
    paystack_public_key: "pk_test_8878e41d2ca3074812fc5d8b1ec898f44c5ec8c4",
  };
}

module.exports = {
  reactStrictMode: true,
  env: envOptions,
  images: {
    domains: ["assets-global.website-files.com", "imagerepo.ding.com"],
  },
};

import { ApolloClient, InMemoryCache, ApolloProvider } from "@apollo/client";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

import Layout from "../components/layout/layout";
import { useAuth, AuthProvider } from "../context/authContext";

import "tailwindcss/tailwind.css";
import "../styles/mainstyle.css";

const client = new ApolloClient({
  uri: process.env.appDingGraphql,
  cache: new InMemoryCache(),
});

function MyApp({ Component, pageProps }) {
  // const {
  //   state: { user, checkingAuth },
  //   dispatch,
  // } = useAuth();

  return (
    <AuthProvider>
      <ApolloProvider client={client}>
        <Layout>
          <ToastContainer
            position="top-right"
            autoClose={5000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
          />
          <Component {...pageProps} />
        </Layout>
      </ApolloProvider>
    </AuthProvider>
  );
}

export default MyApp;

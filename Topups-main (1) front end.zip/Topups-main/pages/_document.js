import Document, { Html, Head, Main, NextScript } from 'next/document';

class MyDocument extends Document {
  render() {
    return (
      <Html lang='en'>
        <Head />
        <body>
          <Main className="bg-gray-50" />
          <NextScript />
          <div id="modals"></div>
        </body>
      </Html>
    );
  }
}

export default MyDocument;
import Container from "../components/ui/container";
import AboutUsHeroSection from "../components/about-us/hero";

function AboutUsPage() {
  return (
    <section>
      {/* About Us Header */}
      <div className="bg-gray-900 py-10 drop-shadow">
        <Container>
          <div className="flex flex-col items-center py-4">
            <div className="text-center mb-4">
              <h1 className="font-extrabold mb-3 text-2xl md:text-4xl max-w-xl text-white leading-tight">
                About <b className="text-red-500">BuyTopups.com</b>
              </h1>
              <hr className="w-12 h-1 border-red-500 bg-red-500 rounded-full mt-3"></hr>
            </div>
            <div className="text-center mb-8">
              <p className="text-2xl text-gray-300 font-light leading-relaxed">
                Learn more about our{" "}
                <span className="text-red-500 font-medium">goals and mission</span>{" "}
              </p>
            </div>
          </div>
        </Container>
      </div>
      <div className="pt-16 pb-0a">
        <AboutUsHeroSection />
      </div>
    </section>
  );
}

export default AboutUsPage;

import cookie from "cookie";
import axios from "axios";

const LoginHandler = async (req, res) => {
  const token = req.body.token;
  console.log("AHAHHA TOKEN", token);

  try {
    const currentUser = await axios
      .post(`${process.env.appAuthApi}/verify-login`, null, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        // console.log("RESPONSE", response);

        const user = response.data.user;

        return user;
      });

    res.setHeader(
      "Set-Cookie",
      cookie.serialize("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV !== "development",
        maxAge: 60 * 60,
        sameSite: "strict",
        path: "/",
      })
    );
    res.status(200).json({ success: true, user: currentUser });
  } catch (err) {
    res.status(401).json({ success: false, user: null });
  }
};

export default LoginHandler;

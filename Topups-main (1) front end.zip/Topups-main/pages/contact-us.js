import Container from "../components/ui/container";
import MobilePhoneInput from "../components/ui/forms/controls/mobileNumberInput";

function ContactUsPage() {
  return (
    <section>
      {/* Contact Us Header */}
      <div className="bg-gray-900 py-10 drop-shadow">
        <Container>
          <div className="flex flex-col items-center py-4">
            <div className="text-center mb-4">
              <h1 className="font-extrabold mb-3 text-2xl md:text-4xl max-w-xl text-white leading-tight">
                Contact Us
              </h1>
              <hr className="w-12 h-1 border-red-500 bg-red-500 rounded-full mt-3"></hr>
            </div>
            <div className="text-left mb-8">
              <p className="text-2xl text-gray-300 font-light leading-relaxed">
                We're here, let's start a{" "}
                <span className="text-red-500 font-medium">conversation</span>{" "}
              </p>
            </div>
          </div>
        </Container>
      </div>
      <Container>
        <div className="max-w-xl mx-auto py-24">
          <form>
            <div className="grid grid-cols-2 gap-6 mb-0 lg:mb-6">
              <div className="mb-6 lg:mb-0">
                <label
                  htmlFor="firstName"
                  className="text-sm text-gray-600 leading-snug"
                >
                  First Name
                </label>
                <input
                  id="firstName"
                  className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50 focus:outline-none focus:bg-gray-100 ring-2 ring-black ring-opacity-10"
                  type="text"
                  placeholder="First Name"
                  required
                />
              </div>
              <div className="mb-6 lg:mb-0">
                <label
                  htmlFor="lastName"
                  className="text-sm text-gray-600 leading-snug"
                >
                  Last Name
                </label>
                <input
                  id="lastName"
                  className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50 focus:outline-none focus:bg-gray-100 ring-2 ring-black ring-opacity-10"
                  type="text"
                  placeholder="Last Name"
                  required
                />
              </div>
            </div>
            <div className="mb-6">
              <label
                htmlFor="email"
                className="text-sm text-gray-600 leading-snug"
              >
                Email
              </label>
              <input
                id="email"
                className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50 focus:outline-none focus:bg-gray-100 ring-2 ring-black ring-opacity-10"
                type="email"
                placeholder="Email"
                required
              />
            </div>
            <div className="mb-6">
              <label
                htmlFor="company"
                className="text-sm text-gray-600 leading-snug"
              >
                Company
              </label>
              <input
                id="company"
                className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50 focus:outline-none focus:bg-gray-100 ring-2 ring-black ring-opacity-10"
                type="text"
                placeholder="Company"
                required
              />
            </div>
            <div className="mb-6">
              <label
                htmlFor="phone"
                className="text-sm block text-gray-600 leading-snug mb-3"
              >
                Phone
              </label>
              <MobilePhoneInput
                phoneNumber=""
                onPhoneChange={() => {}}
                selectedCountry="gh"
              />
            </div>
            <div className="mb-6">
              <label
                htmlFor="message"
                className="text-sm text-gray-600 leading-snug"
              >
                Message
              </label>
              <textarea
                id="message"
                className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50 focus:outline-none focus:bg-gray-100 ring-2 ring-black ring-opacity-10"
                rows="5"
                placeholder="Message"
                required
              />
            </div>
            <div className="mb-6">
              <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                <input
                  type="checkbox"
                  name="toggle"
                  id="toggle"
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-0 appearance-none cursor-pointer"
                />
                <label
                  htmlFor="toggle"
                  className="toggle-label block overflow-hidden h-7 w-12 rounded-full bg-gray-300 cursor-pointer"
                ></label>
              </div>
              <label
                htmlFor="toggle"
                className="text-base font-light text-gray-700"
              >
                By selecting this you agree to the{" "}
                <a href="#" className="font-normal text-gray-800 underline">
                  Privacy Policy
                </a>{" "}
                and{" "}
                <a href="#" className="font-normal text-gray-800 underline">
                  Cookie Policy
                </a>
              </label>
            </div>
            <button className="w-full rounded px-4 py-2 bg-red-500 hover:bg-red-600 hover:shadow">
              <span className="text-lg font-semibold text-gray-50">Submit</span>
            </button>
          </form>
        </div>
      </Container>
    </section>
  );
}

export default ContactUsPage;

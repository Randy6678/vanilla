import { LocationMarkerIcon } from "@heroicons/react/solid";

import AdminLayout from "../../components/layout/admin-layout";

function ContactsPage() {
  return (
    <AdminLayout>
      {/* Header Area */}
      <div className="flex flex-row justify-between items-center pb-5 border-b-2">
        <h1 className="font-extrabold mb-3 text-2xl md:text-4xl leading-tight">
          Contacts
        </h1>
        <form className="lg:w-2/6">
          <input
            id="search"
            className="w-full py-3 px-2 shadow-inner rounded bg-gray-50/80 focus:outline-none focus:bg-gray-50 ring-1 ring-black ring-opacity-10"
            type="text"
            placeholder="Search Contacts"
            required
          />
        </form>
      </div>
      {/* Contacts List */}
      <div>
        {/* Contact 1 */}
        <div className="flex flex-row items-center justify-between p-5 border-b hover:bg-gray-100/20">
          {/* Contact Info */}
          <div className="grid grid-cols-6">
            <div className="col-span-2 inline-flex items-center">
              <div className="w-12 h-12 bg-red-300 px-2 py-1.5 rounded-full mx-auto">
                <h2 className="text-red-600 text-3xl text-center">N</h2>
              </div>
            </div>
            <div className="col-span-4">
              <h3 className="text-xl font-bold leading-8 text-red-500">
                Nat Bongo
              </h3>
              <p className="text-gray-800 font-medium leading-5 tracking-wide">
                0592766862
              </p>
              <p className="text-gray-500">n.bongo40@gmail.com</p>
            </div>
          </div>
          {/* Location and operator Info */}
          <div className="space-y-2">
            <span className="px-3 py-1.5 rounded-full bg-red-300 text-red-700">MTN Ghana</span>
            <h4 className="font-bold text-xl text-gray-500 align-bottom mt-2 flex items-center">
              <LocationMarkerIcon className="w-6 h-6 inline mr-2" />
              Ghana
            </h4>
          </div>
        </div>
        {/* Contact 2 */}
        <div className="flex flex-row items-center justify-between p-5 border-b hover:bg-gray-100/20">
          {/* Contact Info */}
          <div className="grid grid-cols-6">
            <div className="col-span-2 inline-flex items-center">
              <div className="w-12 h-12 bg-red-300 px-2 py-1.5 rounded-full mx-auto">
                <h2 className="text-red-600 text-3xl text-center">N</h2>
              </div>
            </div>
            <div className="col-span-4">
              <h3 className="text-xl font-bold leading-8 text-red-500">
                Nat Bongo
              </h3>
              <p className="text-gray-800 font-medium leading-5 tracking-wide">
                0592766862
              </p>
              <p className="text-gray-500">n.bongo40@gmail.com</p>
            </div>
          </div>
          {/* Location and operator Info */}
          <div className="space-y-2">
            <span className="px-3 py-1.5 rounded-full bg-red-300 text-red-700">MTN Ghana</span>
            <h4 className="font-bold text-xl text-gray-500 align-bottom mt-2 flex items-center">
              <LocationMarkerIcon className="w-6 h-6 inline mr-2" />
              Ghana
            </h4>
          </div>
        </div>
        {/* Contact 3 */}
        <div className="flex flex-row items-center justify-between p-5 border-b hover:bg-gray-100/20">
          {/* Contact Info */}
          <div className="grid grid-cols-6">
            <div className="col-span-2 inline-flex items-center">
              <div className="w-12 h-12 bg-red-300 px-2 py-1.5 rounded-full mx-auto">
                <h2 className="text-red-600 text-3xl text-center">N</h2>
              </div>
            </div>
            <div className="col-span-4">
              <h3 className="text-xl font-bold leading-8 text-red-500">
                Nat Bongo
              </h3>
              <p className="text-gray-800 font-medium leading-5 tracking-wide">
                0592766862
              </p>
              <p className="text-gray-500">n.bongo40@gmail.com</p>
            </div>
          </div>
          {/* Location and operator Info */}
          <div className="space-y-2">
            <span className="px-3 py-1.5 rounded-full bg-red-300 text-red-700">MTN Ghana</span>
            <h4 className="font-bold text-xl text-gray-500 align-bottom mt-2 flex items-center">
              <LocationMarkerIcon className="w-6 h-6 inline mr-2" />
              Ghana
            </h4>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

export default ContactsPage;

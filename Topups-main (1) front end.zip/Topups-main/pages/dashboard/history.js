import { useState } from "react";

import { Table, Column, HeaderCell, Cell } from "rsuite-table";
import "rsuite-table/dist/css/rsuite-table.css";

import AdminLayout from "../../components/layout/admin-layout";

import { getActiveLoggedUser } from "../../services/server.service";

const fakeData = [
  {
    id: 1,
    firstName: "Nat",
    lastName: "Bongo",
    phone: "+233592766762",
    email: "n.bongo40@gmail.com",
    country: "Ghana",
    package: "MTN Mobile Data",
    topupAmount: "GHS 20",
    topupCost: "5$",
    date: "2016-09-23T07:57:40.195Z",
  },
];

function HistoryPage() {
  const [loading, setLoading] = useState(false);
  const [limit, setLimit] = useState(10);
  const [page, setPage] = useState(1);

  const handleChangeLimit = (dataKey) => {
    setPage(1);
    setLimit(dataKey);
  };

  const data = fakeData.filter((v, i) => {
    const start = limit * (page - 1);
    const end = start + limit;
    return i >= start && i < end;
  });

  return (
    <AdminLayout>
      <h1 className="text-4xl font-bold mb-12">Order History</h1>

      {/* History Table */}
      <div>
        <Table height={600} data={data} loading={loading}>
          <Column width={150} align="center" fixed="left">
            <HeaderCell>Order Id</HeaderCell>
            <Cell dataKey="id" />
          </Column>

          <Column width={150} fixed>
            <HeaderCell>First Name</HeaderCell>
            <Cell dataKey="firstName" />
          </Column>

          <Column width={150}>
            <HeaderCell>Last Name</HeaderCell>
            <Cell dataKey="lastName" />
          </Column>
          <Column width={200}>
            <HeaderCell>Phone</HeaderCell>
            <Cell dataKey="phone" />
          </Column>
          <Column width={200}>
            <HeaderCell>Email</HeaderCell>
            <Cell dataKey="email" />
          </Column>
          <Column width={200}>
            <HeaderCell>Topup Package</HeaderCell>
            <Cell dataKey="package" />
          </Column>
          <Column width={200}>
            <HeaderCell>Topup Amount</HeaderCell>
            <Cell dataKey="topupAmount" />
          </Column>
          <Column width={200}>
            <HeaderCell>Topup Cost</HeaderCell>
            <Cell dataKey="topupCost" />
          </Column>
          <Column width={300}>
            <HeaderCell>Date</HeaderCell>
            <Cell dataKey="date" />
          </Column>
        </Table>
      </div>
    </AdminLayout>
  );
}

export async function getServerSideProps(context) {
  let user = null;

  try {
    user = await getActiveLoggedUser(context);

    if (user) {
      return {
        props: {
          user,
          authorized: true,
        },
      };
    } else {
      return {
        redirect: {
          destination: "/login",
          permanent: true,
        },
      };
    }
  } catch (error) {
    return {
      redirect: {
        destination: "/login",
        permanent: true,
      },
    };
  }
}

export default HistoryPage;

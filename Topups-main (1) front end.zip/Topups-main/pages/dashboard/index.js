import { useEffect, useState } from "react";
import { Table, Column, HeaderCell, Cell } from "rsuite-table";
import "rsuite-table/dist/css/rsuite-table.css";

import { IdentificationIcon, ShoppingCartIcon } from "@heroicons/react/outline";

import { VirtualHug } from "../../components/ui/svg";

import { getActiveLoggedUser } from "../../services/server.service";
import AdminLayout from "../../components/layout/admin-layout";
import { useRouter } from "next/router";

const fakeData = [
  {
    id: 1,
    firstName: "Nat",
    lastName: "Bongo",
    email: "n.bongo40@gmail.com",
    package: "MTN Mobile Data",
    topupAmount: "GHS 20",
    topupCost: "5$",
    date: "2016-09-23T07:57:40.195Z",
  },
];

function DashboardPage(props) {
  const [tableData, setTableData] = useState(fakeData);
  const currentUser = props.user;
  const userIsLogged = props.authorized;

  const router = useRouter();

  useEffect(() => {
    console.log("DASHBOARD USER", currentUser);
    console.log("DASHBOARD Authorized", userIsLogged);
    if (!userIsLogged) {
      router.replace("/login");
    }
  }, []);

  return (
    <AdminLayout>
      {/* Welcome Area */}
      <div className="relative bg-red-200 p-4 sm:p-6 rounded overflow-hidden mb-6">
        <div
          className="absolute right-0 top-0 -mt-4 mr-16 pointer-events-none hidden sm:block"
          aria-hidden="true"
        >
          <VirtualHug />
        </div>
        <div className="relative drop-shadow-sm space-y-3">
          <h1 className="text-2xl md:text-3xl text-gray-800 font-bold mb-1">
            Good afternoon,
          </h1>
          <p className="text-lg leading-relaxed text-gray-600">
            Send a virtual hug to brighten up someones day.
          </p>
          <button className="px-6 py-3 bg-red-600 rounded-md text-white outline-none focus:ring-1 shadow-lg transform active:scale-x-105 active:scale-y-105 transition-transform">
            Send Topup
          </button>
        </div>
      </div>

      {/* Stats Area */}
      <div className="container px-5 py-6 mx-auto">
        <div className="flex flex-wrap gap-4">
          <div className="p-4 w-full md:w-1/3 drop-shadow shadow rounded bg-gradient-to-br from-pink-100 to-red-200">
            <div className="inline-flex flex-nowrap items-center">
              <IdentificationIcon className="text-red-500 w-12 h-12 inline-block" />
              <div className="pl-3">
                <h2 className="font-medium text-3xl text-gray-800">20</h2>
                <p className="leading-relaxed text-gray-600">Saved Contacts</p>
              </div>
            </div>
          </div>
          <div className="p-4 w-full md:w-1/3 drop-shadow shadow rounded bg-gradient-to-br from-pink-100 to-red-200">
            <div className="inline-flex flex-nowrap items-center">
              <ShoppingCartIcon className="text-red-500 w-12 h-12 inline-block" />
              <div className="pl-3">
                <h2 className="font-medium text-3xl text-gray-800">31</h2>
                <p className="leading-relaxed text-gray-600">Total Purchases</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* History Area */}
      <div className="container px-5 py-8 mt-8 mx-auto">
        <div className="flex flex-col w-full mb-2">
          <h3 className="sm:text-xl text-2xl font-medium text-gray-800">
            Recent Purchases
          </h3>
        </div>
        <div>
          <Table
            height={400}
            data={tableData}
            id="table"
            onRowClick={(data) => {
              console.log(data);
            }}
          >
            <Column width={150} align="center" fixed="left">
              <HeaderCell>Order Id</HeaderCell>
              <Cell dataKey="id" />
            </Column>

            <Column width={150} fixed>
              <HeaderCell>First Name</HeaderCell>
              <Cell dataKey="firstName" />
            </Column>

            <Column width={150}>
              <HeaderCell>Last Name</HeaderCell>
              <Cell dataKey="lastName" />
            </Column>

            <Column width={200}>
              <HeaderCell>Email</HeaderCell>
              <Cell dataKey="email" />
            </Column>
            <Column width={200}>
              <HeaderCell>Topup Package</HeaderCell>
              <Cell dataKey="package" />
            </Column>
            <Column width={200}>
              <HeaderCell>Topup Amount</HeaderCell>
              <Cell dataKey="topupAmount" />
            </Column>
            <Column width={200}>
              <HeaderCell>Topup Cost</HeaderCell>
              <Cell dataKey="topupCost" />
            </Column>
            <Column width={300}>
              <HeaderCell>Date</HeaderCell>
              <Cell dataKey="date" />
            </Column>
          </Table>
        </div>
      </div>
    </AdminLayout>
  );
}

export async function getServerSideProps (context) {
  let user = null;

  try {
    user = await getActiveLoggedUser(context);

    if (user) {
      return {
        props: { user, authorized: user ? true : false },
      };
    }

    throw new Error("User Not Logged In");
  } catch (error) {
    return {
      redirect: {
        destination: "/login",
        permanent: true,
      },
    };
  }
};

export default DashboardPage;

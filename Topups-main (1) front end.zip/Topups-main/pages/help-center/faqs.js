import { SearchIcon } from "@heroicons/react/outline";

import Container from "../../components/ui/container";

function FAQs() {
  return (
    <section>
      {/* Help Center Header */}
      <div className="bg-gray-900 py-10 drop-shadow">
        <Container>
          <div className="flex flex-col items-start py-4">
            <div className="text-left mb-8">
              <h1 className="font-extrabold mb-3 text-2xl md:text-4xl max-w-xl text-white leading-tight">
                Frequently Asked Questions
              </h1>
              {/* <hr className="w-12 h-1 text-red-500 bg-red-500 rounded-full mt-3"></hr> */}
              <p className="text-2xl text-gray-300 font-light leading-relaxed">
                Browse through frequently asked questions and anwers
              </p>
            </div>
            <form className="w-full bg-gray-500 rounded border-0 focus:bg-gray-50 px-3">
              <div className="grid grid-cols-auto-full items-center">
                <button className="w-8 h-full flex items-center justify-center">
                  <SearchIcon className="w-5 h-5 text-gray-300" />
                </button>
                <div className="">
                  <input
                    type="search"
                    className="w-full py-4 px-2 bg-transparent text-gray-50 rounded-r focus:outline-none"
                    placeholder="Search frequently asked questions ..."
                  />
                </div>
              </div>
            </form>
          </div>
        </Container>
      </div>
      <Container>
        <div className="py-20 grid grid-flow-row">
          <details className="w-full max-w-4xl mx-auto border-t border-gray-20">
            <summary className="cursor-pointer text-lg text-gray-900 font-medium py-4 px-4">
              How Long is this site live ?
            </summary>

            <p className="px-3 py-4 text-base text-gray-500">
              Laboris qui labore cillum culpa in sunt quis sint veniam. Dolore
              ex aute deserunt esse ipsum elit aliqua. Aute quis minim velit
              nostrud pariatur culpa magna in aute.
            </p>
          </details>
          <details className="w-full max-w-4xl mx-auto border-t border-gray-20">
            <summary className="cursor-pointer text-lg text-gray-900 font-medium py-4 px-4">
              How Long is this site live ?
            </summary>

            <p className="px-3 py-4 text-base text-gray-500">
              Laboris qui labore cillum culpa in sunt quis sint veniam. Dolore
              ex aute deserunt esse ipsum elit aliqua. Aute quis minim velit
              nostrud pariatur culpa magna in aute.
            </p>
          </details>
          <details className="w-full max-w-4xl mx-auto border-t border-gray-20">
            <summary className="cursor-pointer text-lg text-gray-900 font-medium py-4 px-4">
              How Long is this site live ?
            </summary>

            <p className="px-3 py-4 text-base text-gray-500">
              Laboris qui labore cillum culpa in sunt quis sint veniam. Dolore
              ex aute deserunt esse ipsum elit aliqua. Aute quis minim velit
              nostrud pariatur culpa magna in aute.
            </p>
          </details>
          <details className="w-full max-w-4xl mx-auto border-t border-gray-20">
            <summary className="cursor-pointer text-lg text-gray-900 font-medium py-4 px-4">
              How Long is this site live ?
            </summary>

            <p className="px-3 py-4 text-base text-gray-500">
              Laboris qui labore cillum culpa in sunt quis sint veniam. Dolore
              ex aute deserunt esse ipsum elit aliqua. Aute quis minim velit
              nostrud pariatur culpa magna in aute.
            </p>
          </details>
        </div>
      </Container>
    </section>
  );
}

export default FAQs;

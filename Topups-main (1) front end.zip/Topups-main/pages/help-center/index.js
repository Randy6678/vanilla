import Link from "next/link";
import {
  SearchIcon,
  QuestionMarkCircleIcon,
  MailIcon,
  PhoneOutgoingIcon,
} from "@heroicons/react/outline";

import Container from "../../components/ui/container";

function HelpCenter() {
  return (
    <section>
      {/* Help Center Header */}
      <div className="bg-gray-900 py-10 drop-shadow">
        <Container>
          <div className="flex flex-col items-start py-4">
            <div className="text-left mb-8">
              <h1 className="font-extrabold mb-3 text-2xl md:text-4xl max-w-xl text-white leading-tight">
                Help Center
              </h1>
              {/* <hr className="w-12 h-1 text-red-500 bg-red-500 rounded-full mt-3"></hr> */}
              <p className="text-2xl text-gray-300 font-light leading-relaxed">
                Help and answers from the{" "}
                <span className="text-red-500 font-medium">BuyTopups.com</span>{" "}
                Team
              </p>
            </div>
            <form className="w-full bg-gray-500 rounded border-0 focus:bg-gray-50 px-3">
              <div className="grid grid-cols-auto-full items-center">
                <button className="w-8 h-full flex items-center justify-center">
                  <SearchIcon className="w-5 h-5 text-gray-300" />
                </button>
                <div className="">
                  <input
                    type="search"
                    className="w-full py-4 px-2 bg-transparent text-gray-50 rounded-r focus:outline-none"
                    placeholder="Search frequently asked questions ..."
                  />
                </div>
              </div>
            </form>
          </div>
        </Container>
      </div>
      <Container>
        <div className="py-20 grid grid-flow-row gap-8">
          <Link href="/help-center/faqs">
            <a className="bg-white w-full block p-6 rounded ring-1 ring-black ring-opacity-0 drop-shadow-md max-w-4xl mx-auto hover:drop-shadow-sm hover:ring-opacity-10">
              <div className="grid grid-cols-auto-full items-center">
                <div className="w-36 flex justify-center items-center">
                  <QuestionMarkCircleIcon className="w-16 h-16 text-gray-400" />
                </div>
                <div>
                  <h3 className="text-2xl text-indigo-500 leading-tight mb-3">
                    FAQs
                  </h3>
                  <p className="text-base text-gray-500 pr-10">
                    Browse through frequently asked questions with anwers. You
                    can also ask new questions here
                  </p>
                </div>
              </div>
            </a>
          </Link>
          <Link href="mailto://support@buytopups.com">
            <a className="bg-white w-full block p-6 rounded ring-1 ring-black ring-opacity-0 drop-shadow-md max-w-4xl mx-auto hover:drop-shadow-sm hover:ring-opacity-10">
              <div className="grid grid-cols-auto-full items-center">
                <div className="w-36 flex justify-center items-center">
                  <MailIcon className="w-16 h-16 text-gray-400" />
                </div>
                <div>
                  <h3 className="text-2xl text-indigo-500 leading-tight mb-3">
                    Email Support
                  </h3>
                  <p className="text-base text-gray-500 pr-10">
                    Can find your question or query in our <b className="font-medium">Frequently Asked
                    Questions</b> ?
                    <br />
                    Email our support{" "}
                    <span className="text-indigo-500">support@buytopups.com</span>
                  </p>
                </div>
              </div>
            </a>
          </Link>
          <Link href="tel://(+233)-592-766-862">
            <a className="bg-white w-full block p-6 rounded ring-1 ring-black ring-opacity-0 drop-shadow-md max-w-4xl mx-auto hover:drop-shadow-sm hover:ring-opacity-10">
              <div className="grid grid-cols-auto-full items-center">
                <div className="w-36 flex justify-center items-center">
                  <PhoneOutgoingIcon className="w-16 h-16 text-gray-400" />
                </div>
                <div>
                  <h3 className="text-2xl text-indigo-500 leading-tight mb-3">
                    Call Support
                  </h3>
                  <p className="text-base text-gray-500 pr-10">
                    For urgent queries phone us on <span className="text-indigo-500">(+233) 592 766 862</span>
                  </p>
                </div>
              </div>
            </a>
          </Link>
        </div>
      </Container>
    </section>
  );
}

export default HelpCenter;

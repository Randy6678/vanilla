import { Fragment } from "react";

// components
import HomeHeroSection from "../components/home-page/hero/hero";
import SendTopupSection from "../components/home-page/send-topup-section";
import WhyUsSection from "../components/home-page/why-us-section";
import NewsLetter from "../components/home-page/newsletter";

function HomePage(props) {
  return (
    <Fragment>
      <HomeHeroSection />
      <SendTopupSection />
      <WhyUsSection />
      <NewsLetter />
    </Fragment>
  );
}

export default HomePage;

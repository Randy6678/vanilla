import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";

import LoginForm from "../components/auth/login-form";

import FacebookIcon from "../components/ui/svg/facebookIcon";
import GoogleIconColored from "../components/ui/svg/googleIconColored";

import { useAuth } from "../context/authContext";
import { userService } from "../services/user.service";
import { checkUserIsLogged } from "../services/server.service";

function LoginPage(props) {
  const userIsLogged = props.authorized;

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [userLogged, setUserLogged] = useState(userIsLogged);

  const router = useRouter();
  const { returnUrl } = router.query;
  const redirectUrl = returnUrl ? returnUrl : "/dashboard";

  const {
    state: { user, checkingAuth },
  } = useAuth();

  useEffect(() => {
    console.log("LOGIN", userIsLogged);
    console.log("LOGIN INITIAL PROPS", props);
    if (userIsLogged) {
      router.replace("/dashboard");
    }
  }, []);

  useEffect(() => {
    if (!checkingAuth && userLogged && user) {
     router.replace(redirectUrl, undefined, { shallow: false });
    }
  }, [checkingAuth, user])

  async function handleEmailPasswordLogin(event) {
    event.preventDefault();
    setLoading(true);

    const loginForm = event.target;
    const loginEmail = loginForm.email.value;
    const loginPass = loginForm.password.value;

    try {
      await userService.loginWithEmailAndPassword(loginEmail, loginPass);

      setUserLogged(true);
    } catch (error) {
      console.log("LOGIN", error);
      setLoading(false);
      setError(error.message);
    }
  }

  async function handleGoogleSignIn() {
    setLoading(true);

    try {
      await userService.loginWithGoogle();

      setUserLogged(true);
    } catch (error) {
      console.log("LOGIN ERROR", error);
      setLoading(false);
      setError(error.message);
    }
  }

  async function handleFacebookSignIn() {
    setLoading(true);

    try {
      await userService.loginWithFacebook();

      setUserLogged(true);
    } catch (error) {
      console.log("LOGIN", error);
      setLoading(false);
      setError(error.message);
    }
  }

  return (
    <section className="grid grid-flow-row lg:grid-flow-col lg:grid-cols-2 xl:grid-cols-3 items-center min-h-screen">
      <div
        className="bg-gray-50 hidden lg:block w-full h-full md:col-span-1 xl:col-span-2 object-cover"
        style={{
          background: "url(https://source.unsplash.com/960x667/?nightfall)",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center center",
          backgroundSize: "cover",
        }}
      ></div>
      <div
        className="bg-white w-full h-full md:max-w-md lg:max-w-full md:mx-auto md:col-span-1 xl:col-span-1 px-6 lg:px-16 xl:px-12
    flex items-center justify-center"
      >
        <div className="w-full py-5">
          <h1 className="text-xl md:text-2xl font-extrabold leading-tight mt-6 text-gray-800">
            Welcome Back
          </h1>
          <LoginForm
            errorMessage={error}
            onSubmit={handleEmailPasswordLogin}
            isLoading={loading}
          />
          <div className="flex items-center justify-center mt-6 mb-4 w-full">
            <div className="w-16 h-px top-4 bg-gray-300"></div>
            <div className="relative text-sm font-extrabold mx-4 my-0 px-0 py-4 text-center text-gray-500 uppercase">
              or login via
            </div>
            <div className="w-16 h-px top-4 bg-gray-300"></div>
          </div>
          <div className="flex flex-row flex-nowrap gap-4 w-full">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full block bg-white hover:bg-gray-100 focus:bg-gray-100 text-gray-900 font-semibold rounded-lg px-4 py-3 border border-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <div className="flex items-center justify-center">
                <GoogleIconColored />
                <span className="ml-4 sr-only">Google</span>
              </div>
            </button>
            <button
              type="button"
              onClick={handleFacebookSignIn}
              disabled={loading}
              className="w-full block bg-white hover:bg-gray-100 focus:bg-gray-100 text-gray-900 font-semibold rounded-lg px-4 py-3 border border-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <div className="flex items-center justify-center">
                <FacebookIcon classes="w-7 h-7 text-indigo-500" />
                <span className="ml-4 sr-only">Facebook</span>
              </div>
            </button>
          </div>
          <p className="mt-8 text-center">
            Need an account?{" "}
            <Link href="/signup">
              <a className="text-blue-500 hover:text-blue-700 font-semibold">
                Create an account
              </a>
            </Link>
          </p>
          <p className="mt-12 text-center text-sm">
            By continuing, you agree to our Terms and Conditions and acknowledge
            our use of your information in accordance with our Privacy Notice.
          </p>
        </div>
      </div>
    </section>
  );
}

export async function getServerSideProps (context) {
  const { req } = context;
  let userIsLogged = null;

  try {
    console.log("/LOGIN TOKEN CHECK", req.cookies);
    userIsLogged = await checkUserIsLogged(context);
    console.log("/LOGIN userIsLogged", userIsLogged);

    if (userIsLogged) {
      return {
        redirect: {
          destination: "/dashboard",
          permanent: true,
        },
      };
    }

    return { props: { authorized: false } };
  } catch (err) {
    return { props: { authorized: false } };
  }
};

export default LoginPage;

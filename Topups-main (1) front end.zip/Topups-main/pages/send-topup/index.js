import { Fragment } from "react";
import TopUpPage from "../../components/send-topup-area/send-topup-page";

function SendTopUpPage() {
  return (
    <Fragment>
      <TopUpPage />
    </Fragment>
  );
}

export default SendTopUpPage;

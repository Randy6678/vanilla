import { Fragment } from "react";
import SelectTopUpPackage from "../../components/send-topup-area/select-topup-package-page";
import Container from "../../components/ui/container";

function SelectPackagePage({ country, prov, actNo }) {
  return (
    <Fragment>
      <Container>
        <SelectTopUpPackage country={country} prov={prov} actNo={actNo} />
      </Container>
    </Fragment>
  );
}

export async function getServerSideProps(context) {
  const { country, prov, actNo } = context.query;

  return {
    props: { country, prov, actNo }, // will be passed to the page component as props
  };
}

export default SelectPackagePage;

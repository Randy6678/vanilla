// react
import { useState } from "react";
// next
// import Image from "next/image";
// imports
import { PaystackButton } from "react-paystack";
import { toast } from "react-toastify";
import axios from "axios";

import Container from "../../components/ui/container";

function SummaryPage({ orderDetails }) {
  const [amount, setAmount] = useState(orderDetails.amount);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");

  const onPayStackPaymentSuccess = () => {
    toast.success(
      "Thanks for doing business with us. Your topup would be sent in a few minutes (This is usually instantly)",
      {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      }
    );
  };

  const onPayStackPaymentModalClosed = () => {
    toast.success(
      "Your order would be saved. Visit us anytime to complete it",
      {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      }
    );
  };

  return (
    <section>
      <div className="py-24">
        <Container>
          <div className="flex flex-wrap flex-row lg:flex-nowrap lg:flex-row-reverse gap-x-8 gap-y-12 lg:gap-y-0">
            {/* Order Summary Details */}
            <div className="w-full xl:w-2/5 lg:px-4">
              <div className="px-4 lg:px-6 py-8 bg-white rounded-lg border shadow-lg">
                <h2 className="text-2xl text-gray-800 text-center font-sans font-extrabold leading-tight mb-4">
                  Order Summary
                </h2>
                <hr className="mb-10" />
                <div className="w-full flex flex-wrap gap-y-6 justify-start break-normal whitespace-normal">
                  {/* Country */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Country:
                      </p>
                      {orderDetails.country && (
                        <img
                          src={`https://imagerepo.ding.com/flag/${orderDetails.country.toUpperCase()}.png?height=28&mask=circle&compress=none`}
                          alt="Ghana flag image"
                          width={28}
                          height={28}
                          className="mx-2"
                        />
                      )}
                      <p className="text-xl font-sans whitespace-nowrap text-gray-600">
                        Ghana
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <button className="text-base font-medium font-sans whitespace-nowrap text-red-400 hover:text-red-600 hover:transition-all hover:duration-500 hover:scale-110">
                        Edit
                      </button>
                    </div>
                  </div>
                  {/* Operator */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Operator:
                      </p>
                      {orderDetails.providerLogo && (
                        <img
                          src={`${orderDetails.providerLogo}?height=28`}
                          alt="Ghana flag image"
                          width={28}
                          height={28}
                          className="mx-2"
                        />
                      )}
                      <p className="text-xl font-sans whitespace-nowrap text-gray-600">
                        {orderDetails.providerName}
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <button className="text-base font-medium font-sans whitespace-nowrap text-red-400 hover:text-red-600 hover:transition-all hover:duration-500 hover:scale-110">
                        Edit
                      </button>
                    </div>
                  </div>
                  {/* Number */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2 gap-x-3">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Number:
                      </p>
                      <p className="text-xl font-sans whitespace-nowrap text-gray-600">
                        {orderDetails.accountNumber}
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <button className="text-base font-medium font-sans whitespace-nowrap text-red-400 hover:text-red-600 hover:transition-all hover:duration-500 hover:scale-110">
                        Edit
                      </button>
                    </div>
                  </div>
                </div>
                <hr className="my-10" />
                <div className="w-full flex flex-wrap gap-y-6 justify-start break-normal whitespace-normal">
                  {/* Recipient Recieve Amount */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2 gap-x-3">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Recipient Receives:
                      </p>
                      <p className="text-xl font-medium font-mono whitespace-nowrap text-gray-600">
                        {orderDetails.recieveAmount} GHS
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <button className="text-base font-medium font-sans whitespace-nowrap text-red-400 hover:text-red-600 hover:transition-all hover:duration-500 hover:scale-110">
                        Edit
                      </button>
                    </div>
                  </div>
                </div>
                <hr className="my-10" />
                <div className="w-full flex flex-wrap gap-y-6 justify-start break-normal whitespace-normal">
                  {/* Topup Send Amount */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2 gap-x-3">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Top-up amount:
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <p className="text-xl font-medium font-mono whitespace-nowrap text-gray-600">
                        {amount} USD
                      </p>
                    </div>
                  </div>
                  {/* Processing fee */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2 gap-x-3">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Proccessing fee:
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <p className="text-xl font-medium font-mono whitespace-nowrap text-gray-600">
                        0.00USD
                      </p>
                    </div>
                  </div>
                  {/* Order Total */}
                  <div className="w-full flex flex-nowrap items-center justify-between -mx-2">
                    <div className="flex justify-start px-2 gap-x-3">
                      <p className="text-xl font-medium font-sans whitespace-nowrap">
                        Total:
                      </p>
                    </div>
                    <div className="flex justify-start px-2">
                      <p className="text-xl font-medium font-mono whitespace-nowrap text-gray-600">
                        {amount} USD
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Area */}
            <div className="w-full xl:w-3/5 lg:px-4">
              <div className="px-4 lg:px-6 py-8 bg-white rounded-lg border shadow-lg">
                <h2 className="text-2xl text-gray-800 text-left font-sans font-extrabold leading-tight mb-4">
                  Payment Methods
                </h2>
                <hr className="mb-10" />
                {/* Payments Options */}
                <div className="mb-10">
                  <label
                    htmlFor="paystack"
                    className="flex items-center justify-between border-b border-gray-100/60 py-4 cursor-pointer"
                  >
                    <div className="flex items-center justify-center gap-x-2">
                      <div>
                        <label
                          htmlFor="paystack"
                          className="flex items-center cursor-pointer"
                        >
                          <input
                            type="radio"
                            className="form-radio h-5 w-5 text-indigo-500"
                            name="payment-option"
                            id="paystack"
                            defaultChecked
                          />
                        </label>
                      </div>
                      <p className="select-text text-lg">Card, Bank, MoMo</p>
                    </div>
                    <div className="flex flex-nowrap justify-end">
                      <img
                        src="https://leadershipmemphis.org/wp-content/uploads/2020/08/780370.png"
                        className="h-8 ml-3"
                      />
                    </div>
                  </label>
                  <label
                    htmlFor="paypal"
                    className="flex items-center justify-between border-b border-gray-100/60 py-4 cursor-pointer"
                  >
                    <div className="flex items-center justify-center gap-x-2">
                      <div>
                        <label
                          htmlFor="paypal"
                          className="flex items-center cursor-pointer"
                        >
                          <input
                            type="radio"
                            className="form-radio h-5 w-5 text-indigo-500"
                            name="payment-option"
                            id="paypal"
                          />
                        </label>
                      </div>
                      <p className="select-text text-lg">Paypal</p>
                    </div>
                    <div className="flex flex-nowrap justify-end">
                      <img
                        src="https://www.sketchappsources.com/resources/source-image/PayPalCard.png"
                        className="h-8 ml-3"
                      />
                    </div>
                  </label>
                </div>
                <hr className="mb-2" />
                {/* Payment Form */}
                <div className="px-2 lg:px-4 py-4 bg-gray-50/5 rounded-md">
                  <form
                    id="paymentForm"
                    className="grid grid-cols-2 gap-x-8 gap-y-8"
                    onSubmit={(event) => event.preventDefault()}
                  >
                    {/* Email */}
                    <div className="col-span-2">
                      <div className="grid">
                        <label
                          htmlFor="email"
                          className="text-base text-gray-700 font-semibold"
                        >
                          Email
                        </label>
                        <input
                          value={email}
                          onChange={(event) => setEmail(event.target.value)}
                          type="email"
                          name="email"
                          id="email"
                          placeholder="Email"
                          className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50/30 focus:outline-none focus:bg-gray-100 ring-1 ring-black ring-opacity-10"
                        />
                      </div>
                    </div>
                    {/* First Name */}
                    <div className="col-span-2 lg:col-span-1">
                      <div className="grid">
                        <label
                          htmlFor="first_name"
                          className="text-base text-gray-700 font-semibold"
                        >
                          First Name
                        </label>
                        <input
                          value={firstName}
                          onChange={(event) => setFirstName(event.target.value)}
                          type="text"
                          name="first_name"
                          id="first_name"
                          placeholder="First Name"
                          className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50/30 focus:outline-none focus:bg-gray-100 ring-1 ring-black ring-opacity-10"
                        />
                      </div>
                    </div>
                    {/* Last Name */}
                    <div className="col-span-2 lg:col-span-1">
                      <div className="grid">
                        <label
                          htmlFor="last_name"
                          className="text-base text-gray-700 font-semibold"
                        >
                          Last Name
                        </label>
                        <input
                          value={lastName}
                          onChange={(event) => setLastName(event.target.value)}
                          type="text"
                          name="last_name"
                          id="last_name"
                          placeholder="Last Name"
                          className="w-full py-3 px-2 mt-3 shadow-inner rounded bg-gray-50/30 focus:outline-none focus:bg-gray-100 ring-1 ring-black ring-opacity-10"
                        />
                      </div>
                    </div>
                    <div className="col-span-2">
                      <PaystackButton
                        className="w-full text-xl font-semibold text-gray-50 mt-3 rounded px-4 py-3 bg-red-500 hover:bg-red-600 hover:shadow disabled:bg-gray-400 disabled:cursor-not-allowed"
                        email={email}
                        amount={amount * 100}
                        currency="GHS"
                        channels={["card", "bank", "mobile_money"]}
                        firstname={firstName}
                        lastname={lastName}
                        phone={phone}
                        transaction_charge=""
                        meta={{
                          name: `${firstName} ${lastName}`,
                          phone: phone,
                        }}
                        publicKey={
                          "pk_test_8878e41d2ca3074812fc5d8b1ec898f44c5ec8c4"
                        }
                        text={`Pay GHS ${amount} Now`}
                        onSuccess={onPayStackPaymentSuccess}
                        onClose={onPayStackPaymentModalClosed}
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </div>
    </section>
  );
}

export async function getServerSideProps(context) {
  const { orderId } = context.params;

  // get order details from database
  const orderResponse = await axios.get(
    `${process.env.backendUrl}/api/orders/${orderId}`
  );

  const order = orderResponse.data;

  if (!order) {
    return {
      notFound: true,
    };
  }

  return {
    props: {
      orderDetails: order,
    }, // will be passed to the page component as props
  };
}

export default SummaryPage;

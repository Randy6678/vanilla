exports.verifyCustomerLogin = async (req, res, next) => {
  const customer = req.customer;

  // return user to client
  res.status(200).json({
    user: customer,
    err: null,
  });
};

exports.userIsLogged = async (req, res, next) => {
  res.json({
    ok: true,
  });
};

const fetch = require("isomorphic-fetch");
const { v4: uuidv4 } = require("uuid");

const Order = require("../models");
const { percentage } = require("../util");

exports.addOrder = async (req, res, next) => {
  const customer = req.customer;
  const { skuCode, sendValue, accountNumber } = req.body;

  // STANDARD SEND TRANSFER CONSTANTS
  const transferQuery = `
  mutation SendTransfer ($skuCode: String!, $sendValue: Float!, $sendCurrencyIso: String!, $accountNumber: String!, $distributorRef, $validateOnly) {
    sendTransfer(
      payload: {
        SkuCode: $skuCode
        SendValue: $sendValue
        SendCurrencyIso: $sendCurrencyIso
        AccountNumber: $accountNumber
        DistributorRef: $distributorRef
        Settings: []
        ValidateOnly: $validateOnly
        BillRef:""
      }
    ) {
      ResultCode
      TransferRecord {
        TransferId {
          TransferRef
          DistributorRef
        }
        SkuCode
        Price {
          CustomerFee
          DistributorFee
          ReceiveValue
          ReceiveCurrencyIso
          ReceiveValueExcludingTax
          TaxRate
          TaxName
          TaxCalculation
          SendValue
          SendCurrencyIso
        }
        CommissionApplied
        StartedUtc
        CompletedUtc
        ProcessingState
        ReceiptText
        ReceiptParams {
          property1
          property2
        }
        AccountNumber
      }
      ErrorCodes {
        Code
        Context
      }
    }
  }
  `;
  const sendCurrencyIso = "USD"; // transfer currency
  const distributorRef = uuidv4(); // uniqui id for identifying transfer
  const validateOnly = true; // to make sure there is no deduction
  const servicePercentage = 3.5;
  const testAccountNumber = "233000000000"; // test account number for testing transfers

  // make an api call to ding to check if topup request will be successfull
  fetch("http://localhost:5000/graphql", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: transferQuery,
      variables: {
        skuCode: skuCode,
        sendValue: sendValue,
        sendCurrencyIso: sendCurrencyIso,
        accountNumber: testAccountNumber, // accountNumber
        distributorRef: distributorRef,
        validateOnly: validateOnly,
      },
    }),
  })
    .then((res) => res.json())
    .then((result) => {
      console.log(result);
      const sendTransfer = result.data.sendTransfer;

      // if there is sendTransfer then request was successfull
      if (sendTranser) {
        const resultCode = sendTransfer.ResultCode;
        const transferRecord = sendTransfer.TransferRecord;

        // if transfer went through successfully
        if (resultCode == 1 && transferRecord?.ProcessingState == "Complete") {
          // add a new order with tranfer details into DB

          // calculating processing fee (%3.5 of [SendValue])
          const serviceFee = percentage(
            transferRecord.Price.SendValue,
            servicePercentage
          );
          // calculating order total [processFee + sendValue + customerFee + distributorFee]
          const orderTotal =
            transferRecord.Price.SendValue +
            transferRecord.Price.CustomerFee +
            transferRecord.Price.CustomerFee +
            serviceFee;

          // creating the order record for DB
          const addedOrder = new Order({
            distributorRef: transferRecord.TransferId.DistributorRef,
            accountNumber: transferRecord.AccountNumber,
            skuCode: transferRecord.SkuCode,
            status: "Pending",
            sendCurrency: transferRecord.Price.SendCurrencyIso,
            sendValue: transferRecord.Price.SendValue,
            receiveCurrency: transferRecord.Price.ReceiveCurrencyIso,
            receiveValue: transferRecord.Price.ReceiveValue,
            dingCommission: transferRecord.Price.CommissionApplied,
            processingFee: serviceFee,
            total: orderTotal,
            customer: customer._id,
          });

          // saving order record in DB
          return addedOrder.save((err, newOrder) => {
            if (err) {
              console.log(err);

              return res.status(500).json({
                status: "failed",
                message: err.message,
                order: null,
                err: err,
              });
            }

            // return order to client
            res.status(200).json({
              status: "success",
              message: "order added successfully",
              order: newOrder,
              err: null,
            });
          });
        }

        // if code execution reaches here ==> an error error occured validating transfer
        throw new Error("Parameters Invalid or Processing Failed");
      }

      // if code execution reaches here then the request failed
      throw new Error("Bad request");
    })
    .catch((err) => {
      console.log(err);

      if (err.message == "Bad request") {
        return res.status(401).json({
          status: "failed",
          message: err.message,
          order: null,
          err: err,
        });
      }

      if (err.message == "Parameters Invalid or Processing Failed") {
        return res.status(422).json({
          status: "failed",
          message: err.message,
          order: null,
          err: err,
        });
      }

      return res.status(400).json({
        status: "failed",
        message: err.message,
        order: null,
        err: err,
      });
    });
};

exports.updateOrder = async (req, res, next) => {
  const customer = req.customer;
  const { skuCode, sendValue, accountNumber } = req.body;
}
const { AuthenticationError } = require("apollo-server-core");

const { dingConnectAxios } = require("../../lib/axios-instances.js");

// SEND TRANSFER MUTATION
exports.sendTransfer = (parent, args, context) => {
  const { accessToken } = context;
  const { payload } = args;

  // console.log(payload);

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // send post request to send transfer end point from ding connect api
  return dingConnectAxios
    .post(
      "/SendTransfer",
      JSON.stringify({
        ...payload,
      }),
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    )
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// ESTIMATE TRANSFER PRICE MUTATION
exports.estimatePrices = (parent, args, context) => {
  const { accessToken } = context;
  const { payload } = args;

  // console.log(payload);

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // send post request to estimate prices end point from ding connect api
  return dingConnectAxios
    .post("/EstimatePrices", JSON.stringify(payload), {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// LIST TRANSFER RECORDS MUTATION
exports.listTransferRecords = (parent, args, context) => {
  const { accessToken } = context;
  const { payload } = args;

  console.log(payload);

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // send post request to list transfer records end point from ding connect api
  return dingConnectAxios
    .post(
      "/ListTransferRecords",
      JSON.stringify({
        ...payload,
      }),
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    )
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// CANCEL TRANSFERS MUTATION
exports.cancelTransfers = (parent, args, context) => {
  const { accessToken } = context;
  const { payload } = args;

  // console.log(payload);

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // send post request to cancel transfers end point from ding connect api
  return dingConnectAxios
    .post("/CancelTransfers", JSON.stringify(payload), {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// LOOKUP BILLS MUTATION
exports.lookupBills = (parent, args, context) => {
  const { accessToken } = context;
  const { payload } = args;

  console.log(payload);

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // send post request to lookup bills end point from ding connect api
  return dingConnectAxios
    .post("/LookupBills", JSON.stringify({ ...payload }), {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

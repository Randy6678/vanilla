const { AuthenticationError } = require("apollo-server-core");

const { dingConnectAxios } = require("../../lib/axios-instances.js");

// Hello World Querying
exports.hello = () => "Hello world!";

// Get Currencies Query
exports.getCurrencies = (parent, args, context) => {
  const { accessToken } = context;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch currencies from ding connect api
  return dingConnectAxios
    .get("/GetCurrencies", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Regions Query
exports.getRegions = (parent, args, context) => {
  const { accessToken } = context;
  const { countryIsos } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch regions from ding connect api
  return dingConnectAxios
    .get("/GetRegions", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: { countryIsos },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Counties Query
exports.getCountries = (parent, args, context) => {
  const { accessToken } = context;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch countries from ding connect api
  return dingConnectAxios
    .get("/GetCountries", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

//  Get Providers Query
exports.getProviders = (parent, args, context) => {
  const { accessToken } = context;
  const { providerCodes, countryIsos, regionCodes, accountNumber } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch providers from ding connect api
  return dingConnectAxios
    .get("/GetProviders", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        providerCodes,
        countryIsos,
        regionCodes,
        accountNumber,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

//  Get Providers Status Query
exports.getProviderStatus = (parent, args, context) => {
  const { accessToken } = context;
  const { providerCodes } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch provider status from ding connect api
  return dingConnectAxios
    .get("/GetProviderStatus", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        providerCodes,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

//  Get Products Query
exports.getProducts = (parent, args, context) => {
  const { accessToken } = context;
  const {
    countryIsos,
    providerCodes,
    skuCodes,
    benefits,
    regionCodes,
    accountNumber,
  } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch products from ding connect api
  return dingConnectAxios
    .get("/GetProducts", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        countryIsos,
        providerCodes,
        skuCodes,
        benefits,
        regionCodes,
        accountNumber,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Product Description From Ding Connect API
exports.getProductDescriptions = (parent, args, context) => {
  const { accessToken } = context;
  const { languageCodes, skuCodes } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch product description from ding connect api
  return dingConnectAxios
    .get("/GetProductDescriptions", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        languageCodes,
        skuCodes,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Balance From Ding Connect API
exports.getBalance = (parent, args, context) => {
  const { accessToken } = context;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch balance from ding connect api
  return dingConnectAxios
    .get("/GetBalance", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Promotions From Ding Connect API
exports.getPromotions = (parent, args, context) => {
  const { accessToken } = context;
  const { countryIsos, providerCodes, accountNumber } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch promotions from ding connect api
  return dingConnectAxios
    .get("/GetPromotions", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        countryIsos,
        providerCodes,
        accountNumber,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Promotions Descriptions From Ding Connect API
exports.getPromotionDescriptions = (parent, args, context) => {
  const { accessToken } = context;
  const { languageCodes } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch promotions descriptions from ding connect api
  return dingConnectAxios
    .get("/GetPromotionDescriptions", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        languageCodes,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// Get Account Look up From Ding Connect API
exports.getAccountLookup = (parent, args, context) => {
  const { accessToken } = context;
  const { accountNumber } = args;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch account look up from ding connect api
  return dingConnectAxios
    .get("/GetAccountLookup", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      params: {
        accountNumber,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

// GET ERROR CODES DESCRIPTIONS QUERY
exports.getErrorCodeDescriptions = (parent, args, context) => {
  const { accessToken } = context;

  // check if session is authenticated
  if (!accessToken) {
    throw new AuthenticationError("Session not authorized");
  }

  // fetch error code descriptions from ding connect api
  return dingConnectAxios
    .get("/GetErrorCodeDescriptions", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })
    .then((res) => {
      // console.log(res.data);
      if (res.status === 200) {
        return res.data;
      }
    })
    .catch((err) => {
      // console.log(err);
      return err.response.data;
    });
};

const { gql } = require("apollo-server-express");

const typeDefs = gql`
  type ErrorCode {
    Code: String
    Context: String
  }
  type DailingInfo {
    Prefix: String
    MinimumLength: Int
    MaximumLength: Int
  }
  type Currency {
    CurrencyIso: String!
    CurrencyName: String!
  }
  type GetCurrenciesResponse {
    ResultCode: Int
    Items: [Currency]
    ErrorCodes: [ErrorCode]
  }
  type Region {
    RegionCode: String!
    RegionName: String!
    CountryIso: String!
  }
  type GetRegionsResponse {
    ResultCode: Int
    Items: [Region]
    ErrorCodes: [ErrorCode]
  }
  type Country {
    CountryIso: String!
    CountryName: String!
    InternationalDialingInformation: [DailingInfo]!
    RegionCodes: [String]!
  }
  type GetCountriesResponse {
    ResultCode: Int
    Items: [Country]
    ErrorCodes: [ErrorCode]
  }
  type Provider {
    ProviderCode: String
    CountryIso: String
    Name: String
    ShortName: String
    ValidationRegex: String
    CustomerCareNumber: String
    RegionCodes: [String]!
    PaymentTypes: [String]!
    LogoUrl: String
  }
  type GetProvidersResponse {
    ResultCode: Int
    Items: [Provider]
    ErrorCodes: [ErrorCode]
  }
  type ProviderStatus {
    ProviderCode: String!
    IsProcessingTransfers: Boolean!
    Message: String!
  }
  type GetProviderStatusResponse {
    ResultCode: Int
    Items: [ProviderStatus]
    ErrorCodes: [ErrorCode]
  }
  type Product {
    ProviderCode: String
    SkuCode: String
    LocalizationKey: String
    SettingDefinitions: [ProductSettingDefinitions]!
    Maximum: ProductMaximum
    Minimum: ProductMinimum
    CommissionRate: Float
    ProcessingMode: String
    RedemptionMechanism: String
    Benefits: [String]
    ValidityPeriodIso: String
    UatNumber: String
    AdditionalInformation: String
    DefaultDisplayText: String
    RegionCode: String
    PaymentTypes: [String]
    LookupBillsRequired: Boolean
  }
  type GetProductsResponse {
    ResultCode: Int
    Items: [Product]
    ErrorCodes: [ErrorCode]
  }
  type ProductSettingDefinitions {
    Name: String
    Description: String
    IsMandatory: Boolean
  }
  type ProductMaximum {
    CustomerFee: Float
    DistributorFee: Float
    ReceiveValue: Float
    ReceiveCurrencyIso: String
    ReceiveValueExcludingTax: Float
    TaxRate: Float
    TaxName: String
    TaxCalculation: String
    SendValue: Float
    SendCurrencyIso: String
  }
  type ProductMinimum {
    CustomerFee: Float
    DistributorFee: Float
    ReceiveValue: Float
    ReceiveCurrencyIso: String
    ReceiveValueExcludingTax: Float
    TaxRate: Float
    TaxName: String
    TaxCalculation: String
    SendValue: Float
    SendCurrencyIso: String
  }
  type ProductDescription {
    DisplayText: String
    DescriptionMarkdown: String
    ReadMoreMarkdown: String
    LocalizationKey: String
    LanguageCode: String
  }
  type GetProductDescriptionsResponse {
    ResultCode: Int
    Items: [ProductDescription]
    ErrorCodes: [ErrorCode]
  }
  type Balance {
    Balance: Float
    CurrencyIso: String
  }
  type GetBalanceResponse {
    ResultCode: Int
    Balance: Float
    CurrencyIso: String
    ErrorCodes: [ErrorCode]
  }
  type Promotion {
    ProviderCode: String
    StartUtc: String
    EndUtc: String
    CurrencyIso: String
    ValidityPeriodIso: String
    MinimumSendAmount: Float
    LocalizationKey: String
  }
  type GetPromotionsResponse {
    ResultCode: Int
    Items: [Promotion]
    ErrorCodes: [ErrorCode]
  }
  type PromotionDescription {
    Dates: String
    Headline: String
    TermsAndConditionsMarkDown: String
    BonusValidity: String
    PromotionType: String
    LocalizationKey: String
    LanguageCode: String
  }
  type GetPromotionDescriptionsResponse {
    ResultCode: Int
    Items: [PromotionDescription]
    ErrorCodes: [ErrorCode]
  }
  type AccountLookup {
    CountryIso: String
    AccountNumberNormalized: String
    Items: [Account]
  }
  type Account {
    ProviderCode: String
    RegionCode: String
  }
  type GetAccountLookupResponse {
    ResultCode: Int
    CountryIso: String
    AccountNumberNormalized: String
    Items: [Account]
    ErrorCodes: [ErrorCode]
  }
  type ErrorCodeDescription {
    Message: String
    Code: String
  }
  type GetErrorCodeDescriptionsResponse {
    ResultCode: Int
    Items: [ErrorCodeDescription]
    ErrorCodes: [ErrorCode]
  }
  type TransferId {
    TransferRef: String
    DistributorRef: String
  }
  type TransferPrice {
    CustomerFee: Float
    DistributorFee: Float
    ReceiveValue: Float
    ReceiveCurrencyIso: String
    ReceiveValueExcludingTax: Float
    TaxRate: Float
    TaxName: String
    TaxCalculation: String
    SendValue: Float
    SendCurrencyIso: String
  }
  type ReceiptParam {
    property1: String
    property2: String
  }
  type TransferRecord {
    TransferId: TransferId
    SkuCode: String
    Price: TransferPrice
    CommissionApplied: Float
    StartedUtc: String
    CompletedUtc: String
    ProcessingState: String
    ReceiptText: String
    ReceiptParams: ReceiptParam
    AccountNumber: String
  }
  type SendTransferResponse {
    ResultCode: Int
    TransferRecord: TransferRecord
    ErrorCodes: [ErrorCode]
  }
  type EstimatePrice {
    Price: TransferPrice
    SkuCode: String
    BatchItemRef: String
  }
  type EstimatePricesResponse {
    ResultCode: Int
    Items: [EstimatePrice]
    ErrorCodes: [ErrorCode]
  }
  type ListTransferRecord {
    TransferRecord: TransferRecord
    ResultCode: Int
    ErrorCodes: [ErrorCode]
  }
  type ListTransferRecordsResponse {
    ResultCode: Int
    Items: [ListTransferRecord]
    ThereAreMoreItems: Boolean
    ErrorCodes: [ErrorCode]
  }
  type CanceledTransfer {
    TransferId: TransferId
    ProcessingState: String
    BatchItemRef: String
  }
  type CancelTransferResponse {
    ResultCode: Int
    Items: [CanceledTransfer]
    ErrorCodes: [ErrorCode]
  }
  type LookupBill {
    Price: TransferPrice
    BillRef: String
    AdditionalInfo: ReceiptParam
  }
  type LookupBillsResponse {
    ResultCode: Int
    Items: [LookupBill]
    ErrorCodes: [ErrorCode]
  }
  input TransferIdInput {
    TransferRef: String!
    DistributorRef: String!
  }
  input TransferSetting {
    Name: String
    Value: String
  }
  input SendTransferPayload {
    SkuCode: String!
    SendValue: Float!
    SendCurrencyIso: String
    AccountNumber: String!
    DistributorRef: String!
    Settings: [TransferSetting]
    ValidateOnly: Boolean!
    BillRef: String
  }
  input EstimatePricePayload {
    SendValue: Float
    SendCurrencyIso: String
    ReceiveValue: Float
    SkuCode: String!
    BatchItemRef: String!
  }
  input TransferRecordPayload {
    TransferRef: String
    DistributorRef: String
    AccountNumber: String
    Skip: Int
    Take: Int!
  }
  input CancelTransferPayload {
    TransferId: TransferIdInput!
    BatchItemRef: String!
  }
  input LookupBillPayload {
    SkuCode: String!
    AccountNumber: String!
    Settings: TransferSetting
  }
  type Query {
    hello: String
    getCurrencies: GetCurrenciesResponse!
    getRegions(countryIsos: [String]): GetRegionsResponse!
    getCountries: GetCountriesResponse!
    getProviders(
      providerCodes: [String]
      countryIsos: [String]
      regionCodes: [String]
      accountNumber: String
    ): GetProvidersResponse!
    getProviderStatus(providerCodes: [String]): GetProviderStatusResponse!
    getProducts(
      countryIsos: [String]
      providerCodes: [String]
      skuCodes: [String]
      benefits: [String]
      regionCodes: [String]
      accountNumber: String
    ): GetProductsResponse!
    getProductDescriptions(
      languageCodes: [String]
      skuCodes: [String]
    ): GetProductDescriptionsResponse!
    getBalance: GetBalanceResponse!
    getPromotions(
      countryIsos: [String]
      providerCodes: [String]
      accountNumber: String
    ): GetPromotionsResponse!
    getPromotionDescriptions(
      languageCodes: String
    ): GetPromotionDescriptionsResponse!
    getAccountLookup(accountNumber: String!): GetAccountLookupResponse!
    getErrorCodeDescriptions: GetErrorCodeDescriptionsResponse!
  }
  type Mutation {
    sendTransfer(payload: SendTransferPayload): SendTransferResponse!
    estimatePrices(payload: [EstimatePricePayload]): EstimatePricesResponse!
    listTransferRecords(
      payload: TransferRecordPayload
    ): ListTransferRecordsResponse!
    cancelTransfers(payload: [CancelTransferPayload]): CancelTransferResponse!
    lookupBills(payload: LookupBillPayload): LookupBillsResponse!
  }
`;

module.exports = typeDefs;
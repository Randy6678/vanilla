const { Customer } = require("../models");
const firebaseAdmin = require("../firebase");

exports.findOrCreateCustomer = async (req, res, next) => {
  const authorizationHeader = req.headers.authorization;
  // console.log(req.headers)
  // console.log(authorizationHeader)
  const token = authorizationHeader
    ? authorizationHeader.split("Bearer").pop().trim()
    : "";
  console.log("REQ FIREBASE USER TOKEN", token);

  try {
    const customer = await firebaseAdmin.auth().verifyIdToken(token);

    // the user is authenticated!
    const { name, email } = customer;

    // check if user is already in DB
    const existingCustomer = await Customer.findOne({ email: email });

    if (existingCustomer) {
      req.customer = existingCustomer;
    } else {
      const newCustomer = new Customer({
        name: name ? name : email.split("@").shift(),
        email: email,
      }).save();

      req.customer = newCustomer;
    }

    next();
  } catch (error) {
    console.log("SERVER ERROR", error)
    res.status(401).json({
      user: null,
      err: "Invalid or expired user token",
    });
  }
};

const axios = require("axios");

const {
  getAuthAnalytics,
  setAuthAnalytics,
} = require("../lib/auth-analytics.js");

const axiosConfig = {
  headers: {
    "Content-Type": "application/x-www-form-urlencoded",
  },
};

const params = new URLSearchParams();
params.append("client_id", "1afab676-da90-47f0-a6b0-fb979729fa51");
params.append("client_secret", "4s//MpgCxnjdnfZN7aXsYudwGbhF0lLx9RyTTP3LNF8=");
params.append("grant_type", "client_credentials");

exports.checkIsAuth = async (req, res, next) => {
  const authAnalytics = getAuthAnalytics();
  if (authAnalytics.expiresAt <= Date.now()) {
    try {
      const response = await axios.post(
        "https://idp.ding.com/connect/token",
        params,
        axiosConfig
      );

      const { access_token, expires_in } = response.data;

      const currentDate = new Date();
      currentDate.setSeconds(currentDate.getSeconds() + expires_in);

      const newAuthAnalytics = {
        access_token,
        last_authenticated: Date.now(),
        expiresAt: currentDate.getTime(),
        auth_count: authAnalytics.auth_count + 1,
      };

      setAuthAnalytics(newAuthAnalytics);
    } catch (error) {
      // An Error Occurred
      req.dcAuthAt = null;
      return next();
    }
  }

  req.dcAuthAt = authAnalytics.access_token;
  next();
};

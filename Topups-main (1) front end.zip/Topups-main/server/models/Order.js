const mongoose = require("mongoose");

const Schema = mongoose.Schema;

var payer = new Schema({
  name: String,
});

const orderSchema = new Schema(
  {
    distributorRef: {
      type: String,
      trim: true,
      required: true,
    },
    accountNumber: {
      type: String,
      trim: true,
      required: true,
    },
    skuCode: {
      type: String,
      trim: true,
      required: true,
    },
    status: {
      type: String,
      enum: ["Pending", "Cancelled", "Completed"],
      default: "Pending",
      required: true,
    },
    sendCurrency: {
      type: String,
      required: true,
    },
    sendValue: {
      type: Number,
      required: true,
    },
    receiveCurrency: {
      type: Number,
      required: true,
    },
    receiveValue: {
      type: Number,
      required: true,
    },
    dingCommission: {
      type: Number,
      required: true,
    },
    processingFee: { // 5% of (sendValue + tax + customerfee + distributorfee)
      type: Number,
      required: true,
    },
    total: {
      type: Number,
      required: true,
    },
    customer: {
      type: Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },
    payment: {
      type: Schema.Types.ObjectId,
      ref: "Payment",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);

const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const payer = new Schema({
  firstName: {
    type: String,
    trim: true,
    required: true,
  },
  lastName: {
    type: String,
    trim: true,
    required: true,
  },
  email: {
    type: String,
    trim: true,
    required: true,
  },
  phone: String,
});

const paymentSchema = new Schema(
  {
    transferRef: {
      type: String,
      trim: true,
      required: true,
    },
    payer: payer,
    channel: {
      type: String,
      enum: ["bank", "bank_transfer", "card", "mobile_money", "qr", "ussd"],
      required: true,
    },
    status: {
      type: String,
      enum: ["Pending", "Success", "Failed"],
      default: "Pending",
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    chargedAmount: {
      type: Number,
      required: true,
    },
    currency: {
      type: String,
      default: "GHS",
      required: true,
    },
    order: {
      type: Schema.Types.ObjectId,
      ref: "Order",
      required: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Payment", paymentSchema);

const Customer = require("./Customer");
const Order = require("./Order");
const Payment = require("./Payment");

module.exports = { Customer, Order, Payment };

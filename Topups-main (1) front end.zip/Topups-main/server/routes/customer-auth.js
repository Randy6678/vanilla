const express = require("express");

const { findOrCreateCustomer } = require("../middlewares/customer-auth");
const {
  verifyCustomerLogin,
  userIsLogged,
} = require("../controllers/customer-auth");

const router = express.Router();

router.post("/verify-login", findOrCreateCustomer, verifyCustomerLogin);

router.get("/logged-user", findOrCreateCustomer, userIsLogged);

module.exports = router;

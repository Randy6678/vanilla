const express = require("express");

const { findOrCreateCustomer } = require("../middlewares/customer-auth");
const { addOrder, updateOrder } = require("../controllers/order");

const router = express.Router();

router.post("/", findOrCreateCustomer, addOrder);

router.put("/", findOrCreateCustomer, updateOrder);

module.exports = router;

exports.percentage = (num, per) =>{
  return (num/100)*per;
}
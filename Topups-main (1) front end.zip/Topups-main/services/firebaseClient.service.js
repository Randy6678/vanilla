import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  FacebookAuthProvider,
  TwitterAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from "firebase/auth";

const firebaseAuth = {
  getAuth,
  GoogleAuthProvider,
  FacebookAuthProvider,
  TwitterAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
};

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA1NCZvDwEvnP0EwozrbfCCqDE8t4yWNXQ",
  authDomain: "send-topups.firebaseapp.com",
  projectId: "send-topups",
  storageBucket: "send-topups.appspot.com",
  messagingSenderId: "558283007361",
  appId: "1:558283007361:web:1cf39b76824659d1fdf480",
  measurementId: "G-R5R1CJWRV1",
};

// Initialize Firebase
const firebaseApp = !getApps().length
  ? initializeApp(firebaseConfig)
  : getApp();

export { firebaseApp, firebaseAuth };

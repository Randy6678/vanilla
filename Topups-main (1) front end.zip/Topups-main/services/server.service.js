import axios from "axios";

export async function getActiveLoggedUser(ctx) {
  const {
    req: { cookies },
  } = ctx;
  console.log("GET ACTIVE LOGGED USER", cookies);

  let currentUser = null;

  try {
    currentUser = await axios
      .post(`${process.env.appAuthApi}/verify-login`, null, {
        headers: {
          Authorization: `Bearer ${cookies.token}`,
        },
      })
      .then((response) => {
        // console.log("RESPONSE", response);

        const user = response.data.user;

        return user;
      });
  } catch (error) {
    currentUser = null;
  }

  return currentUser;
}

export async function checkUserIsLogged(ctx) {
  const {
    req: { cookies },
  } = ctx;
  console.log("CHECK USER ISLOGGED", cookies);

  try {
    const userIsLogged = await axios
      .get(`${process.env.appAuthApi}/logged-user`, {
        headers: {
          Authorization: `Bearer ${cookies.token}`,
        },
      })
      .then((response) => {
        // console.log("RESPONSE", response);

        const isLogged = response.data.ok;

        console.log("SERVICE userIsLogged", isLogged);

        return isLogged;
      });

    return userIsLogged;
  } catch (error) {
    console.log("SERVICE Error userIsLogged", false);

    return false;
  }
}

export async function fetchSupportedCountries() {
  const ALL_SUPPORTED_COUNTRIES = `
  query FetchSupportedCountries {
    getCountries {
      ResultCode
      Items {
        CountryIso
        CountryName
        InternationalDialingInformation {
          Prefix
          MinimumLength
          MaximumLength
        }
      }
      ErrorCodes {
        Code
        Context
      }
    }
  }`;

  const data = JSON.stringify({
    query: ALL_SUPPORTED_COUNTRIES,
  });

  return fetch(process.env.appDingGraphql, {
    method: "POST",
    body: data,
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((result) => {
      console.log("ALL_SUPPORTED_COUNTRIES", result);
      let countries = [];

      if (result.data.getCountries?.Items.length) {
        countries = result.data.getCountries?.Items.map(
          (item) => item.CountryIso
        );
      }
      return countries;
    })
    .catch((err) => {
      console.log(err);
      return [];
    });
}

import axios from "axios";

import Router from "next/router";

import { firebaseApp, firebaseAuth } from "./firebaseClient.service";

import { axiosAuth } from "../helpers/axios-instances";

function getAuthenticatedUser(token) {
  if (token) {
    return axios
      .post(`${process.env.appAuthApi}/verify-login`, null, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        // console.log("RESPONSE", response);

        const user = response.data.user;

        return user;
      });
  }

  return axiosAuth.post("/verify-login").then((response) => {
    // console.log("RESPONSE", response);

    const user = response.data.user;

    return user;
  });
}

function signupWithEmailAndPassword(email, password) {
  const authInstance = firebaseAuth.getAuth();

  return firebaseAuth
    .createUserWithEmailAndPassword(authInstance, email, password)
    .then(async (result) => {
      console.log("LOGIN", result);

      const user = result.user;

      const token = await user.getIdToken();

      return token;
    })
    .catch((error) => {
      console.log("SIGNUP", error);
      throw Error(error);
    });
}

function loginWithEmailAndPassword(email, password) {
  const authInstance = firebaseAuth.getAuth();

  return firebaseAuth
    .signInWithEmailAndPassword(authInstance, email, password)
    .then(async (result) => {
      console.log("LOGIN", result);

      const user = result.user;

      const token = await user.getIdToken();

      return token;
    })
    .catch((error) => {
      console.log("LOGIN", error);
      throw Error(error);
    });
}

function loginWithGoogle() {
  const provider = new firebaseAuth.GoogleAuthProvider();
  const authInstance = firebaseAuth.getAuth();

  return firebaseAuth
    .signInWithPopup(authInstance, provider)
    .then((result) => {
      console.log("LOGIN", result);

      const credential =
        firebaseAuth.GoogleAuthProvider.credentialFromResult(result);
      const token = credential.accessToken;

      return token;
    })
    .catch((error) => {
      console.log("LOGIN WITH GOOGLE", error);
      throw Error(error);
    });
}

function loginWithFacebook() {
  const provider = new firebaseAuth.FacebookAuthProvider();
  provider.setCustomParameters({
    display: "popup",
  });
  const authInstance = firebaseAuth.getAuth();

  return firebaseAuth
    .signInWithPopup(authInstance, provider)
    .then((result) => {
      console.log("LOGIN WITH FACEBOOK", result);

      const credential =
        firebaseAuth.FacebookAuthProvider.credentialFromResult(result);
      const token = credential.accessToken;

      return token;
    })
    .catch((error) => {
      console.log("LOGIN", error);
      throw Error(error);
    });
}

async function logout() {
  await firebaseAuth.getAuth(firebaseApp).signOut();
  // remove user token from cookies and redirect to login page

  // destroyCookie(null, "token");
  // setCookie(null, "token", "", {});
  // Router.push("/login");
}

export const userService = {
  getAuthenticatedUser,
  signupWithEmailAndPassword,
  loginWithEmailAndPassword,
  loginWithGoogle,
  loginWithFacebook,
  logout,
};

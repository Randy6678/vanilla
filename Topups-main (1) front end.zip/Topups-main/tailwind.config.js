module.exports = {
  // important: true,
  mode: "jit",
  purge: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      gridTemplateColumns: {
        "auto-full": "auto 1fr",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};

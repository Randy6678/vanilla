-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "providerLogo" TEXT;

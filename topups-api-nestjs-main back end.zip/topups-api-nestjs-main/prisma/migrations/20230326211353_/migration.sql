-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "recieveAmount" INTEGER;

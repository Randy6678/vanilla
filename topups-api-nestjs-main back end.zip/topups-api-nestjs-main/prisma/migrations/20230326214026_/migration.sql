-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "country" TEXT,
ADD COLUMN     "providerName" TEXT;

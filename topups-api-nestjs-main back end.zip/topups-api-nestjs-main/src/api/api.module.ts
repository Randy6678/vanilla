import { Module } from '@nestjs/common';

// controller
import { ApiController } from './api.controller';

// services
import { ApiService } from './api.service';

// modules
import { OrderModule } from './order/order.module';

@Module({
  imports: [OrderModule],
  controllers: [ApiController],
  providers: [ApiService],
})
export class ApiModule {}

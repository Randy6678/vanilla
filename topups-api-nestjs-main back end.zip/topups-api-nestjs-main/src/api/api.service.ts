import { Injectable } from '@nestjs/common';

// common
import {
  SupportedCountryIsos,
  SupportedCurrencies,
  SupportedRegions,
} from '../common/enums';
// app axios
import { appApiAxios } from '../common/lib/axios-instances';

// constants
const supportedCountryValues = Object.values(SupportedCountryIsos);
const supportedCurrencyValues = Object.values(SupportedCurrencies);
const supportedRegionValues = Object.values(SupportedRegions);

@Injectable()
export class ApiService {
  async getAccountLookup(accountNumber: string) {
    try {
      const response = await appApiAxios.get('/ding-connect/GetAccountLookup', {
        params: {
          accountNumber,
        },
      });

      if (response.status === 200) {
        const data = response.data;
        const filteredItems = data.Items.filter((item) =>
          supportedRegionValues.includes(
            item?.RegionCode as unknown as SupportedRegions,
          ),
        );

        // delete ResultCode and ErrorCodes from response
        delete data['ResultCode'];
        delete data['ErrorCodes'];
        return { ...data, Items: filteredItems };
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getCountries() {
    try {
      const response = await appApiAxios.get('/ding-connect/GetCountries');

      if (response.status === 200) {
        const data = response.data;
        const items = data.Items.filter((item) =>
          supportedCountryValues.includes(
            item?.CountryIso as unknown as SupportedCountryIsos,
          ),
        );
        return items;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getCurrencies() {
    try {
      const response = await appApiAxios.get('/ding-connect/GetCurrencies');

      if (response.status === 200) {
        const data = response.data;
        const items = data.Items.filter((item) =>
          supportedCurrencyValues.includes(
            item?.CurrencyIso as unknown as SupportedCurrencies,
          ),
        );
        return items;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getRegions(queryOptions: { countryIsos: string[] }) {
    // filter to limit supported countries
    const countryIsos: string[] = queryOptions?.countryIsos
      ? queryOptions.countryIsos.filter((countryIso) =>
          supportedCountryValues.includes(
            countryIso as unknown as SupportedCountryIsos,
          ),
        )
      : supportedCountryValues;

    try {
      const response = await appApiAxios.get('/ding-connect/GetRegions', {
        params: {
          countryIsos: countryIsos.length
            ? countryIsos
            : supportedCountryValues,
        },
      });

      if (response.status === 200) {
        const data = response.data;
        return data.Items;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProductDescriptions(queryOptions: {
    languageCodes: string[];
    skuCodes: string[];
  }) {
    try {
      const response = await appApiAxios.get(
        '/ding-connect/GetProductDescriptions',
        {
          params: {
            languageCodes: queryOptions.languageCodes,
            skuCodes: queryOptions.skuCodes,
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProducts(queryOptions: {
    countryIsos: string[];
    providerCodes: string[];
    skuCodes: string[];
    benefits: string[];
    regionCodes: string[];
    accountNumber?: string;
  }) {
    // filter to limit supported countries
    const countryIsos: string[] = queryOptions?.countryIsos
      ? queryOptions.countryIsos.filter((countryIso) =>
          supportedCountryValues.includes(
            countryIso as unknown as SupportedCountryIsos,
          ),
        )
      : supportedCountryValues;

    // filter to limit supported regions
    const regionCodes: string[] = queryOptions?.regionCodes
      ? queryOptions.regionCodes.filter((regionCode) =>
          supportedRegionValues.includes(
            regionCode as unknown as SupportedRegions,
          ),
        )
      : supportedRegionValues;

    try {
      const response = await appApiAxios.get('/ding-connect/GetProducts', {
        params: {
          countryIsos: countryIsos.length
            ? countryIsos
            : supportedCountryValues,
          providerCodes: queryOptions.providerCodes,
          skuCodes: queryOptions.skuCodes,
          benefits: queryOptions.benefits,
          regionCodes: regionCodes.length ? regionCodes : supportedRegionValues,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getPromotionDescriptions(queryOptions: { languageCodes: string[] }) {
    try {
      const response = await appApiAxios.get(
        '/ding-connect/GetPromotionDescriptions',
        {
          params: {
            languageCodes: queryOptions.languageCodes,
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getPromotions(queryOptions: {
    countryIsos: string[];
    providerCodes: string[];
    accountNumber?: string;
  }) {
    // filter to limit supported countries
    const countryIsos: string[] = queryOptions?.countryIsos
      ? queryOptions.countryIsos.filter((countryIso) =>
          supportedCountryValues.includes(
            countryIso as unknown as SupportedCountryIsos,
          ),
        )
      : supportedCountryValues;

    try {
      const response = await appApiAxios.get('/ding-connect/GetPromotions', {
        params: {
          countryIsos: countryIsos.length
            ? countryIsos
            : supportedCountryValues,
          providerCodes: queryOptions.providerCodes,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProviders(queryOptions: {
    providerCodes: string[];
    countryIsos: string[];
    regionCodes: string[];
    accountNumber?: string;
  }) {
    // filter to limit supported countries
    const countryIsos: string[] = queryOptions?.countryIsos
      ? queryOptions.countryIsos.filter((countryIso) =>
          supportedCountryValues.includes(
            countryIso as unknown as SupportedCountryIsos,
          ),
        )
      : supportedCountryValues;

    // filter to limit supported regions
    const regionCodes: string[] = queryOptions?.regionCodes
      ? queryOptions.regionCodes.filter((regionCode) =>
          supportedRegionValues.includes(
            regionCode as unknown as SupportedRegions,
          ),
        )
      : supportedRegionValues;

    try {
      const response = await appApiAxios.get('/ding-connect/GetProviders', {
        params: {
          providerCodes: queryOptions.providerCodes,
          countryIsos: countryIsos.length
            ? countryIsos
            : supportedCountryValues,
          regionCodes: regionCodes.length ? regionCodes : supportedRegionValues,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProviderStatus(queryOptions: { providerCodes: string[] }) {
    try {
      const response = await appApiAxios.get(
        '/ding-connect/GetProviderStatus',
        {
          params: {
            providerCodes: queryOptions.providerCodes,
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }
}

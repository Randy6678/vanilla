import { IsString, IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { ArgsType, Field } from '@nestjs/graphql';

@ArgsType()
export class AddOrderInput {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The iso code for the country where the order is being placed',
  })
  @Field({
    name: 'countryIso',
    nullable: false,
    description: 'The iso code for the country where the order is being placed',
  })
  countryIso: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The code of the provider that the order is being placed with',
  })
  @Field({
    name: 'providerCode',
    nullable: false,
    description: 'The code of the provider that the order is being placed with',
  })
  providerCode: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The sku code of the product that is being ordered',
  })
  @Field({
    name: 'productSkuCode',
    nullable: false,
    description: 'The sku code of the product that is being ordered',
  })
  productSkuCode: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The send amount/cost of the product that is being ordered',
  })
  @Field({
    name: 'productSendAmount',
    nullable: false,
    description: 'The send amount/cost of the product that is being ordered',
  })
  productSendAmount: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description:
      'The receive amount/value of the product that is being ordered',
  })
  @Field({
    name: 'productReceiveAmount',
    nullable: false,
    description:
      'The receive amount/value of the product that is being ordered',
  })
  productReceiveAmount: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description:
      'The phone number of the receiver, the account number should be in international phone number format.',
    default: '',
  })
  @Field({
    name: 'accountNumber',
    nullable: true,
    description:
      'The phone number of the receiver, the account number should be in international phone number format.',
  })
  accountNumber: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'Provider Logo',
  })
  @Field({
    name: 'providerLogo',
    nullable: false,
    description: 'Provider Logo',
  })
  providerLogo: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'Provider Name',
  })
  @Field({
    name: 'providerName',
    nullable: false,
    description: 'Provider Name',
  })
  providerName: string;
}

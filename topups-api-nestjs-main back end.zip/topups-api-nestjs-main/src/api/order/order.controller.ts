import { Body, Controller, Get, Param, Post } from '@nestjs/common';
// swagger
import {
  ApiTags,
  ApiOperation,
  ApiOkResponse,
  ApiUnauthorizedResponse,
  ApiResponse,
} from '@nestjs/swagger';

// services
import { OrderService } from './order.service';

// dtos
import { AddOrderInput } from './dto/add-order.input';

@ApiTags('api/orders')
@Controller('api/orders')
export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  // Add a new order
  @ApiOperation({
    summary: 'Add a new order',
    description: 'Adds a new order to the system.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post()
  async addOrder(@Body() body: AddOrderInput) {
    return this.orderService.addNewOrder(body);
  }

  // Get An Order
  @ApiOperation({
    summary: 'Get order details for a specific order ID',
    description: 'Returns order details for the order ID.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get(':orderId')
  async getSingleOrder(@Param('orderId') orderId: string) {
    return this.orderService.getOrder(orderId);
  }
}

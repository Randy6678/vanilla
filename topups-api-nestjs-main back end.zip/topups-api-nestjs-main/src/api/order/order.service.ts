import { BadRequestException, Injectable } from '@nestjs/common';

// services
import { PrismaService } from '../..//prisma/prisma.service';

// dtos
import { AddOrderInput } from './dto/add-order.input';

// app axios
import { appApiAxios } from '../../common/lib/axios-instances';

@Injectable()
export class OrderService {
  constructor(private readonly prisma: PrismaService) {}

  async addNewOrder(input: AddOrderInput) {
    console.log('input', input);
    // get the product info by sku code
    const response = await appApiAxios.get('/ding-connect/GetProducts', {
      params: {
        skuCodes: [input.productSkuCode],
        accountNumber: input.accountNumber,
      },
    });

    // if the response is not 200, return the error
    if (response.status !== 200) {
      console.log('response', response);
      throw new BadRequestException('Error getting product info');
    }

    console.log('response', response.data);
    const product = response.data.Items[0];

    // if the product is not found, return the error
    if (!product) {
      console.log('product', product);
      throw new BadRequestException('Product not found');
    }

    console.log('product', product);

    // if the amount to send is not inclusively between the min and max send amount
    if (
      input.productSendAmount < product.Minimum.SendValue ||
      input.productSendAmount > product.Maximum.SendValue
    ) {
      console.log('input.productSendAmount', input.productSendAmount);
      throw new BadRequestException(
        'Amount to send is not inclusively between the min and max send amount',
      );
    }

    // add the order to the database as pending
    return await this.prisma.order.create({
      data: {
        amount: input.productSendAmount,
        status: 'PENDING',
        productId: input.productSkuCode,
        accountNumber: input.accountNumber,
        providerLogo: input.providerLogo,
        providerName: input.providerName,
        recieveAmount: input.productReceiveAmount,
        country: input.countryIso,
      },
    });
  }

  async getOrder(id: string) {
    const order = await this.prisma.order.findUnique({
      where: {
        id,
      },
    });

    return {
      ...order,
      amount: Number(order.amount),
      recieveAmount: Number(order.recieveAmount),
    };
  }
}

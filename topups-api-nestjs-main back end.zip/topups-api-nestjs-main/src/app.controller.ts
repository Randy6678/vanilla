import { Controller, Get, Request } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(@Request() req): string {
    const clientIp =
      req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip;
    return this.appService.getHello(clientIp);
  }
}

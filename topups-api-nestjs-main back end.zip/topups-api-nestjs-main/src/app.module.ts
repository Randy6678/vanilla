/* core node modules */
// path
import { join } from 'path';

import { Module } from '@nestjs/common';
// graphql
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';

// controllers
import { AppController } from './app.controller';

// services
import { AppService } from './app.service';

// modules
import { PrismaModule } from './prisma/prisma.module';
import { DingConnectModule } from './ding-connect/ding-connect.module';
import { WhatsappModule } from './whatsapp/whatsapp.module';
import { ApiModule } from './api/api.module';

@Module({
  imports: [
    // prisma module
    PrismaModule,
    // ding connect module
    DingConnectModule,
    // graphql module
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      // autoSchemaFile: join(process.cwd(), 'src/graphql/schema.gql'), --> for code first approach only
      typePaths: ['./**/*.graphql', 'src/**/*.graphql'],
      definitions: {
        path: join(process.cwd(), 'src/graphql/typedefs.ts'),
        outputAs: 'class',
      },
      // later change debugging for production in the future to false
      debug: process.env.NODE_ENV !== 'production' ? true : true,
      // later change playground for production in the future to false
      playground: process.env.NODE_ENV !== 'production' ? true : true,
      // later change introspection for production in the future to false
      introspection: process.env.NODE_ENV !== 'production' ? true : true,
    }),
    WhatsappModule,
    ApiModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

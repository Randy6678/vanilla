export enum SupportedCountryIsos {
  'Ghana' = 'GH',
  'Nigeria' = 'NG',
}

export enum SupportedCurrencies {
  'Ghana Cedi' = 'GHS',
  'Nigerian Naira' = 'NGN',
}

export enum SupportedRegions {
  'Ghana' = 'GH',
  'Nigeria' = 'NG',
}

export enum TopupOptions {
  'Airtime',
  'Data',
}

export enum SupportedCountryCodes {
  'GH' = '233',
  'NG' = '234',
}

export enum ConversationContext {
  'None' = 'None',
  'Topup' = 'Topup',
  'Feedback' = 'Feedback',
}

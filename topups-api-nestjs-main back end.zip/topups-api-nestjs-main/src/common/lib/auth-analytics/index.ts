import * as fs from 'fs';
import * as path from 'path';

// static auth analytics file path
const authAnalyticsFilePath = path.resolve(
  process.cwd(),
  'data',
  'dc-analytics',
  'auth-analytics.json',
);

interface AuthAnalytics {
  access_token: string;
  last_authenticated: number;
  expiresAt: number;
  auth_count: number;
}

export const getAuthAnalytics = () => {
  const authAnalyticsJson = fs.readFileSync(authAnalyticsFilePath);
  const authAnalytics: AuthAnalytics = JSON.parse(authAnalyticsJson.toString());

  return authAnalytics;
};

export const setAuthAnalytics = (authAnalytics: AuthAnalytics) => {
  fs.writeFileSync(
    authAnalyticsFilePath,
    JSON.stringify(authAnalytics, null, 2),
  );
};

import axios from 'axios';

export const appApiAxios = axios.create({
  baseURL:
    process.env.NODE_ENV === 'development'
      ? 'http://localhost:5000'
      : 'https://topups-api-server.herokuapp.com',
});

export const dingConnectAxios = axios.create({
  baseURL: 'https://api.dingconnect.com/api/V1',
});

export const authDingConnectAxios = axios.create({
  baseURL: 'https://idp.ding.com/connect/token',
  timeout: 3000,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-Requested-With': 'XMLHttpRequest',
  },
});

export const whatsappApiAxios = axios.create({
  baseURL: 'https://graph.facebook.com/v12.0',
});

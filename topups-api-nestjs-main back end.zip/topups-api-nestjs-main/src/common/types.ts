import { ConversationContext, SupportedCountryIsos } from './enums';

export type ConversationState = {
  context: ConversationContext;
  prevState?: string | null;
  activeState: string;
  nextState?: string | null;
  selectedCountry?: SupportedCountryIsos;
  recipientPhone?: string;
  selectedProviderCode?: string;
  selectedProviderName?: string;
  selectedProductSkuCode?: string;
  selectedProductValue?: number | string;
  varingProductRecieveValue?: number | string;
  sendValue?: number;
  selectedProductUatNumber?: string;
};

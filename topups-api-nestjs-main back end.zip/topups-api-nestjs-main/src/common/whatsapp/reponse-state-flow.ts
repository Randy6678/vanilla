// incoming message state response handler functions
import {
  welcomeMessage,
  invalidWelcomeMessageResponse,
  selectCountryMessage,
  invalidSelectCountryMessageResponse,
  getRecipientPhoneMessage,
  invalidGetRecipientPhoneMessage,
  confirmMobileOperatorMessage,
  changeMobileOperatorMessage,
  invalidConfirmMobileOperatorMessage,
  selectTopupPlanMessage,
  invalidSelectTopupPlanMessage,
  getVaryingProductSendValueMessage,
  invalidGetVaryingProductSendValueMessage,
  confirmSendTopupMessage,
  invalidConfirmSendTopupMessage,
  confirmSendVaryingTopupMessage,
  invalidConfirmSendVaryingTopupMessage,
  sendPaymentLink,
} from './response-messages';

const StateFlow = {
  welcomeMessage: {
    execute: welcomeMessage,
    prev: null,
    next: selectCountryMessage,
    error: invalidWelcomeMessageResponse,
    isAsync: false,
  },
  selectCountryMessage: {
    execute: selectCountryMessage,
    prev: selectCountryMessage,
    next: getRecipientPhoneMessage,
    error: invalidSelectCountryMessageResponse,
    isAsync: false,
  },
  getRecipientPhoneMessage: {
    execute: getRecipientPhoneMessage,
    prev: selectCountryMessage,
    next: confirmMobileOperatorMessage,
    error: invalidGetRecipientPhoneMessage, // should be try again function
    isAsync: false,
  },
  confirmMobileOperatorMessage: {
    execute: confirmMobileOperatorMessage,
    prev: getRecipientPhoneMessage,
    next: selectTopupPlanMessage,
    error: invalidConfirmMobileOperatorMessage,
    isAsync: true,
  },
  changeMobileOperatorMessage: {
    execute: changeMobileOperatorMessage,
    prev: getRecipientPhoneMessage,
    next: confirmMobileOperatorMessage,
    error: invalidConfirmMobileOperatorMessage, // create custom error for changeMobileOperatorMessage
    isAsync: true,
  },
  selectTopupPlanMessage: {
    execute: selectTopupPlanMessage,
    prev: confirmMobileOperatorMessage,
    next: confirmSendTopupMessage,
    error: invalidSelectTopupPlanMessage,
    isAsync: true,
  },
  getVaryingProductSendValueMessage: {
    execute: getVaryingProductSendValueMessage,
    prev: selectTopupPlanMessage,
    next: confirmSendVaryingTopupMessage,
    error: invalidGetVaryingProductSendValueMessage,
    isAsync: true,
  },
  confirmSendTopupMessage: {
    execute: confirmSendTopupMessage,
    prev: selectTopupPlanMessage,
    next: sendPaymentLink,
    error: invalidConfirmSendTopupMessage,
    isAsync: true,
  },
  confirmSendVaryingTopupMessage: {
    execute: confirmSendVaryingTopupMessage,
    prev: getVaryingProductSendValueMessage,
    next: sendPaymentLink,
    error: invalidConfirmSendVaryingTopupMessage,
    isAsync: true,
  },
  sendPaymentLink: {
    execute: sendPaymentLink,
    prev: confirmSendTopupMessage,
    next: null,
    error: null,
    isAsync: true,
  },
};

export default StateFlow;

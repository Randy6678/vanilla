// axios instances
import { appApiAxios } from '../lib/axios-instances';

// types and enums
import {
  SupportedCountryCodes,
  SupportedCountryIsos,
  ConversationContext,
} from '../enums';
import { ConversationState } from '../types';

// custom error
import { WhatsappMessageResponseError } from './custom-error';

export const welcomeMessage = (requestBody, convoState: ConversationState) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload
  const username =
    requestBody.entry[0].changes[0].value?.contacts[0]?.profile?.name; // extract the name of current user if he saved bots number

  const parsedUsernameText = username ? username : 'Welcome';

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      body: {
        text: `Hi ${parsedUsernameText} 👋\nI'm Rilla, your Creative Lyfe Whatsapp Topups Assistant and am excited to meet you 😎.\n\nI'm here to help you with all your airtime and data topup transactions.\n\nClick to select an option from the main menu below.`,
      },
      action: {
        button: 'Main Menu',
        sections: [
          {
            title: 'Choose From The Options',
            rows: [
              {
                id: ConversationContext.Topup,
                title: 'Send Top up',
              },
              {
                id: ConversationContext.Feedback,
                title: 'Feedback/Report Issue',
              },
            ],
          },
        ],
      },
    },
  };

  // update conversation next state
  convoState.nextState = selectCountryMessage.name;

  // return response data with state
  return { responseData, updatedConversationState: convoState };
};

export const invalidWelcomeMessageResponse = (requestBody) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      body: {
        text: `*Invalid response received*\n\nPlease click to select an option from the main menu below.`,
      },
      action: {
        button: 'Main Menu',
        sections: [
          {
            title: 'Choose From The Options',
            rows: [
              {
                id: ConversationContext.Topup,
                title: 'Send Top up',
              },
              {
                id: ConversationContext.Feedback,
                title: 'Feedback/Report Issue',
              },
            ],
          },
        ],
      },
    },
  };
};

export const selectCountryMessage = (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type;

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;

  // check if message was in the appropriate form
  const isInvalidIncomingMessage =
    msg_type !== 'interactive' ||
    typeOfMessageType !== 'list_reply' ||
    !msg_type_id ||
    !Object.values(ConversationContext).includes(msg_type_id);
  if (isInvalidIncomingMessage) {
    throw new WhatsappMessageResponseError('invalidWelcomeMessageResponse');
  }

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      body: {
        text: `
*Sending Mobile Topup*

Please select which country you would like to send *Top up* to.
`.trim(),
      },
      footer: {
        text: '*Note:* Currently we are only supported in 2 countries',
      },
      action: {
        button: 'Choose Country',
        sections: [
          {
            title: 'Choose From The Options',
            rows: [
              {
                id: SupportedCountryIsos.Ghana,
                title: 'Ghana (+233)',
              },
              {
                id: SupportedCountryIsos.Nigeria,
                title: 'Nigeria (+234)',
              },
            ],
          },
        ],
      },
    },
  };

  // update state context
  convoState.context =
    msg_type_id == ConversationContext.Topup
      ? ConversationContext.Topup
      : msg_type_id == ConversationContext.Feedback
      ? ConversationContext.Feedback
      : ConversationContext.None;

  // update conversation next state
  convoState.nextState = getRecipientPhoneMessage.name;

  // return response data with state
  return { responseData, updatedConversationState: convoState };
};

export const invalidSelectCountryMessageResponse = (requestBody) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      body: {
        text: `
*Invalid response received*

Please select which country you would like to send *Top up* to.`.trim(),
      },
      footer: {
        text: '*Note:* Currently we are only supported in 2 countries',
      },
      action: {
        button: 'Choose Country',
        sections: [
          {
            title: 'Choose From The Options',
            rows: [
              {
                id: SupportedCountryIsos.Ghana,
                title: 'Ghana (+233)',
              },
              {
                id: SupportedCountryIsos.Nigeria,
                title: 'Nigeria (+234)',
              },
            ],
          },
        ],
      },
    },
  };
};

export const getRecipientPhoneMessage = (requestBody, convoState) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type;

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;

  // check if message was in the appropriate form
  const isInvalidIncomingMessage =
    msg_type !== 'interactive' ||
    typeOfMessageType !== 'list_reply' ||
    !msg_type_id ||
    !Object.values(SupportedCountryIsos).includes(msg_type_id);
  if (isInvalidIncomingMessage) {
    throw new WhatsappMessageResponseError(
      'invalidSelectCountryMessageResponse',
    );
  }

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `*Enter Recipient Phone Number*\n\nPhone number should begin with country code (${SupportedCountryCodes[msg_type_id]})`,
    },
  };

  // update state selected country
  convoState.selectedCountry =
    msg_type_id == 'GH'
      ? SupportedCountryIsos.Ghana
      : SupportedCountryIsos.Nigeria;

  // update conversation next state
  convoState.nextState = confirmMobileOperatorMessage.name;

  // return response data with state
  return { responseData, updatedConversationState: convoState };
};

export const invalidGetRecipientPhoneMessage = (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  // extract selected country name's name from SupportedCountryIsos enum
  const selectedCountryName =
    Object.keys(SupportedCountryIsos)[
      Object.values(SupportedCountryIsos).indexOf(convoState.selectedCountry)
    ];

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
*Invalid Phone Number Received*

Please enter a valid Phone number for selected country *${selectedCountryName}*
*Note*: Phone number should begin with country code (${
        SupportedCountryCodes[convoState.selectedCountry]
      })`,
    },
  };
};

export const confirmMobileOperatorMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type; // text
  const msg_body = messagesObject[msg_type]?.body as string;

  // get selected country
  const selectedCountryCode = SupportedCountryCodes[convoState.selectedCountry];

  // TODO
  // check if the phone number is a valid phone number
  const isInvalidPhoneNumber =
    !msg_body || !msg_body.startsWith(selectedCountryCode);
  if (isInvalidPhoneNumber) {
    throw new WhatsappMessageResponseError('invalidGetRecipientPhoneMessage');
  }

  // get the provider of the submitted phone number with the getAccountLookup api endpoint
  try {
    const response = await appApiAxios.get('/api/GetProviders', {
      params: {
        accountNumber: msg_body,
      },
    });

    if (response.status === 200) {
      const data = response.data;
      const providers = data.Items;

      if (providers && providers.length) {
        const responseData = {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: from,
          type: 'interactive',
          interactive: {
            type: 'list',
            header: {
              type: 'text',
              text: 'Confirm Mobile Operator',
            },
            body: {
              text: `Based on your _selected country_ and _recipient phone_ below is a list of providers in your region.\n\nPlease select from the list below recipeint's mobile operator.`,
            },
            action: {
              button: 'Choose Operator',
              sections: [
                {
                  title: 'Choose Operator',
                  rows: [
                    ...providers.map((provider) => ({
                      id: provider.ProviderCode,
                      title: provider.Name.slice(0, 24),
                    })),
                    {
                      id: '0',
                      title: "Couldn't find operator ?",
                    },
                  ],
                },
              ],
            },
          },
        };

        // update state recipient phone
        convoState.recipientPhone = msg_body;

        // update conversation next state
        convoState.nextState = selectTopupPlanMessage.name;

        // return response data with state
        return { responseData, updatedConversationState: convoState };
      }
    }

    throw new WhatsappMessageResponseError('invalidGetRecipientPhoneMessage');
  } catch (error) {
    console.error(error);
    throw new WhatsappMessageResponseError('invalidGetRecipientPhoneMessage');
  }
};

export const changeMobileOperatorMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  try {
    const response = await appApiAxios.get('/api/GetProviders', {
      params: {
        countryIsos: convoState.selectedCountry,
      },
    });

    if (response.status === 200) {
      const data = response.data;
      const providers = data.Items;

      if (providers && Array.isArray(providers) && providers.length) {
        const providerList = providers.map((provider) => ({
          id: provider.ProviderCode,
          title: provider.Name.slice(0, 24),
        }));

        const responseData = {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: from,
          type: 'interactive',
          interactive: {
            type: 'list',
            header: {
              type: 'text',
              text: "Manually Select Recipient's Mobile Operator",
            },
            body: {
              text: `Please select from the list below the mobile operator of ${convoState.recipientPhone}`.trim(),
            },
            action: {
              button: 'Select Operator',
              sections: [
                {
                  title: 'Select Mobile Operator',
                  rows: providerList,
                },
              ],
            },
          },
        };

        // update conversation active state
        convoState.activeState = changeMobileOperatorMessage.name;

        // update conversation next state
        convoState.nextState = selectTopupPlanMessage.name;

        // return response data with state
        return { responseData, updatedConversationState: convoState };
      }
    }
  } catch (error) {
    console.log(error);
  }
};

export const invalidConfirmMobileOperatorMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  try {
    const response = await appApiAxios.get('/api/GetProviders', {
      params: {
        accountNumber: convoState.recipientPhone,
      },
    });

    if (response.status === 200) {
      const data = response.data;
      const providers = data.Items;

      if (providers && providers.length) {
        return {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: from,
          type: 'interactive',
          interactive: {
            type: 'list',
            header: {
              type: 'text',
              text: 'Invalid Response Recieved',
            },
            body: {
              text: `Based on your _selected country_ and _recipient phone_ below is a list of providers in your region.\n\nPlease select from the list below recipeint's mobile operator.`,
            },
            action: {
              button: 'Choose Operator',
              sections: [
                {
                  title: 'Choose Operator',
                  rows: [
                    ...providers.map((provider) => ({
                      id: provider.ProviderCode,
                      title: provider.Name.slice(0, 24),
                    })),
                    {
                      id: '0',
                      title: "Couldn't find operator ?",
                    },
                  ],
                },
              ],
            },
          },
        };
      }
    }
  } catch (error) {
    console.error(error);
  }
};

export const selectTopupPlanMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload
  const msg_type = messagesObject.type; // button_reply

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;

  // check if previous state was confirmMobileOperatorMessage or changeMobileOperatorMessage
  if (
    convoState.prevState == confirmMobileOperatorMessage.name ||
    convoState.prevState == changeMobileOperatorMessage.name
  ) {
    // check if response is valid
    const isInvalidIncomingMessage =
      msg_type !== 'interactive' ||
      typeOfMessageType !== 'list_reply' ||
      !msg_type_id;
    if (isInvalidIncomingMessage) {
      throw new WhatsappMessageResponseError(
        'invalidConfirmMobileOperatorMessage',
      );
    }

    // check if response was 2 for change mobile operator
    if (msg_type_id == '0') {
      // return function for handing change mobile operator
      return await changeMobileOperatorMessage(requestBody, convoState);
    }
  }

  const selectedProviderCode = msg_type_id;
  const selectedProviderName = msg_body.title;

  // fetch products avalaible for use based on selected provider code
  const fetchProductsResponse = await appApiAxios.get('/api/GetProducts', {
    params: {
      providerCodes: selectedProviderCode,
    },
  });

  const data = fetchProductsResponse.data;
  const fetchedProducts = data.Items;

  const fetchProductsDescriptionsResponse = await appApiAxios.get(
    '/api/GetProductDescriptions',
    {
      params: {
        skuCodes: fetchedProducts.map((product) => product.SkuCode).toString(),
      },
    },
  );

  const descriptionsData = fetchProductsDescriptionsResponse.data;
  const fetchedProductsDescriptions = descriptionsData.Items;

  // reaches here if response was 1 or anything other than 2
  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      header: {
        type: 'text',
        text: 'Select Topup Plan',
      },
      body: {
        text: `\nFrom the options below select which plan would like to send to ${convoState.recipientPhone}`,
      },
      action: {
        button: 'Select Plan',
        sections: [
          {
            title: 'Choose From The Options',
            rows: fetchedProductsDescriptions.map(
              (productDescription, productIndex) => ({
                id: fetchedProducts[productIndex].SkuCode,
                title: productDescription.DisplayText.slice(0, 24),
              }),
            ),
          },
        ],
      },
    },
  };

  // update state to store recipeint provider name
  convoState.selectedProviderName = selectedProviderName;
  // update state recipient mobile provider code
  convoState.selectedProviderCode = msg_type_id;

  // update conversation next state
  convoState.nextState = confirmSendTopupMessage.name;

  // return response data with state
  return { responseData, updatedConversationState: convoState };
};

export const invalidSelectTopupPlanMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  // fetch products avalaible for use based on selected provider code
  const fetchProductsResponse = await appApiAxios.get('/api/GetProducts', {
    params: {
      providerCodes: convoState.selectedProviderCode,
    },
  });

  const data = fetchProductsResponse.data;
  const fetchedProducts = data.Items;

  const fetchProductsDescriptionsResponse = await appApiAxios.get(
    '/api/GetProductDescriptions',
    {
      params: {
        skuCodes: fetchedProducts.map((product) => product.SkuCode).toString(),
      },
    },
  );

  const descriptionsData = fetchProductsDescriptionsResponse.data;
  const fetchedProductsDescriptions = descriptionsData.Items;

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'list',
      header: {
        type: 'text',
        text: 'Invalid Topup Plan',
      },
      body: {
        text: `From the options below select which plan would like to send to ${convoState.recipientPhone}`.trim(),
      },
      action: {
        button: 'Select Plan',
        sections: [
          {
            title: 'Choose From The Options',
            rows: fetchedProductsDescriptions.map(
              (productDescription, productIndex) => ({
                id: fetchedProducts[productIndex].SkuCode,
                title: productDescription.DisplayText.slice(0, 24),
              }),
            ),
          },
        ],
      },
    },
  };
};

export const getVaryingProductSendValueMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type;

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;
  const msg_type_title = msg_body.title;
  const recipientPhone = convoState.recipientPhone;

  const response = await appApiAxios.get('/api/GetProducts', {
    params: {
      skuCodes: msg_type_id,
    },
  });

  const data = response.data;
  const products = data.Items;
  const selectedProduct = products[0];

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
*Enter Amount To Send To Recipient*

The Top up plan you selected *(${msg_type_title})* allows you to send a custom top up to ${recipientPhone}.
Please enter amount to send to ${recipientPhone}. 

*Note*: The amount entered should be between *${selectedProduct.Maximum.ReceiveCurrencyIso} ${selectedProduct.Minimum.ReceiveValue}* and *${selectedProduct.Maximum.ReceiveValue}*`.trim(),
    },
  };

  // update active state to getVaryingProductSendValueMessage
  convoState.activeState = getVaryingProductSendValueMessage.name;

  // update state selected send value and product skucode code
  convoState.selectedProductValue = msg_type_title;
  convoState.selectedProductSkuCode = msg_type_id;
  convoState.selectedProductUatNumber = selectedProduct.UatNumber;

  // update conversation next state
  convoState.nextState = confirmSendVaryingTopupMessage.name;

  // return response data with state
  return { responseData, updatedConversationState: convoState };
};

export const invalidGetVaryingProductSendValueMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const { selectedProductSkuCode, selectedProductValue, recipientPhone } =
    convoState;

  const response = await appApiAxios.get('/api/GetProducts', {
    params: {
      skuCodes: selectedProductSkuCode,
    },
  });

  const data = response.data;
  const products = data.Items;
  const selectedProduct = products[0];

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
*Invalid Amount Entered*

The Top up plan you selected *(${selectedProductValue})* allows you to send a custom top up to ${recipientPhone}.
Please enter amount to send to ${recipientPhone}. 

*Note*: The amount entered should be between *${selectedProduct.Maximum.ReceiveCurrencyIso} ${selectedProduct.Minimum.ReceiveValue}* and *${selectedProduct.Maximum.ReceiveValue}*`.trim(),
    },
  };
};

export const confirmSendTopupMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type;

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;
  const msg_type_title = msg_body.title;
  const recipientPhone = convoState.recipientPhone;

  // check if response is valid
  const isInvalidIncomingMessage =
    msg_type !== 'interactive' ||
    typeOfMessageType !== 'list_reply' ||
    !msg_type_id;
  if (isInvalidIncomingMessage) {
    throw new WhatsappMessageResponseError('invalidSelectTopupPlanMessage');
  }

  const response = await appApiAxios.get('/api/GetProducts', {
    params: {
      skuCodes: msg_type_id,
    },
  });

  const data = response.data;
  const products = data.Items;
  const selectedProduct = products[0];

  // check if the selected product has a varying send and receive values
  const isVaryingProduct =
    selectedProduct.Maximum.ReceiveValue !=
      selectedProduct.Minimum.ReceiveValue ||
    selectedProduct.Maximum.SendValue != selectedProduct.Minimum.SendValue;

  // TODO - handle varying product
  if (isVaryingProduct) {
    return await getVaryingProductSendValueMessage(requestBody, convoState);
  }

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'button',
      header: {
        type: 'text',
        text: `Confirm Topup Plan`,
      },
      body: {
        text: `You have requested to send *${msg_type_title}* worth *${selectedProduct.Minimum.ReceiveCurrencyIso} ${selectedProduct.Minimum.ReceiveValue}* to ${recipientPhone}.\n\nPlease confrim your request.`,
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: '1',
              title: 'Cancel',
            },
          },
          {
            type: 'reply',
            reply: {
              id: '2',
              title: 'Confirm',
            },
          },
        ],
      },
    },
  };

  // update state selected send value and product skucode code
  convoState.selectedProductValue = msg_type_title;
  convoState.selectedProductSkuCode = msg_type_id;
  convoState.sendValue = selectedProduct.Maximum.SendValue;
  convoState.selectedProductUatNumber = selectedProduct.UatNumber;

  // update conversation next state
  convoState.nextState = sendPaymentLink.name;

  return { responseData, updatedConversationState: convoState };
};

export const invalidConfirmSendTopupMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const selectedProductValue = convoState.selectedProductValue;
  const recipientPhone = convoState.recipientPhone;

  const response = await appApiAxios.get('/api/GetProducts', {
    params: {
      skuCodes: convoState.selectedProductSkuCode,
    },
  });

  const data = response.data;
  const products = data.Items;
  const selectedProduct = products[0];

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'button',
      header: {
        type: 'text',
        text: `Invalid Response Received`,
      },
      body: {
        text: `You have requested to send *${selectedProductValue}* worth *${selectedProduct.Minimum.ReceiveValue} ${selectedProduct.Minimum.ReceiveCurrencyIso}* to ${recipientPhone}.\n\nPlease confrim your request.`.trim(),
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: '1',
              title: 'Cancel',
            },
          },
          {
            type: 'reply',
            reply: {
              id: '2',
              title: 'Confirm',
            },
          },
        ],
      },
    },
  };
};

export const confirmSendVaryingTopupMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type; // text
  const msg_body = messagesObject[msg_type]?.body as any; // send value

  const skuCode = convoState.selectedProductSkuCode;
  const productDescription = convoState.selectedProductValue;
  const recipientPhone = convoState.recipientPhone;

  const response = await appApiAxios.get('/api/GetProducts', {
    params: {
      skuCodes: skuCode,
    },
  });

  const data = response.data;
  const products = data.Items;
  const selectedProduct = products[0];

  // check if response is valid
  const isInvalidIncomingMessage =
    msg_type !== 'text' ||
    isNaN(msg_body) ||
    Number(msg_body) > selectedProduct.Maximum.ReceiveValue ||
    Number(msg_body) < selectedProduct.Minimum.ReceiveValue;
  if (isInvalidIncomingMessage) {
    throw new WhatsappMessageResponseError(
      'invalidGetVaryingProductSendValueMessage',
    );
  }

  // get estimated recieve value
  const estimatedPricesResponse = await appApiAxios.post(
    '/ding-connect/EstimatePrices',
    [
      {
        SkuCode: skuCode,
        BatchItemRef: `estimate-${from}-${recipientPhone}`,
        ReceiveValue: Number(msg_body),
      },
    ],
    { headers: { 'Content-Type': 'application/json' } },
  );

  const estimatedPricesResponseData = estimatedPricesResponse.data;
  const estimatedPricesItems = estimatedPricesResponseData.Items;
  const estimatedPrice = estimatedPricesItems[0];

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'button',
      header: {
        type: 'text',
        text: `Confirm Topup Plan`,
      },
      body: {
        text: `From the selected plan *${productDescription}*, you have requested to send *${estimatedPrice.Price.ReceiveCurrencyIso} ${msg_body}* worth *${estimatedPrice.Price.ReceiveCurrencyIso} ${estimatedPrice.Price.ReceiveValue}* to ${recipientPhone}.\n\nPlease confrim your request.`,
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: '1',
              title: 'Cancel',
            },
          },
          {
            type: 'reply',
            reply: {
              id: '2',
              title: 'Confirm',
            },
          },
        ],
      },
    },
  };

  // update state varying product recieve value
  convoState.varingProductRecieveValue = msg_body;
  // update state product send value
  convoState.sendValue = estimatedPrice.Price.SendValue;
  convoState.selectedProductUatNumber = selectedProduct.UatNumber;

  // update conversation next state
  convoState.nextState = sendPaymentLink.name;

  return { responseData, updatedConversationState: convoState };
};

export const invalidConfirmSendVaryingTopupMessage = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const varingProductRecieveValue = convoState.varingProductRecieveValue;
  const skuCode = convoState.selectedProductSkuCode;
  const productDescription = convoState.selectedProductValue;
  const recipientPhone = convoState.recipientPhone;

  // get estimated recieve value
  const estimatedPricesResponse = await appApiAxios.post(
    '/ding-connect/EstimatePrices',
    [
      {
        SkuCode: skuCode,
        BatchItemRef: `estimate-${from}-${recipientPhone}`,
        ReceiveValue: Number(varingProductRecieveValue),
      },
    ],
    { headers: { 'Content-Type': 'application/json' } },
  );

  const estimatedPricesResponseData = estimatedPricesResponse.data;
  const estimatedPricesItems = estimatedPricesResponseData.Items;
  const estimatedPrice = estimatedPricesItems[0];

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'interactive',
    interactive: {
      type: 'button',
      header: {
        type: 'text',
        text: `Confirm Topup Plan`,
      },
      body: {
        text: `From the selected plan *${productDescription}*, you have requested to send *${estimatedPrice.Price.ReceiveCurrencyIso} ${varingProductRecieveValue}* worth *${estimatedPrice.Price.ReceiveCurrencyIso} ${estimatedPrice.Price.ReceiveValue}* to ${recipientPhone}.\n\nPlease confrim your request.`,
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: '1',
              title: 'Cancel',
            },
          },
          {
            type: 'reply',
            reply: {
              id: '2',
              title: 'Confirm',
            },
          },
        ],
      },
    },
  };
};

export const cancelConfirmTopupOrder = (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `Your Topup order has been cancelled.\nPlease reply to this message to start a new order.`.trim(),
    },
  };

  convoState = {
    context: ConversationContext.None,
    activeState: 'initial',
  };

  return { responseData, updatedConversationState: convoState };
};

export const sendPaymentLink = async (
  requestBody,
  convoState: ConversationState,
) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  const msg_type = messagesObject.type;

  const typeOfMessageType = messagesObject[msg_type]?.type;
  const msg_body = typeOfMessageType
    ? messagesObject[msg_type][typeOfMessageType]
    : messagesObject[msg_type];

  const msg_type_id = msg_body.id;

  // TODO - handle invalid confirmSendVaryingTopupMessage

  // check if response is valid
  const isInvalidIncomingMessage =
    msg_type !== 'interactive' ||
    typeOfMessageType !== 'button_reply' ||
    !msg_type_id;
  if (isInvalidIncomingMessage) {
    if (convoState.prevState === confirmSendTopupMessage.name) {
      throw new WhatsappMessageResponseError('invalidConfirmSendTopupMessage');
    }

    if (convoState.prevState === confirmSendVaryingTopupMessage.name) {
      throw new WhatsappMessageResponseError(
        'invalidConfirmSendVaryingTopupMessage',
      );
    }

    throw new WhatsappMessageResponseError('Unknown Error');
  }

  // check if user choose cancel button
  if (msg_type_id == '1') {
    return cancelConfirmTopupOrder(requestBody, convoState);
  }

  // send a validate only request to verify if transfer would be successful
  const distributorRef = 'validateOrderRef'; // should be an order id from database

  const validateSendTransferResponse = await appApiAxios.post(
    '/ding-connect/SendTransfer',
    {
      SkuCode: convoState.selectedProductSkuCode,
      AccountNumber: convoState.selectedProductUatNumber,
      DistributorRef: distributorRef,
      SendValue: convoState.sendValue,
      ValidateOnly: true,
    },
    { headers: { 'Content-Type': 'application/json' } },
  );

  const validateSendTransferResponseData = validateSendTransferResponse.data;
  const transferRecord = validateSendTransferResponseData.TransferRecord;

  // get variables for response message
  const selectedCountryName =
    Object.keys(SupportedCountryIsos)[
      Object.values(SupportedCountryIsos).indexOf(convoState.selectedCountry)
    ];
  const recipientPhone = convoState.recipientPhone;
  const mobileProviderName = convoState.selectedProviderName;

  const orderLinkUrl = 'https://sample-payment-link.com';

  const responseData = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
*Order Summary*

Country: ${selectedCountryName}
Number: ${recipientPhone}
Operator: ${mobileProviderName}

*Receiver Gets:* ${transferRecord.Price.ReceiveCurrencyIso} ${
        transferRecord.Price.ReceiveValue
      }

Top-up amount: ${transferRecord.Price.SendCurrencyIso} ${
        transferRecord.Price.SendValue
      }
Processing fee: ${transferRecord.Price.SendCurrencyIso} ${'0'}
*Total*: ${transferRecord.Price.SendCurrencyIso} ${
        transferRecord.Price.SendValue
      }
      
*Click the link below pay for your order*
${orderLinkUrl}
`.trim(),
    },
  };

  // TODO
  // reset state here

  // update conversation next state
  convoState.nextState = null;

  return { responseData, updatedConversationState: convoState };
};

export const sessionResetSuccessfulResponse = (requestBody) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
Your session has been restarted/reset sucessfully.
Please reply to this message to start your new session.
      `.trim(),
    },
  };
};

export const sessionResetFailedResponse = (requestBody) => {
  const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
  const from = messagesObject.from; // extract the phone number from the webhook payload

  return {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: from,
    type: 'text',
    text: {
      body: `
Something went wrong while restarting/reseting your session.
Please try again with the *Restart* command.
      `.trim(),
    },
  };
};

export default {
  welcomeMessage,
  invalidWelcomeMessageResponse,
  selectCountryMessage,
  invalidSelectCountryMessageResponse,
  getRecipientPhoneMessage,
  invalidGetRecipientPhoneMessage,
  confirmMobileOperatorMessage,
  changeMobileOperatorMessage,
  invalidConfirmMobileOperatorMessage,
  selectTopupPlanMessage,
  invalidSelectTopupPlanMessage,
  getVaryingProductSendValueMessage,
  invalidGetVaryingProductSendValueMessage,
  confirmSendTopupMessage,
  invalidConfirmSendTopupMessage,
  confirmSendVaryingTopupMessage,
  invalidConfirmSendVaryingTopupMessage,
  sendPaymentLink,
};

import { Test, TestingModule } from '@nestjs/testing';
import { DingConnectController } from './ding-connect.controller';
import { DingConnectService } from './ding-connect.service';

describe('DingConnectController', () => {
  let controller: DingConnectController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DingConnectController],
      providers: [DingConnectService],
    }).compile();

    controller = module.get<DingConnectController>(DingConnectController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

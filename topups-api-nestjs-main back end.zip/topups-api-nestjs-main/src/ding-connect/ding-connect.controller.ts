import {
  Controller,
  Get,
  Post,
  Body,
  Req,
  UseInterceptors,
  Query,
} from '@nestjs/common';
// swagger
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiOkResponse,
  ApiUnauthorizedResponse,
  ApiResponse,
} from '@nestjs/swagger';

// services
import { DingConnectService } from './ding-connect.service';

// dto
import { CancelTransferDto } from './dto/cancelTransfer.dto';
import { EstimatePricesDto } from './dto/estimatePrices.dto';
import { ListTransferRecordsDto } from './dto/listTransferRecords.dto';
import { LookupBillsDto } from './dto/lookupBills.dto';
import { SendTransferDto } from './dto/sendTransfer.dto';
import { GetAccountLookupQueryDto } from './dto/getAccountLookupQuery.dto';
import { GetProductDescriptionsQueryDto } from './dto/getProductDescriptionsQuery.dto';
import { GetProductsQueryDto } from './dto/getProductsQuery.dto';
import { GetPromotionDescriptionsQueryDto } from './dto/getPromotionDescriptionsQuery.dto';
import { GetPromotionsQueryDto } from './dto/getPromotionsQuery.dto';
import { GetProvidersQueryDto } from './dto/getProvidersQuery.dto';
import { GetProviderStatusQueryDto } from './dto/getProviderStatusQuery.dto';
import { GetRegionsQueryDto } from './dto/getRegionsQuery.dto';

// entities

// lib
import { DingConnectAuthInterceptor } from '../interceptors/ding-connect-auth.interceptor';

@ApiTags('ding-connect')
@UseInterceptors(DingConnectAuthInterceptor)
@Controller('ding-connect')
export class DingConnectController {
  constructor(private readonly dingConnectService: DingConnectService) {}

  /* =====================> Ding Connect post api endpoints <=================== */
  // CancelTransfers
  @ApiOperation({
    summary: 'Attempt to cancel transfers with the submitted TransferIds',
    description:
      'The agent should call `ListTransferRecords` with an appropriate query to get a list of `TransferIds` that are available to cancel.\n\nNot all transfers can be cancelled. This method will return the ProcessingState of the transfer: if the state is "Cancelled", then the transfer was successfully cancelled and any appropriate balance compensations will have been applied to the agent account. If the state is anything else, then the transfer could not be cancelled.',
  })
  @ApiBody({ type: CancelTransferDto, isArray: true })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post('CancelTransfers')
  async cancelTransfers(
    @Req() req,
    @Body()
    body: CancelTransferDto[],
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.cancelTransfers(accessToken, body);
  }

  @ApiOperation({
    summary: 'Estimate prices for send or receive values',
    description:
      'Before a transfer is attempted, it is impossible to know the exact value that an account will receive due to fluctuating foreign exchange rates, provider promotions and fees. This API call will attempt to estimate, from the current prices in the products list, what receive value will result from a given send value or vice versa.',
  })
  @ApiBody({ type: EstimatePricesDto, isArray: true })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post('EstimatePrices')
  async estimatePrices(
    @Req() req,
    @Body()
    body: EstimatePricesDto[],
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.estimatePrices(accessToken, body);
  }

  /* =====================> Ding Connect get api endpoints <=================== */
  // GetAccountLookup
  @ApiOperation({
    summary:
      'Get providers and product information for a specific account number',
    description:
      'Returns country, provider and region code details for the account number. This information can be then be used as input parameters to `GetProducts`',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetAccountLookup')
  async getAccountLookup(@Req() req, @Query() query: GetAccountLookupQueryDto) {
    const accessToken = req.dcAuthAt;
    const accountNumber = query.accountNumber;

    return this.dingConnectService.getAccountLookup(accessToken, accountNumber);
  }

  // GetBalance
  @ApiOperation({
    summary: 'Get the current agent balance',
    description:
      'Returns the current agent balance. This will include any commission-on-sale increments, but will not reflect any transfers that are currently processing.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetBalance')
  async getBalance(@Req() req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getBalance(accessToken);
  }

  // GetCountries
  @ApiOperation({
    summary: 'Get a list of supported countries',
    description:
      'Retrieves a list of standard two letter country codes that the system supports, along with the country name in English.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetCountries')
  async getCountries(@Req() req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getCountries(accessToken);
  }

  // GetCurrencies
  @ApiOperation({
    summary: 'Get a list of supported currencies',
    description:
      'Retrieves a list of standard three letter currency codes that the system supports, along with the currency name in English.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetCurrencies')
  async getCurrencies(@Req() req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getCurrencies(accessToken);
  }

  // GetErrorCodeDescriptions
  // GetCurrencies
  @ApiOperation({
    summary: 'Get a list of error code descriptions',
    description:
      'Every API response can contain one or more ErrorCodes that indicate why a request failed. This API can be used to get a list of human readable errors that correspond to those ErrorCodes. These error messages are aimed at the agent and are not suitable for display to the end user/customer.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetErrorCodeDescriptions')
  async getErrorCodeDescriptions(@Req() req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getErrorCodeDescriptions(accessToken);
  }

  // GetProductDescriptions
  @Get('GetProductDescriptions')
  @ApiOperation({
    summary: 'Get localized strings for products',
    description: 'Please see the documentation section on localization.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  async getProductDescriptions(
    @Req() req,
    @Query() query: GetProductDescriptionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProductDescriptions(accessToken, query);
  }

  // GetProducts
  @Get('GetProducts')
  @ApiOperation({
    summary: 'Get a list of products that can be used in SendTransfer',
    description:
      'This API returns a list of available products that satisfy request criteria.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  async getProducts(
    @Req() req,
    @Query()
    query: GetProductsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProducts(accessToken, query);
  }

  // GetPromotionDescriptions
  @ApiOperation({
    summary: 'Get localized strings for promotions',
    description: 'Please see the documentation section on localization.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetPromotionDescriptions')
  async getPromotionDescriptions(
    @Req() req,
    @Query()
    query: GetPromotionDescriptionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getPromotionDescriptions(accessToken, query);
  }

  // GetPromotions
  @ApiOperation({
    summary: 'Get a list of promotions',
    description:
      'Returns a list promotions that may apply for the submitted criteria.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetPromotions')
  async getPromotions(
    @Req() req,
    @Query()
    query: GetPromotionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getPromotions(accessToken, query);
  }

  // GetProviders
  @ApiOperation({
    summary: 'Get a list of product providers available to the agent',
    description: 'Retrieves the list of providers available to the agent.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetProviders')
  async getProviders(
    @Req() req,
    @Query()
    query: GetProvidersQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProviders(accessToken, query);
  }

  // GetProviderStatus
  @ApiOperation({
    summary: 'Get the current status of product providers',
    description:
      'Providers can be suspended or be in an error state. This API allows an agent to find out if it will be possible to send a transfer to a particular provider.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetProviderStatus')
  async getProviderStatus(
    @Req() req,
    @Query()
    query: GetProviderStatusQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProviderStatus(accessToken, query);
  }

  // GetRegions
  @ApiOperation({
    summary: 'Get a list of regions on the system',
    description:
      'Retrieves a list of regions used in the system. Each region includes a Region Code, Region Name and CountryIso.',
  })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Get('GetRegions')
  async getRegions(
    @Req() req,
    @Query()
    query: GetRegionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getRegions(accessToken, query);
  }

  /* =====================> Ding Connect post api endpoints <=================== */
  @ApiOperation({
    summary: 'Query transfers that were submitted to the system',
    description:
      'ListTransferRecords gives the ability to search the details of transfers that have been submitted to the system by the agent. Note these transfers must not be older than 2 months.',
  })
  @ApiBody({ type: ListTransferRecordsDto })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post('ListTransferRecords')
  async listTransferRecords(
    @Req() req,
    @Body()
    body: ListTransferRecordsDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.listTransferRecords(accessToken, body);
  }

  @ApiOperation({
    summary: 'Search available bills',
    description:
      '`LookupBills` should be called for any product where `LookupBillsRequired` true that will be required for this product when making the `SendTransfer` request, which will pay the Bill.',
  })
  @ApiBody({ type: LookupBillsDto })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post('LookupBills')
  async lookupBills(
    @Req() req,
    @Body()
    body: LookupBillsDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.lookupBills(accessToken, body);
  }

  @ApiOperation({
    summary: 'Send a transfer to an account',
    description: `
    An agent will construct a request that contains a product SkuCode and a SendValue that is between the Min and Max price (inclusive). The agent should also include a DistributorRef that uniquely identifies the transfer within their system.

    SendTransfer will respond with the transfer that was created - including a TransferRef that uniquely identifies the transfer within our system. There will also be information about the state of the transfer and the amount that was received.
    
    On success, we will deduct the value of the transfer from the agent balance and apply any applicable commissions.
    
    The SendTranfer method has a maximum proccessing time of 90 seconds. After 90 seconds, if the SendTransfer request is not completed, the system will return a response with ProviderTimedOut. This transaction will be treated as a failed transaction and the balance will not be deducted.
    `,
  })
  @ApiBody({ type: SendTransferDto })
  @ApiOkResponse({
    description: 'Operation Sucessfull',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
  })
  @ApiUnauthorizedResponse({
    description: 'Session not authorized',
  })
  @Post('SendTransfer')
  async sendTransfer(
    @Req() req,
    @Body()
    body: SendTransferDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.sendTransfer(accessToken, body);
  }
}

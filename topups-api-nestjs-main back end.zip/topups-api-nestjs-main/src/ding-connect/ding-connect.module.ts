import { Module } from '@nestjs/common';

// services
import { DingConnectService } from './ding-connect.service';
import { RequestService } from '../services/request.service';

// controllers
import { DingConnectController } from './ding-connect.controller';
import { DingConnectResolver } from './ding-connect.resolver';

@Module({
  controllers: [DingConnectController],
  providers: [DingConnectService, RequestService, DingConnectResolver],
})
export class DingConnectModule {}

import { Test, TestingModule } from '@nestjs/testing';
import { DingConnectResolver } from './ding-connect.resolver';

describe('DingConnectResolver', () => {
  let resolver: DingConnectResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DingConnectResolver],
    }).compile();

    resolver = module.get<DingConnectResolver>(DingConnectResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});

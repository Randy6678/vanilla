import { UseInterceptors } from '@nestjs/common';
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql';

// interceptors
import { DingConnectAuthInterceptor } from '../interceptors/ding-connect-auth.interceptor';

// services
import { DingConnectService } from './ding-connect.service';

// dto
import { CancelTransferDto } from './dto/cancelTransfer.dto';
import { EstimatePricesDto } from './dto/estimatePrices.dto';
import { GetAccountLookupQueryDto } from './dto/getAccountLookupQuery.dto';
import { GetProductDescriptionsQueryDto } from './dto/getProductDescriptionsQuery.dto';
import { GetProductsQueryDto } from './dto/getProductsQuery.dto';
import { GetPromotionDescriptionsQueryDto } from './dto/getPromotionDescriptionsQuery.dto';
import { GetPromotionsQueryDto } from './dto/getPromotionsQuery.dto';
import { GetProvidersQueryDto } from './dto/getProvidersQuery.dto';
import { GetProviderStatusQueryDto } from './dto/getProviderStatusQuery.dto';
import { GetRegionsQueryDto } from './dto/getRegionsQuery.dto';
import { ListTransferRecordsDto } from './dto/listTransferRecords.dto';
import { LookupBillsDto } from './dto/lookupBills.dto';
import { SendTransferDto } from './dto/sendTransfer.dto';

@UseInterceptors(DingConnectAuthInterceptor)
@Resolver('ding-connect')
export class DingConnectResolver {
  constructor(private readonly dingConnectService: DingConnectService) {}

  /* =====================> Ding Connect Hello graphql query <=================== */
  // Hello
  @Query('Hello')
  async hello() {
    return 'GraphQL Up And Running!';
  }

  /* =====================> Ding Connect graphql mutations <=================== */
  // CancelTransfers
  @Mutation('CancelTransfers')
  async cancelTransfers(
    @Context('req') req,
    @Args('payload')
    payload: CancelTransferDto[],
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.cancelTransfers(accessToken, payload);
  }

  // EstimatePrices
  @Mutation('EstimatePrices')
  async estimatePrices(
    @Context('req') req,
    @Args('payload')
    payload: EstimatePricesDto[],
  ) {
    const accessToken = req.dcAuthAt;
    console.log(payload);

    return this.dingConnectService.estimatePrices(accessToken, payload);
  }

  /* =====================> Ding Connect Hello graphql queries <=================== */
  // GetAccountLookup
  @Query('GetAccountLookup')
  async getAccountLookup(
    @Context('req') req,
    @Args() query: GetAccountLookupQueryDto,
  ) {
    const accessToken = req.dcAuthAt;
    const accountNumber = query.accountNumber;

    return this.dingConnectService.getAccountLookup(accessToken, accountNumber);
  }

  // GetAccountBalance
  @Query('GetBalance')
  async getBalance(@Context('req') req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getBalance(accessToken);
  }

  // GetCountries
  @Query('GetCountries')
  async getCountries(@Context('req') req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getCountries(accessToken);
  }

  // GetCurrencies
  @Query('GetCurrencies')
  async getCurrencies(@Context('req') req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getCurrencies(accessToken);
  }

  // GetErrorCodeDescriptions
  @Query('GetErrorCodeDescriptions')
  async getErrorCodeDescriptions(@Context('req') req) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getErrorCodeDescriptions(accessToken);
  }

  // GetProductDescriptions
  @Query('GetProductDescriptions')
  async getProductDescriptions(
    @Context('req') req,
    @Args() query: GetProductDescriptionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProductDescriptions(accessToken, query);
  }

  // GetProducts
  @Query('GetProducts')
  async getProducts(
    @Context('req') req,
    @Args()
    query: GetProductsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProducts(accessToken, query);
  }

  // GetPromotionDescriptions
  @Query('GetPromotionDescriptions')
  async getPromotionDescriptions(
    @Context('req') req,
    @Args()
    query: GetPromotionDescriptionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getPromotionDescriptions(accessToken, query);
  }

  // GetPromotions
  @Query('GetPromotions')
  async getPromotions(
    @Context('req') req,
    @Args()
    query: GetPromotionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getPromotions(accessToken, query);
  }

  // GetProviders
  @Query('GetProviders')
  async getProviders(
    @Context('req') req,
    @Args()
    query: GetProvidersQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProviders(accessToken, query);
  }

  // GetProviderStatus
  @Query('GetProviderStatus')
  async getProviderStatus(
    @Context('req') req,
    @Args()
    query: GetProviderStatusQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getProviderStatus(accessToken, query);
  }

  // GetRegions
  @Query('GetRegions')
  async getRegions(
    @Context('req') req,
    @Args()
    query: GetRegionsQueryDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.getRegions(accessToken, query);
  }

  /* =====================> Ding Connect Hello graphql mutations <=================== */
  // ListTransferRecords
  @Mutation('ListTransferRecords')
  async listTransferRecords(
    @Context('req') req,
    @Args('payload')
    payload: ListTransferRecordsDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.listTransferRecords(accessToken, payload);
  }

  // LookupBills
  @Mutation('LookupBills')
  async lookupBills(
    @Context('req') req,
    @Args('payload')
    payload: LookupBillsDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.lookupBills(accessToken, payload);
  }

  // SendTransfer
  @Mutation('SendTransfer')
  async sendTransfer(
    @Context('req') req,
    @Args('payload')
    payload: SendTransferDto,
  ) {
    const accessToken = req.dcAuthAt;

    return this.dingConnectService.sendTransfer(accessToken, payload);
  }
}

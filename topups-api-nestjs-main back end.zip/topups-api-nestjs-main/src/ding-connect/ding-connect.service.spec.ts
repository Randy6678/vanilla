import { Test, TestingModule } from '@nestjs/testing';
import { DingConnectService } from './ding-connect.service';

describe('DingConnectService', () => {
  let service: DingConnectService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DingConnectService],
    }).compile();

    service = module.get<DingConnectService>(DingConnectService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

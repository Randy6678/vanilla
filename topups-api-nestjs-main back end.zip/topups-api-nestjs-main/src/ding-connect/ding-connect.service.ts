import { Injectable, UnauthorizedException } from '@nestjs/common';

// dto
import { CancelTransferDto } from './dto/cancelTransfer.dto';
import { EstimatePricesDto } from './dto/estimatePrices.dto';
import { ListTransferRecordsDto } from './dto/listTransferRecords.dto';
import { LookupBillsDto } from './dto/lookupBills.dto';
import { SendTransferDto } from './dto/sendTransfer.dto';

// lib
import { dingConnectAxios } from '../common/lib/axios-instances';

@Injectable()
export class DingConnectService {
  async cancelTransfers(
    accessToken: string,
    payloadRecords: CancelTransferDto[],
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.post(
        '/CancelTransfers',
        JSON.stringify(payloadRecords),
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async estimatePrices(
    accessToken: string,
    payloadRecords: EstimatePricesDto[],
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.post(
        '/EstimatePrices',
        JSON.stringify(payloadRecords),
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getAccountLookup(accessToken: string, accountNumber: string) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetAccountLookup', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getBalance(accessToken: string) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetBalance', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getCountries(accessToken: string) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetCountries', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getCurrencies(accessToken: string) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetCurrencies', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getErrorCodeDescriptions(accessToken: string) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetErrorCodeDescriptions', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProductDescriptions(
    accessToken: string,
    queryOptions: { languageCodes: string[]; skuCodes: string[] },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetProductDescriptions', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          languageCodes: queryOptions.languageCodes,
          skuCodes: queryOptions.skuCodes,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProducts(
    accessToken: string,
    queryOptions: {
      countryIsos: string[];
      providerCodes: string[];
      skuCodes: string[];
      benefits: string[];
      regionCodes: string[];
      accountNumber?: string;
    },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetProducts', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          countryIsos: queryOptions.countryIsos,
          providerCodes: queryOptions.providerCodes,
          skuCodes: queryOptions.skuCodes,
          benefits: queryOptions.benefits,
          regionCodes: queryOptions.regionCodes,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getPromotionDescriptions(
    accessToken: string,
    queryOptions: { languageCodes: string[] },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetPromotionDescriptions', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          languageCodes: queryOptions.languageCodes,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getPromotions(
    accessToken: string,
    queryOptions: {
      countryIsos: string[];
      providerCodes: string[];
      accountNumber?: string;
    },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetPromotions', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          countryIsos: queryOptions.countryIsos,
          providerCodes: queryOptions.providerCodes,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProviders(
    accessToken: string,
    queryOptions: {
      providerCodes: string[];
      countryIsos: string[];
      regionCodes: string[];
      accountNumber?: string;
    },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetProviders', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          providerCodes: queryOptions.providerCodes,
          countryIsos: queryOptions.countryIsos,
          regionCodes: queryOptions.regionCodes,
          accountNumber: queryOptions.accountNumber,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getProviderStatus(
    accessToken: string,
    queryOptions: { providerCodes: string[] },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetProviderStatus', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          providerCodes: queryOptions.providerCodes,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async getRegions(
    accessToken: string,
    queryOptions: { countryIsos: string[] },
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.get('/GetRegions', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          countryIsos: queryOptions.countryIsos,
        },
      });

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async listTransferRecords(
    accessToken: string,
    payload: ListTransferRecordsDto,
  ) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.post(
        '/ListTransferRecords',
        JSON.stringify(payload),
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async lookupBills(accessToken: string, payload: LookupBillsDto) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.post(
        '/LookupBills',
        JSON.stringify(payload),
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }

  async sendTransfer(accessToken: string, payload: SendTransferDto) {
    if (!accessToken) {
      throw new UnauthorizedException('Session not authorized');
    }

    try {
      const response = await dingConnectAxios.post(
        '/SendTransfer',
        JSON.stringify(payload),
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
        },
      );

      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      // console.log(error);
      return error.response.data;
    }
  }
}

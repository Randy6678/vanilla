import { IsString, IsNotEmpty, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { ArgsType, Field } from '@nestjs/graphql';

@ArgsType()
class TransferIdDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The unique identifier for the transfer within our system',
  })
  @Field({
    name: 'TransferRef',
    nullable: false,
    description: 'The unique identifier for the transfer within our system',
  })
  TransferRef: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: "The distributor's identifier for the transfer.",
  })
  @Field({
    name: 'DistributorRef',
    nullable: false,
    description: "The distributor's identifier for the transfer.",
  })
  DistributorRef: string;
}

@ArgsType()
export class CancelTransferDto {
  @ValidateNested({ each: true })
  @Type(() => TransferIdDto)
  @ApiProperty({
    required: true,
    description: 'object (TransferId)',
    isArray: true,
    type: TransferIdDto,
  })
  @Field(() => [TransferIdDto], {
    name: 'TransferId',
    nullable: false,
    description: 'object (TransferId)',
  })
  TransferId: TransferIdDto[];

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'A unique number for an item in an overall batched request',
  })
  @Field({
    name: 'BatchItemRef',
    nullable: false,
    description: 'A unique number for an item in an overall batched request',
  })
  BatchItemRef: string;
}

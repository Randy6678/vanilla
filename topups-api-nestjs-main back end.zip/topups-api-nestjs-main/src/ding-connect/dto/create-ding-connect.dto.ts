export class CreateDingConnectDto {}

import { IsString, IsNotEmpty, IsNumber, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class EstimatePricesDto {
  @IsNumber()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'Desired send value',
    format: 'decimal',
  })
  SendValue?: number;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'The currency of `SendValue`',
  })
  SendCurrencyIso?: string;

  @IsNumber()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'Desired receive value',
    format: 'decimal',
  })
  ReceiveValue?: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'Product to estimate a price for',
  })
  SkuCode: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'A unique number for an item in an overall batched request',
  })
  BatchItemRef: string;
}

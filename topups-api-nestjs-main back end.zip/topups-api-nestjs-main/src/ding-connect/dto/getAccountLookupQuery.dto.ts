import { IsString, IsNotEmpty, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class GetAccountLookupQueryDto {
  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'For phone number based products, the account number should be in international phone number format.',
    default: '233592766862',
  })
  accountNumber?: string;
}

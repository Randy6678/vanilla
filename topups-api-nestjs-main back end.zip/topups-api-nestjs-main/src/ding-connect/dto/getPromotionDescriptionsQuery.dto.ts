import { IsString, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class GetPromotionDescriptionsQueryDto {
  @IsString({ each: true })
  @IsOptional()
  @Transform((param) => {
    let codesArray: string[];
    const value = param.value;

    console.log(value, typeof value);

    if (value && typeof value == 'object' && Array.isArray(value)) {
      return value;
    }

    if (param.value && typeof param.value == 'string') {
      codesArray = param.value.split(',');
      return codesArray.map((c) => c.trim());
    }

    return [];
  })
  @ApiProperty({
    required: false,
    description:
      'Filter the list to product descriptions with the submitted language codes.',
    // example: 'lang1, lang2',
  })
  languageCodes: string[];
}

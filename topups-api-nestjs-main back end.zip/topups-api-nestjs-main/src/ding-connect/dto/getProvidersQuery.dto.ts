import { IsString, IsNotEmpty, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class GetProvidersQueryDto {
  @IsString({ each: true })
  @IsOptional()
  @Transform((param) => {
    let codesArray: string[];
    const value = param.value;

    console.log(value, typeof value);

    if (value && typeof value == 'object' && Array.isArray(value)) {
      return value;
    }

    if (param.value && typeof param.value == 'string') {
      codesArray = param.value.split(',');
      return codesArray.map((c) => c.trim());
    }

    return [];
  })
  @ApiProperty({
    required: false,
    description:
      'Filter the list to products supplied by providers with the submitted provider codes.',
    // example: 'code1, code2',
  })
  providerCodes: string[];

  @IsString({ each: true })
  @IsOptional()
  @Transform((param) => {
    let codesArray: string[];
    const value = param.value;

    console.log(value, typeof value);

    if (value && typeof value == 'object' && Array.isArray(value)) {
      return value;
    }

    if (param.value && typeof param.value == 'string') {
      codesArray = param.value.split(',');
      return codesArray.map((c) => c.trim());
    }

    return [];
  })
  @ApiProperty({
    required: false,
    description:
      'Filter the list to products for countries with the given ISOs.',
    // example: 'iso1, iso2',
  })
  countryIsos: string[];

  @IsString({ each: true })
  @IsOptional()
  @Transform((param) => {
    let codesArray: string[];
    const value = param.value;

    console.log(value, typeof value);

    if (value && typeof value == 'object' && Array.isArray(value)) {
      return value;
    }

    if (param.value && typeof param.value == 'string') {
      codesArray = param.value.split(',');
      return codesArray.map((c) => c.trim());
    }

    return [];
  })
  @ApiProperty({
    required: false,
    description:
      'Filter the list to products in regions with the submitted regionCodes.',
    // example: 'code1, code2',
  })
  regionCodes: string[];

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'Filter the list to products that are valid for the submitted account number. For phone number based products, the account number should be in international phone number format.',
    default: '',
  })
  accountNumber?: string;
}

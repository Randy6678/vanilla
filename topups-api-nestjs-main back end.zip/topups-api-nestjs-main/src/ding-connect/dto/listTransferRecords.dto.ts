import { IsString, IsNotEmpty, IsNumber, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ListTransferRecordsDto {
  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'Filter by Ding TransferRef',
  })
  TransferRef?: string;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'Filter transfers by DistributorRef.',
  })
  DistributorRef?: string;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description: 'Filter transfers by AccountNumber',
  })
  AccountNumber?: string;

  @IsNumber()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'The amount of records to by-pass before returning the remaining records',
    type: Number,
    format: 'int32',
  })
  Skip?: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The amount of records to return',
    type: Number,
    format: 'int32',
  })
  Take: number;
}

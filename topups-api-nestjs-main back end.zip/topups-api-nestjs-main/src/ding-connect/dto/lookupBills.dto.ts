import {
  IsString,
  IsNotEmpty,
  IsOptional,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

// dto
import { SettingsDto } from './settings.dto';

export class LookupBillsDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'Code provided by GetProducts API',
  })
  SkuCode: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The account number to target',
  })
  AccountNumber: string;

  @ValidateNested({ each: true })
  @Type(() => SettingsDto)
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'Product specific name/value pairs to be associated with the lookup bills request',
    isArray: true,
    type: SettingsDto,
  })
  Settings?: SettingsDto[];
}

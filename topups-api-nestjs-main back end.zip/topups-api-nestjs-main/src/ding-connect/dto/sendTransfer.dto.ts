import {
  IsString,
  IsNotEmpty,
  IsNumber,
  IsBoolean,
  IsOptional,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

// dto
import { SettingsDto } from './settings.dto';

export class SendTransferDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'Code provided by GetProducts API',
  })
  SkuCode: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description:
      'The transfer value to be sent. Specified to two decimal places of accuracy of the major currency unit, e.g. 3.17 USD.',
    type: Number,
    format: 'decimal',
  })
  SendValue: number;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'The currency of the SendValue. If this is null or empty, we will assume distributor currency.',
  })
  SendCurrencyIso?: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The account number to target',
  })
  AccountNumber: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description:
      'Unique identifier in the distributor system to be associated with the transfer',
  })
  DistributorRef: string;

  @ValidateNested({ each: true })
  @Type(() => SettingsDto)
  @IsOptional()
  @ApiProperty({
    required: false,
    description:
      'Product specific name/value pairs to be associated with the lookup bills request',
    isArray: true,
    type: SettingsDto,
  })
  Settings?: SettingsDto[];

  @IsBoolean()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description:
      'Validate the request with the provider without doing a transfer',
  })
  ValidateOnly: boolean;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @ApiProperty({
    required: true,
    description:
      'Bill reference. Required when product has "LookupBillsRequired" set to true.',
  })
  BillRef?: string;
}

import { IsString, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SettingsDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The name of the setting as defined in the SettingDefinition',
  })
  Name: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    required: true,
    description: 'The transfer specific value to associate with the Name',
  })
  Value: string;
}

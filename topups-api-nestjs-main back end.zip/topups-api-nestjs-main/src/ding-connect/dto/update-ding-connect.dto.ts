import { PartialType } from '@nestjs/swagger';
import { CreateDingConnectDto } from './create-ding-connect.dto';

export class UpdateDingConnectDto extends PartialType(CreateDingConnectDto) {}

export class DingConnect {}

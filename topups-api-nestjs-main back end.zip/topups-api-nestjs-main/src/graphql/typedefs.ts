
/*
 * -------------------------------------------------------
 * THIS FILE WAS AUTOMATICALLY GENERATED (DO NOT MODIFY)
 * -------------------------------------------------------
 */

/* tslint:disable */
/* eslint-disable */
export class TransferIdInput {
    TransferRef: string;
    DistributorRef: string;
}

export class TransferSetting {
    Name?: Nullable<string>;
    Value?: Nullable<string>;
}

export class SendTransferPayload {
    SkuCode: string;
    SendValue: number;
    SendCurrencyIso?: Nullable<string>;
    AccountNumber: string;
    DistributorRef: string;
    Settings?: Nullable<Nullable<TransferSetting>[]>;
    ValidateOnly: boolean;
    BillRef?: Nullable<string>;
}

export class EstimatePricePayload {
    SendValue?: Nullable<number>;
    SendCurrencyIso?: Nullable<string>;
    ReceiveValue?: Nullable<number>;
    SkuCode: string;
    BatchItemRef: string;
}

export class TransferRecordPayload {
    TransferRef?: Nullable<string>;
    DistributorRef?: Nullable<string>;
    AccountNumber?: Nullable<string>;
    Skip?: Nullable<number>;
    Take: number;
}

export class CancelTransferPayload {
    TransferId?: Nullable<TransferIdInput[]>;
    BatchItemRef: string;
}

export class LookupBillPayload {
    SkuCode: string;
    AccountNumber: string;
    Settings?: Nullable<TransferSetting>;
}

export class ErrorCode {
    Code?: Nullable<string>;
    Context?: Nullable<string>;
}

export class DailingInfo {
    Prefix?: Nullable<string>;
    MinimumLength?: Nullable<number>;
    MaximumLength?: Nullable<number>;
}

export class Currency {
    CurrencyIso: string;
    CurrencyName: string;
}

export class GetCurrenciesResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Currency>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Region {
    RegionCode: string;
    RegionName: string;
    CountryIso: string;
}

export class GetRegionsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Region>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Country {
    CountryIso: string;
    CountryName: string;
    InternationalDialingInformation: Nullable<DailingInfo>[];
    RegionCodes: Nullable<string>[];
}

export class GetCountriesResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Country>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Provider {
    ProviderCode?: Nullable<string>;
    CountryIso?: Nullable<string>;
    Name?: Nullable<string>;
    ShortName?: Nullable<string>;
    ValidationRegex?: Nullable<string>;
    CustomerCareNumber?: Nullable<string>;
    RegionCodes: Nullable<string>[];
    PaymentTypes: Nullable<string>[];
    LogoUrl?: Nullable<string>;
}

export class GetProvidersResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Provider>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class ProviderStatus {
    ProviderCode: string;
    IsProcessingTransfers: boolean;
    Message: string;
}

export class GetProviderStatusResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<ProviderStatus>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Product {
    ProviderCode?: Nullable<string>;
    SkuCode?: Nullable<string>;
    LocalizationKey?: Nullable<string>;
    SettingDefinitions: Nullable<ProductSettingDefinitions>[];
    Maximum?: Nullable<ProductMaximum>;
    Minimum?: Nullable<ProductMinimum>;
    CommissionRate?: Nullable<number>;
    ProcessingMode?: Nullable<string>;
    RedemptionMechanism?: Nullable<string>;
    Benefits?: Nullable<Nullable<string>[]>;
    ValidityPeriodIso?: Nullable<string>;
    UatNumber?: Nullable<string>;
    AdditionalInformation?: Nullable<string>;
    DefaultDisplayText?: Nullable<string>;
    RegionCode?: Nullable<string>;
    PaymentTypes?: Nullable<Nullable<string>[]>;
    LookupBillsRequired?: Nullable<boolean>;
}

export class GetProductsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Product>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class ProductSettingDefinitions {
    Name?: Nullable<string>;
    Description?: Nullable<string>;
    IsMandatory?: Nullable<boolean>;
}

export class ProductMaximum {
    CustomerFee?: Nullable<number>;
    DistributorFee?: Nullable<number>;
    ReceiveValue?: Nullable<number>;
    ReceiveCurrencyIso?: Nullable<string>;
    ReceiveValueExcludingTax?: Nullable<number>;
    TaxRate?: Nullable<number>;
    TaxName?: Nullable<string>;
    TaxCalculation?: Nullable<string>;
    SendValue?: Nullable<number>;
    SendCurrencyIso?: Nullable<string>;
}

export class ProductMinimum {
    CustomerFee?: Nullable<number>;
    DistributorFee?: Nullable<number>;
    ReceiveValue?: Nullable<number>;
    ReceiveCurrencyIso?: Nullable<string>;
    ReceiveValueExcludingTax?: Nullable<number>;
    TaxRate?: Nullable<number>;
    TaxName?: Nullable<string>;
    TaxCalculation?: Nullable<string>;
    SendValue?: Nullable<number>;
    SendCurrencyIso?: Nullable<string>;
}

export class ProductDescription {
    DisplayText?: Nullable<string>;
    DescriptionMarkdown?: Nullable<string>;
    ReadMoreMarkdown?: Nullable<string>;
    LocalizationKey?: Nullable<string>;
    LanguageCode?: Nullable<string>;
}

export class GetProductDescriptionsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<ProductDescription>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Balance {
    Balance?: Nullable<number>;
    CurrencyIso?: Nullable<string>;
}

export class GetBalanceResponse {
    ResultCode?: Nullable<number>;
    Balance?: Nullable<number>;
    CurrencyIso?: Nullable<string>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class Promotion {
    ProviderCode?: Nullable<string>;
    StartUtc?: Nullable<string>;
    EndUtc?: Nullable<string>;
    CurrencyIso?: Nullable<string>;
    ValidityPeriodIso?: Nullable<string>;
    MinimumSendAmount?: Nullable<number>;
    LocalizationKey?: Nullable<string>;
}

export class GetPromotionsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<Promotion>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class PromotionDescription {
    Dates?: Nullable<string>;
    Headline?: Nullable<string>;
    TermsAndConditionsMarkDown?: Nullable<string>;
    BonusValidity?: Nullable<string>;
    PromotionType?: Nullable<string>;
    LocalizationKey?: Nullable<string>;
    LanguageCode?: Nullable<string>;
}

export class GetPromotionDescriptionsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<PromotionDescription>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class AccountLookup {
    CountryIso?: Nullable<string>;
    AccountNumberNormalized?: Nullable<string>;
    Items?: Nullable<Nullable<Account>[]>;
}

export class Account {
    ProviderCode?: Nullable<string>;
    RegionCode?: Nullable<string>;
}

export class GetAccountLookupResponse {
    ResultCode?: Nullable<number>;
    CountryIso?: Nullable<string>;
    AccountNumberNormalized?: Nullable<string>;
    Items?: Nullable<Nullable<Account>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class ErrorCodeDescription {
    Message?: Nullable<string>;
    Code?: Nullable<string>;
}

export class GetErrorCodeDescriptionsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<ErrorCodeDescription>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class TransferId {
    TransferRef?: Nullable<string>;
    DistributorRef?: Nullable<string>;
}

export class TransferPrice {
    CustomerFee?: Nullable<number>;
    DistributorFee?: Nullable<number>;
    ReceiveValue?: Nullable<number>;
    ReceiveCurrencyIso?: Nullable<string>;
    ReceiveValueExcludingTax?: Nullable<number>;
    TaxRate?: Nullable<number>;
    TaxName?: Nullable<string>;
    TaxCalculation?: Nullable<string>;
    SendValue?: Nullable<number>;
    SendCurrencyIso?: Nullable<string>;
}

export class ReceiptParam {
    property1?: Nullable<string>;
    property2?: Nullable<string>;
}

export class TransferRecord {
    TransferId?: Nullable<TransferId>;
    SkuCode?: Nullable<string>;
    Price?: Nullable<TransferPrice>;
    CommissionApplied?: Nullable<number>;
    StartedUtc?: Nullable<string>;
    CompletedUtc?: Nullable<string>;
    ProcessingState?: Nullable<string>;
    ReceiptText?: Nullable<string>;
    ReceiptParams?: Nullable<ReceiptParam>;
    AccountNumber?: Nullable<string>;
}

export class SendTransferResponse {
    ResultCode?: Nullable<number>;
    TransferRecord?: Nullable<TransferRecord>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class EstimatePrice {
    Price?: Nullable<TransferPrice>;
    SkuCode?: Nullable<string>;
    BatchItemRef?: Nullable<string>;
}

export class EstimatePricesResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<EstimatePrice>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class ListTransferRecord {
    TransferRecord?: Nullable<TransferRecord>;
    ResultCode?: Nullable<number>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class ListTransferRecordsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<ListTransferRecord>[]>;
    ThereAreMoreItems?: Nullable<boolean>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class CanceledTransfer {
    TransferId?: Nullable<TransferId>;
    ProcessingState?: Nullable<string>;
    BatchItemRef?: Nullable<string>;
}

export class CancelTransferResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<CanceledTransfer>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export class LookupBill {
    Price?: Nullable<TransferPrice>;
    BillRef?: Nullable<string>;
    AdditionalInfo?: Nullable<ReceiptParam>;
}

export class LookupBillsResponse {
    ResultCode?: Nullable<number>;
    Items?: Nullable<Nullable<LookupBill>[]>;
    ErrorCodes?: Nullable<Nullable<ErrorCode>[]>;
}

export abstract class IQuery {
    abstract Hello(): Nullable<string> | Promise<Nullable<string>>;

    abstract GetAccountLookup(accountNumber: string): GetAccountLookupResponse | Promise<GetAccountLookupResponse>;

    abstract GetBalance(): GetBalanceResponse | Promise<GetBalanceResponse>;

    abstract GetCountries(): GetCountriesResponse | Promise<GetCountriesResponse>;

    abstract GetCurrencies(): GetCurrenciesResponse | Promise<GetCurrenciesResponse>;

    abstract GetErrorCodeDescriptions(): GetErrorCodeDescriptionsResponse | Promise<GetErrorCodeDescriptionsResponse>;

    abstract GetProductDescriptions(languageCodes?: Nullable<Nullable<string>[]>, skuCodes?: Nullable<Nullable<string>[]>): GetProductDescriptionsResponse | Promise<GetProductDescriptionsResponse>;

    abstract GetProducts(countryIsos?: Nullable<Nullable<string>[]>, providerCodes?: Nullable<Nullable<string>[]>, skuCodes?: Nullable<Nullable<string>[]>, benefits?: Nullable<Nullable<string>[]>, regionCodes?: Nullable<Nullable<string>[]>, accountNumber?: Nullable<string>): GetProductsResponse | Promise<GetProductsResponse>;

    abstract GetPromotionDescriptions(languageCodes?: Nullable<string>): GetPromotionDescriptionsResponse | Promise<GetPromotionDescriptionsResponse>;

    abstract GetPromotions(countryIsos?: Nullable<Nullable<string>[]>, providerCodes?: Nullable<Nullable<string>[]>, accountNumber?: Nullable<string>): GetPromotionsResponse | Promise<GetPromotionsResponse>;

    abstract GetProviders(providerCodes?: Nullable<Nullable<string>[]>, countryIsos?: Nullable<Nullable<string>[]>, regionCodes?: Nullable<Nullable<string>[]>, accountNumber?: Nullable<string>): GetProvidersResponse | Promise<GetProvidersResponse>;

    abstract GetProviderStatus(providerCodes?: Nullable<Nullable<string>[]>): GetProviderStatusResponse | Promise<GetProviderStatusResponse>;

    abstract GetRegions(countryIsos?: Nullable<Nullable<string>[]>): GetRegionsResponse | Promise<GetRegionsResponse>;
}

export abstract class IMutation {
    abstract CancelTransfers(payload?: Nullable<Nullable<CancelTransferPayload>[]>): CancelTransferResponse | Promise<CancelTransferResponse>;

    abstract EstimatePrices(payload?: Nullable<Nullable<EstimatePricePayload>[]>): EstimatePricesResponse | Promise<EstimatePricesResponse>;

    abstract ListTransferRecords(payload?: Nullable<TransferRecordPayload>): ListTransferRecordsResponse | Promise<ListTransferRecordsResponse>;

    abstract LookupBills(payload?: Nullable<LookupBillPayload>): LookupBillsResponse | Promise<LookupBillsResponse>;

    abstract SendTransfer(payload?: Nullable<SendTransferPayload>): SendTransferResponse | Promise<SendTransferResponse>;
}

type Nullable<T> = T | null;

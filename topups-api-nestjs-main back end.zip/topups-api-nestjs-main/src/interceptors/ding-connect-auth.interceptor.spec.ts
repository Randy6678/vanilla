import { DingConnectAuthInterceptor } from './ding-connect-auth.interceptor';

describe('DingConnectAuthInterceptor', () => {
  it('should be defined', () => {
    expect(new DingConnectAuthInterceptor()).toBeDefined();
  });
});

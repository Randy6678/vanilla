import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { GqlContextType } from '@nestjs/graphql';
// axios
import axios from 'axios';

// lib/auth-analytics
import {
  getAuthAnalytics,
  setAuthAnalytics,
} from '../common/lib/auth-analytics';

// middleware constants
const axiosConfig = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const params = new URLSearchParams();
params.append('client_id', process.env.DING_CONNECT_CLIENT_ID);
params.append('client_secret', process.env.DING_CONNECT_CLIENT_SECRET);
params.append('grant_type', process.env.DING_CONNECT_GRANT_TYPE);

@Injectable()
export class DingConnectAuthInterceptor implements NestInterceptor {
  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    let request: any;

    // checking current execution context
    if (context.getType() === 'http') {
      /* if execution context is http */
      // console.log('Execution context is rest/http');

      // changing request
      request = context.switchToHttp().getRequest();
    } else if (context.getType<GqlContextType>() === 'graphql') {
      /* if execution context is graphql */
      // console.log('Execution context is graphql');

      // changing request
      request = context.getArgByIndex(2).req;
    }

    // get existing analytics data
    const authAnalytics = getAuthAnalytics();
    let accessToken = authAnalytics.access_token;

    if (authAnalytics.expiresAt <= Date.now()) {
      try {
        const response = await axios.post(
          'https://idp.ding.com/connect/token',
          params,
          axiosConfig,
        );

        const { access_token, expires_in } = response.data;

        const currentDate = new Date();
        currentDate.setSeconds(currentDate.getSeconds() + expires_in);

        const newAuthAnalytics = {
          access_token,
          last_authenticated: Date.now(),
          expiresAt: currentDate.getTime(),
          auth_count: authAnalytics.auth_count + 1,
        };

        accessToken = newAuthAnalytics.access_token;
        setAuthAnalytics(newAuthAnalytics);
      } catch (error) {
        // An Error Occurred
        request.dcAuthAt = null;
      }
    }

    request.dcAuthAt = accessToken;
    return next.handle();
  }
}

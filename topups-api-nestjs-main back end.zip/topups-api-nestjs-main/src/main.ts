import { ValidationPipe, ClassSerializerInterceptor } from '@nestjs/common';
import { HttpAdapterHost, NestFactory, Reflector } from '@nestjs/core';
// swagger
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

// App Module
import { AppModule } from './app.module';

/* DB ORM */
// prisma service
import { PrismaService } from './prisma/prisma.service';

// Execption Filters
import { PrismaClientExceptionFilter } from './prisma/filters/prisma-client-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // enable cors
  app.enableCors();

  // binds ValidationPipe to the entire application
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // apply transform to all responses
  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));

  // 👇 apply PrismaClientExceptionFilter to entire application, requires HttpAdapterHost because it extends BaseExceptionFilter
  const { httpAdapter } = app.get(HttpAdapterHost);
  app.useGlobalFilters(new PrismaClientExceptionFilter(httpAdapter));

  // configure prisma
  const prismaService = app.get(PrismaService);
  // enable prisma shut down hooks
  await prismaService.enableShutdownHooks(app);

  // configure swagger
  const config = new DocumentBuilder()
    .setTitle('Topups API Documentation (REST Version)')
    .setDescription(
      'This documentation includes API description of restful endpoints in the topups API',
    )
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api-docs', app, document);

  await app.listen(process.env.PORT || 5000);
  console.log(`Application is running on: ${await app.getUrl()}`);
}

bootstrap();

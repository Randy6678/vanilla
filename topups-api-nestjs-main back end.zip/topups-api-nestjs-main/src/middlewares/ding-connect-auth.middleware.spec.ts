import { DingConnectAuthMiddleware } from './ding-connect-auth.middleware';

describe('DingConnectAuthMiddleware', () => {
  it('should be defined', () => {
    expect(new DingConnectAuthMiddleware()).toBeDefined();
  });
});

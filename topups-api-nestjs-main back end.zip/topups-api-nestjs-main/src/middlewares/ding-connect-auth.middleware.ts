import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
// axios
import axios from 'axios';

// services
import { RequestService } from '../services/request.service';

// lib/auth-analytics
import {
  getAuthAnalytics,
  setAuthAnalytics,
} from '../common/lib/auth-analytics';

// middleware constants
const axiosConfig = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const params = new URLSearchParams();
params.append('client_id', process.env.DING_CONNECT_CLIENT_ID);
params.append('client_secret', process.env.DING_CONNECT_CLIENT_SECRET);
params.append('grant_type', process.env.DING_CONNECT_GRANT_TYPE);

@Injectable()
export class DingConnectAuthMiddleware implements NestMiddleware {
  constructor(private readonly requestService: RequestService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    // get existing analytics data
    const authAnalytics = getAuthAnalytics();
    let accessToken = authAnalytics.access_token;
    console.log(accessToken);

    if (authAnalytics.expiresAt <= Date.now()) {
      try {
        const response = await axios.post(
          'https://idp.ding.com/connect/token',
          params,
          axiosConfig,
        );

        const { access_token, expires_in } = response.data;

        const currentDate = new Date();
        currentDate.setSeconds(currentDate.getSeconds() + expires_in);

        const newAuthAnalytics = {
          access_token,
          last_authenticated: Date.now(),
          expiresAt: currentDate.getTime(),
          auth_count: authAnalytics.auth_count + 1,
        };

        accessToken = newAuthAnalytics.access_token;
        setAuthAnalytics(newAuthAnalytics);
      } catch (error) {
        // An Error Occurred
        console.log(error);
        // req.dcAuthAt = null;
        this.requestService.setDCAuthAt(null);
        return next();
      }
    }

    this.requestService.setDCAuthAt(accessToken);
    next();
  }
}

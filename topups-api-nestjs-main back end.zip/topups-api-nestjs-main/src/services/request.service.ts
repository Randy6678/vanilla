import { Injectable, Scope } from '@nestjs/common';

@Injectable({ scope: Scope.REQUEST })
export class RequestService {
  private dcAuthAt: string;

  setDCAuthAt(dcAuthAt: string) {
    this.dcAuthAt = dcAuthAt;
  }

  getDCAuthAt() {
    return this.dcAuthAt;
  }
}

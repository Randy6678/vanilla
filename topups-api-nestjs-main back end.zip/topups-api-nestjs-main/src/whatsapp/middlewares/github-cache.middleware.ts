import {
  CACHE_MANAGER,
  Inject,
  Injectable,
  NestMiddleware,
} from '@nestjs/common';
// cache-manager
import { Cache } from 'cache-manager';
// express
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class GithubCacheMiddleware implements NestMiddleware {
  constructor(@Inject(CACHE_MANAGER) private readonly cacheManager: Cache) {}

  use(req: Request, res: Response, next: NextFunction) {
    // console.log('Middleware Running...');
    const { username } = req.params;

    this.cacheManager.get(username, (err, repoCount) => {
      if (err) throw err;

      // console.log(repoCount);
      // console.log(!Number.isNaN(repoCount));

      if (repoCount !== null && !Number.isNaN(+repoCount)) {
        return res
          .status(200)
          .send(`<h2>${username} has ${repoCount} Github repos</h2>`);
      }

      next();
    });
  }
}

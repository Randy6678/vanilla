import { Controller, Post, Get, Body, Res, Query, Param } from '@nestjs/common';
// swagger
import { ApiTags } from '@nestjs/swagger';

// services
import { WhatsappService } from './whatsapp.service';

@ApiTags('whatsapp')
@Controller('whatsapp')
export class WhatsappController {
  constructor(private readonly whatsappService: WhatsappService) {}

  // Accepts POST requests at /webhook endpoint
  @Post('webhook')
  async handleIncomingPostRequest(@Res() response, @Body() body) {
    // Check the Incoming webhook message
    console.log(JSON.stringify(body, null, 2));

    try {
      await this.whatsappService.handleOnMessageReceived(body);

      response.status(200).send();
    } catch (error) {
      console.log(error);
      response.status(500).send();
    }
  }

  // Accepts GET requests at the /webhook endpoint. You need this URL to setup webhook initially.
  @Get('webhook')
  handleIncomingGetRequest(@Res() response, @Query() query) {
    /** 
      * UPDATE YOUR VERIFY TOKEN
      This will be the Verify Token value when you set up webhook
    **/
    const VERIFY_TOKEN = process.env.VERIFY_TOKEN;

    // Parse params from the webhook verification request
    const mode = query['hub.mode'];
    const token = query['hub.verify_token'];
    const challenge = query['hub.challenge'];

    // Check if a token and mode were sent
    if (mode && token) {
      // Check the mode and token sent are correct
      if (mode === 'subscribe' && token === VERIFY_TOKEN) {
        // Respond with 200 OK and challenge token from the request
        console.log('WEBHOOK_VERIFIED');
        response.status(200).send(challenge);
      } else {
        // Responds with '403 Forbidden' if verify tokens do not match
        response.set('Bypass-Tunnel-Reminder', true);
        response.status(403);
      }
    }
  }

  // Send Custom Text Message
  @Get(':number')
  async sendCustomTextMessage(
    @Res() response,
    @Param('number') number: string,
    @Query('msg') message: string,
  ) {
    // Check the Incoming webhook message
    console.log('number', number);
    console.log('message', message);

    try {
      await this.whatsappService.handleOnSendCustomTextMessage(number, message);

      response.status(200).send('Sent');
    } catch (error) {
      console.log(error);
      response.status(500).send();
    }
  }

  // Test Redis endpoint
  @Get(':username')
  async getUserReposCount(
    @Res() response,
    @Param('username') username: string,
  ) {
    try {
      const repoCount = await this.whatsappService.getGithubUserRepos(username);

      response
        .status(200)
        .send(`<h2>${username} has ${repoCount} Github repos</h2>`);
    } catch (error) {
      console.log(error);
      response.status(500);
    }
  }
}

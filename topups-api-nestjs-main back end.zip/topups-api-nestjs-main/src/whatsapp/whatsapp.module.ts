import {
  CacheModule,
  MiddlewareConsumer,
  Module,
  NestModule,
  RequestMethod,
} from '@nestjs/common';
// redis
import type { ClientOpts } from 'redis';
// cache manager redis store
import * as redisStore from 'cache-manager-redis-store';

// middlewares
import { GithubCacheMiddleware } from './middlewares/github-cache.middleware';

// controllers
import { WhatsappController } from './whatsapp.controller';

// services
import { WhatsappService } from './whatsapp.service';

@Module({
  imports: [
    CacheModule.register<ClientOpts>(
      process.env.NODE_ENV !== 'development'
        ? {
            store: redisStore,
            // Store-specific configuration:
            host: 'redis-18777.c15.us-east-1-4.ec2.cloud.redislabs.com',
            port: 18777,
            auth_pass: 'ylqgXgg26W9LU8Tntz6K2NmyxDo5VGLh',
          }
        : {
            store: redisStore,
            // Store-specific configuration:
            host: 'localhost',
            port: 6379,
          },
    ),
  ],
  controllers: [WhatsappController],
  providers: [WhatsappService],
})
export class WhatsappModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(GithubCacheMiddleware)
      .forRoutes({ path: 'whatsapp/:username', method: RequestMethod.GET });
  }
}

import { Injectable, Inject, CACHE_MANAGER } from '@nestjs/common';
// cache manager
import { Cache } from 'cache-manager';
// prisma
import { ConversationMessageType } from '@prisma/client';
// axios
import axios from 'axios';

// services
import { PrismaService } from '../prisma/prisma.service';

// whatsapp api axios instance
import { whatsappApiAxios } from '../common/lib/axios-instances';

// whatsapp state flow
import StateFlow from '../common/whatsapp/reponse-state-flow';

// whatsapp error class
import { WhatsappMessageResponseError } from '../common/whatsapp/custom-error';

// whatsapp response helpers
import {
  sessionResetFailedResponse,
  sessionResetSuccessfulResponse,
  welcomeMessage,
} from '../common/whatsapp/response-messages';

// custom types and interfaces
import { ConversationState } from '../common/types';
import { ConversationContext } from '../common/enums';

@Injectable()
export class WhatsappService {
  constructor(
    @Inject(CACHE_MANAGER) private readonly cacheManager: Cache,
    private readonly prisma: PrismaService,
  ) {}

  async handleOnMessageReceived(requestBody) {
    // Validate the webhook
    if (requestBody && typeof requestBody === 'object' && requestBody.object) {
      if (
        requestBody.entry &&
        requestBody.entry[0].changes &&
        requestBody.entry[0].changes[0] &&
        requestBody.entry[0].changes[0].value.messages &&
        requestBody.entry[0].changes[0].value.messages[0]
      ) {
        const phone_number_id =
          requestBody.entry[0].changes[0].value.metadata.phone_number_id;
        const messagesObject =
          requestBody.entry[0].changes[0].value.messages[0];
        const msg_id = messagesObject.id;
        const from = messagesObject.from; // extract the phone number from the webhook payload
        const msg_type = messagesObject.type;
        const msg_context = messagesObject?.context;
        let msg_body;

        switch (msg_type) {
          case 'text':
            msg_body = messagesObject.text.body; // extract the message text from the webhook payload
            break;
          case 'interactive':
            const interactiveMessageType = messagesObject.interactive.type;
            msg_body = messagesObject.interactive[interactiveMessageType];
            break;
          default:
            const typeOfMessageType = messagesObject[msg_type]?.type;
            msg_body = typeOfMessageType
              ? messagesObject[msg_type][typeOfMessageType]
              : messagesObject[msg_type];
            break;
        }

        // get current user
        const currentUser = await this.createOrReturnWhatsappUser(from);

        // save the message in database
        const conversationTracker =
          await this.prisma.whatsappConversationTracker.create({
            data: {
              message: msg_body,
              messageId: msg_id,
              messageType:
                msg_type == 'text'
                  ? ConversationMessageType.TEXT
                  : msg_type == 'interactive'
                  ? ConversationMessageType.INTERACTIVE
                  : ConversationMessageType.OTHER,
              isReplyMessage: !!msg_context,
              messageContext: msg_context,
              userId: currentUser.id,
            },
            select: {
              id: true,
            },
          });

        try {
          // check if message type was a text and message value is "Restart"
          if (
            msg_type === 'text' &&
            typeof msg_body === 'string' &&
            msg_body.trim().toLowerCase() === 'restart'
          ) {
            await this.resetUserState(requestBody, phone_number_id);
            return true;
          }

          const stateJson = await this.cacheManager.get(from);

          console.log('state', stateJson);

          let conversationStateObj: ConversationState = {
            context: ConversationContext.None,
            activeState: 'initial',
          };

          if (stateJson && typeof stateJson === 'string') {
            conversationStateObj = JSON.parse(stateJson) as ConversationState;
          }

          // set prev active state to active state
          conversationStateObj.prevState = conversationStateObj.activeState;
          if (conversationStateObj.prevState === 'initial') {
            conversationStateObj.activeState = welcomeMessage.name;
            conversationStateObj.context = ConversationContext.None;
          } else {
            conversationStateObj.activeState = conversationStateObj.nextState;
            // StateFlow[conversationStateObj.prevState].next.name;
          }

          const currentActiveState = conversationStateObj.activeState;

          const { responseData, updatedConversationState } = StateFlow[
            currentActiveState
          ].isAsync
            ? await StateFlow[currentActiveState].execute(
                requestBody,
                conversationStateObj,
              )
            : StateFlow[currentActiveState].execute(
                requestBody,
                conversationStateObj,
              );

          // send response back to user
          await whatsappApiAxios({
            method: 'POST', // Required, HTTP method, a string, e.g. POST, GET
            url: `https://graph.facebook.com/${process.env.WA_API_VERSION}/${phone_number_id}/messages?access_token=${process.env.WHATSAPP_TOKEN}`,
            data: responseData,
            headers: { 'Content-Type': 'application/json' },
          });

          // save conversation response in db
          await this.prisma.whatsappConversationResponse.create({
            data: {
              responseFunction: currentActiveState,
              responseParams: requestBody,
              conversationTrackerId: conversationTracker.id,
            },
          });

          // store current message in redis cache
          conversationStateObj = updatedConversationState;
          await this.cacheManager.set(
            from,
            JSON.stringify(conversationStateObj),
            {
              ttl: 3600 * 24,
            },
          ); // expire after 24 hours
        } catch (error) {
          console.error('An error occured responding to message', error);

          if (error instanceof WhatsappMessageResponseError) {
            await this.handleWhatsappMessageResponseError(requestBody, error);
            return;
          } else {
            throw error;
          }
        }
      }

      return true;
    }

    // Return a false if event is not a incoming whatsApp message
    return false;
  }

  async resetUserState(requestBody, phone_number_id: string) {
    const conversationStateObj: ConversationState = {
      context: ConversationContext.None,
      activeState: 'initial',
    };

    const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
    const from = messagesObject.from; // extract the phone number from the webhook payload

    try {
      // update/reset current user state in redis cache
      await this.cacheManager.set(from, JSON.stringify(conversationStateObj), {
        ttl: 3600 * 24,
      }); // expire after 24 hours

      // notify user that their session has been reset/restarted
      const responseData = sessionResetSuccessfulResponse(requestBody);
      // send success response back to user
      await whatsappApiAxios({
        method: 'POST', // Required, HTTP method, a string, e.g. POST, GET
        url: `https://graph.facebook.com/${process.env.WA_API_VERSION}/${phone_number_id}/messages?access_token=${process.env.WHATSAPP_TOKEN}`,
        data: responseData,
        headers: { 'Content-Type': 'application/json' },
      });
    } catch (error) {
      console.log('Reset State Error', error);

      // notify user that there was an error while reseting/restarting session
      const errorResponseData = sessionResetFailedResponse(requestBody);
      // send error response back to user
      await whatsappApiAxios({
        method: 'POST', // Required, HTTP method, a string, e.g. POST, GET
        url: `https://graph.facebook.com/${process.env.WA_API_VERSION}/${phone_number_id}/messages?access_token=${process.env.WHATSAPP_TOKEN}`,
        data: errorResponseData,
        headers: { 'Content-Type': 'application/json' },
      });
    }
  }

  async handleWhatsappMessageResponseError(
    requestBody,
    error: WhatsappMessageResponseError,
  ) {
    // extract important fields from request body
    const phone_number_id =
      requestBody.entry[0].changes[0].value.metadata.phone_number_id; // whatsapp bots phone number from the webhook payload
    const messagesObject = requestBody.entry[0].changes[0].value.messages[0];
    const from = messagesObject.from; // extract the phone number from the webhook payload

    // get current conversation state
    const stateJson = await this.cacheManager.get(from);
    let conversationStateObj: ConversationState = {
      context: ConversationContext.None,
      activeState: 'initial',
    };

    if (stateJson && typeof stateJson === 'string') {
      conversationStateObj = JSON.parse(stateJson) as ConversationState;
    }

    // variable to holding error response object
    let errorResponseData;

    switch (error.message) {
      case 'invalidWelcomeMessageResponse':
        errorResponseData = StateFlow.welcomeMessage.error(requestBody);
        break;
      case 'invalidSelectCountryMessageResponse':
        errorResponseData = StateFlow.selectCountryMessage.error(requestBody);
        break;
      case 'invalidGetRecipientPhoneMessage':
        errorResponseData = StateFlow.getRecipientPhoneMessage.error(
          requestBody,
          conversationStateObj,
        );
        break;
      case 'invalidConfirmMobileOperatorMessage':
        errorResponseData = await StateFlow.confirmMobileOperatorMessage.error(
          requestBody,
          conversationStateObj,
        );
        break;
      case 'invalidGetVaryingProductSendValueMessage':
        errorResponseData =
          await StateFlow.getVaryingProductSendValueMessage.error(
            requestBody,
            conversationStateObj,
          );
        break;
      case 'invalidSelectTopupPlanMessage':
        errorResponseData = await StateFlow.selectTopupPlanMessage.error(
          requestBody,
          conversationStateObj,
        );
        break;
      case 'invalidConfirmSendTopupMessage':
        errorResponseData = await StateFlow.confirmSendTopupMessage.error(
          requestBody,
          conversationStateObj,
        );
        break;
      case 'invalidConfirmSendVaryingTopupMessage':
        errorResponseData =
          await StateFlow.confirmSendVaryingTopupMessage.error(
            requestBody,
            conversationStateObj,
          );
        break;
      default:
        console.error('An handled whatsapp response message occured', error);

        errorResponseData = {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: from,
          type: 'text',
          text: {
            body: `
*An handled whatsapp response message occured*

${JSON.stringify(error, null, 2)}`.trim(),
          },
        };
        break;
    }

    // send error response back to user
    await whatsappApiAxios({
      method: 'POST', // Required, HTTP method, a string, e.g. POST, GET
      url: `https://graph.facebook.com/${process.env.WA_API_VERSION}/${phone_number_id}/messages?access_token=${process.env.WHATSAPP_TOKEN}`,
      data: errorResponseData,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  async handleOnSendCustomTextMessage(number: string, message: string) {
    await whatsappApiAxios({
      method: 'POST', // Required, HTTP method, a string, e.g. POST, GET
      url: `https://graph.facebook.com/${process.env.WA_API_VERSION}/${process.env.PHONE_NUMBER_ID}/messages?access_token=${process.env.WHATSAPP_TOKEN}`,
      data: {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: number,
        type: 'text',
        text: {
          body: message,
        },
      },
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // method to create or return user
  async createOrReturnWhatsappUser(user_phone: string) {
    const existingUser = await this.prisma.user.findUnique({
      where: { phone: user_phone },
      select: { id: true },
    });

    if (existingUser) return existingUser;

    return await this.prisma.user.create({
      data: {
        firstName: 'Whatsapp',
        lastName: 'User',
        email: `${user_phone}@whatsappuser.com`,
        phone: user_phone,
        password: 'password',
      },
      select: {
        id: true,
      },
    });
  }

  // test method to fetch gitgub user profile repos
  async getGithubUserRepos(username: string) {
    // console.log('Fetching data');

    const axiosResponse = await axios.get(
      `https://api.github.com/users/${username}`,
    );

    const data = axiosResponse.data;

    const repoCount = data.public_repos;

    // Set data to redis
    this.cacheManager.set(username, repoCount, { ttl: 3600 });

    return repoCount;
  }
}
